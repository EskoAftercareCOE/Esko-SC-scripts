paramikojs.ZlibCompressor = function () {
	
}

paramikojs.ZlibCompressor.prototype = {
	
};

paramikojs.ZlibDecompressor = function () {
	
}

paramikojs.ZlibDecompressor.prototype = {
	
};
