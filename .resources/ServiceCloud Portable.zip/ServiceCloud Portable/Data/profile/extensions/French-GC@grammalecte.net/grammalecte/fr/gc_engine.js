// Grammar checker engine


// String

String.prototype._count = function (sSearch, bOverlapping) {
    // http://jsperf.com/string-ocurrence-split-vs-match/8
    if (sSearch.length <= 0) {
        return this.length + 1;
    }
    let nOccur = 0;
    let iPos = 0;
    let nStep = (bOverlapping) ? 1 : sSearch.length;
    while ((iPos = this.indexOf(sSearch, iPos)) >= 0) {
        nOccur++;
        iPos += nStep;
    }
    return nOccur;
}
String.prototype._isDigit = function () {
    return (this.search(/^[0-9⁰¹²³⁴⁵⁶⁷⁸⁹]+$/) !== -1);
}
String.prototype._isLowerCase = function () {
    return (this.search(/^[a-zà-öø-ÿ0-9-]+$/) !== -1);
}
String.prototype._isUpperCase = function () {
    return (this.search(/^[A-ZÀ-ÖØ-ßŒ0-9-]+$/) !== -1);
}
String.prototype._isTitle = function () {
    return (this.search(/^[A-ZÀ-ÖØ-ßŒ][a-zà-öø-ÿ'’-]+$/) !== -1);
}
String.prototype._toCapitalize = function () {
    return this.slice(0,1).toUpperCase() + this.slice(1).toLowerCase();
}
String.prototype._expand = function (oMatch) {
    let sNew = this;
    for (let i = 0; i < oMatch.length ; i++) {
        let z = new RegExp("\\\\"+parseInt(i), "g");
        sNew = sNew.replace(z, oMatch[i]);
    }
    return sNew;
}
String.prototype._trimRight = function (sChars) {
    let z = new RegExp("["+sChars+"]+$");
    return this.replace(z, "");
}
String.prototype._trimLeft = function (sChars) {
    let z = new RegExp("^["+sChars+"]+");
    return this.replace(z, "");
}
String.prototype._trim = function (sChars) {
    let z1 = new RegExp("^["+sChars+"]+");
    let z2 = new RegExp("["+sChars+"]+$");
    return this.replace(z1, "").replace(z2, "");
}


// regex

RegExp.prototype._exec2 = function (sText, aGroupsPos, aNegLookBefore=null) {
    let m;
    while ((m = this.exec(sText)) !== null) {
        // we have to iterate over sText here too
        // because first match doesn’t imply it’s a valid match according to negative lookbefore assertions,
        // and even if first match is finally invalid, it doesn’t mean the following eligible matchs would be invalid too.
        if (aNegLookBefore !== null) {
            // check negative look before assertions
            if ( !aNegLookBefore.some(sRegEx  =>  (RegExp.leftContext.search(sRegEx) >= 0)) ) {
                break;
            }
        } else {
            break;
        }
    }
    if (m === null) {
        return null;
    }

    let codePos;
    let iPos = 0;
    m.start = [m.index];
    m.end = [this.lastIndex];
    if (m.length > 1) {
        // there is subgroup(s)
        if (aGroupsPos !== null) {
            // aGroupsPos is defined
            for (let i = 1; i <= m.length-1; i++) {
                codePos = aGroupsPos[i-1];
                if (typeof codePos === "number") {
                    // position as a number
                    m.start.push(m.index + codePos);
                    m.end.push(m.index + codePos + m[i].length);
                } else if (codePos === "$") {
                    // at the end of the pattern
                    m.start.push(this.lastIndex - m[i].length);
                    m.end.push(this.lastIndex);
                } else if (codePos === "w") {
                    // word in the middle of the pattern
                    iPos = m[0].search("[ ~’,()«»“”]"+m[i]+"[ ,’~()«»“”]") + 1 + m.index
                    m.start.push(iPos);
                    m.end.push(iPos + m[i].length)
                } else if (codePos === "*") {
                    // anywhere
                    iPos = m[0].indexOf(m[i]) + m.index;
                    m.start.push(iPos);
                    m.end.push(iPos + m[i].length)
                } else if (codePos === "**") {
                    // anywhere after previous group
                    iPos = m[0].indexOf(m[i], m.end[i-1]-m.index) + m.index;
                    m.start.push(iPos);
                    m.end.push(iPos + m[i].length)
                } else if (codePos.startsWith(">")) {
                    // >x:_
                    // todo: look in substring x
                    iPos = m[0].indexOf(m[i]) + m.index;
                    m.start.push(iPos);
                    m.end.push(iPos + m[i].length);
                } else {
                    console.error("# Error: unknown positioning code in regex [" + this.source + "], for group[" + i.toString() +"], code: [" + codePos + "]");
                }
            }
        } else {
            // no aGroupsPos
            for (let subm of m.slice(1)) {
                iPos = m[0].indexOf(subm) + m.index;
                m.start.push(iPos);
                m.end.push(iPos + subm.length);
            }
        }
    }
    return m;
}


// Map

Map.prototype._shallowCopy = function () {
    let oNewMap = new Map();
    for (let [key, val] of this.entries()) {
        oNewMap.set(key, val);
    }
    return oNewMap;
}

Map.prototype._get = function (key, defaultValue) {
    let res = this.get(key);
    if (res !== undefined) {
        return res;
    }
    return defaultValue;
}

Map.prototype._toString = function () {
    // Default .toString() gives nothing useful
    let sRes = "{ ";
    for (let [k, v] of this.entries()) {
        sRes += (typeof k === "string") ? '"' + k + '": ' : k.toString() + ": ";
        sRes += (typeof v === "string") ? '"' + v + '", ' : v.toString() + ", ";
    }
    sRes = sRes.slice(0, -2) + " }"
    return sRes;
}

Map.prototype._update = function (dDict) {
    for (let [k, v] of dDict.entries()) {
        this.set(k, v);
    }
}

Map.prototype._updateOnlyExistingKeys = function (dDict) {
    for (let [k, v] of dDict.entries()) {
        if (this.has(k)){
            this.set(k, v);
        }
    }
}



function capitalizeArray (aArray) {
    // can’t map on user defined function??
    let aNew = [];
    for (let i = 0; i < aArray.length; i = i + 1) {
        aNew[i] = aArray[i]._toCapitalize();
    }
    return aNew;
}

const ibdawg = require("resource://grammalecte/ibdawg.js");
const helpers = require("resource://grammalecte/helpers.js");
const gc_options = require("resource://grammalecte/fr/gc_options.js");
const cr = require("resource://grammalecte/fr/cregex.js");
const text = require("resource://grammalecte/text.js");
const echo = require("resource://grammalecte/helpers.js").echo;

const lang = "fr";
const locales = {'fr-FR': ['fr', 'FR', ''], 'fr-BE': ['fr', 'BE', ''], 'fr-CA': ['fr', 'CA', ''], 'fr-CH': ['fr', 'CH', ''], 'fr-LU': ['fr', 'LU', ''], 'fr-MC': ['fr', 'MC', ''], 'fr-BF': ['fr', 'BF', ''], 'fr-CI': ['fr', 'CI', ''], 'fr-SN': ['fr', 'SN', ''], 'fr-ML': ['fr', 'ML', ''], 'fr-NE': ['fr', 'NE', ''], 'fr-TG': ['fr', 'TG', ''], 'fr-BJ': ['fr', 'BJ', '']};
const pkg = "grammalecte";
const name = "Grammalecte";
const version = "0.5.15.1";
const author = "Olivier R.";

// commons regexes
const _zEndOfSentence = new RegExp ('([.?!:;…][ .?!… »”")]*|.$)', "g");
const _zBeginOfParagraph = new RegExp ("^[-  –—.,;?!…]*", "ig");
const _zEndOfParagraph = new RegExp ("[-  .,;?!…–—]*$", "ig");

// grammar rules and dictionary
//const _rules = require("./gc_rules.js");
const _rules = require("resource://grammalecte/fr/gc_rules.js");
let _dOptions = gc_options.dOpt._shallowCopy();     // duplication necessary, to be able to reset to default
let _aIgnoredRules = new Set();
let _oDict = null;
let _dAnalyses = new Map();                        // cache for data from dictionary


///// Parsing

function parse (sText, sCountry="FR", bDebug=false) {
    // analyses the paragraph sText and returns list of errors
    let dErrors;
    let errs;
    let sAlt = sText;
    let dDA = new Map();        // Disamnbiguator
    let dPriority = new Map();  // Key = position; value = priority
    let sNew = "";

    // parse paragraph
    try {
        [sNew, dErrors] = _proofread(sText, sAlt, 0, true, dDA, dPriority, sCountry, bDebug);
        if (sNew) {
            sText = sNew;
        }
    }
    catch (e) {
        helpers.logerror(e);
    }

    // cleanup
    if (sText.includes(" ")) {
        sText = sText.replace(/ /g, ' '); // nbsp
    }
    if (sText.includes(" ")) {
        sText = sText.replace(/ /g, ' '); // snbsp
    }
    if (sText.includes("'")) {
        sText = sText.replace(/'/g, "’");
    }
    if (sText.includes("‑")) {
        sText = sText.replace(/‑/g, "-"); // nobreakdash
    }

    // parse sentence
    for (let [iStart, iEnd] of _getSentenceBoundaries(sText)) {
        if (4 < (iEnd - iStart) < 2000) {
            dDA.clear();
            try {
                [_, errs] = _proofread(sText.slice(iStart, iEnd), sAlt.slice(iStart, iEnd), iStart, false, dDA, dPriority, sCountry, bDebug);
                dErrors._update(errs);
            }
            catch (e) {
                helpers.logerror(e);
            }
        }
    }
    return Array.from(dErrors.values());
}

function* _getSentenceBoundaries (sText) {
    let mBeginOfSentence = _zBeginOfParagraph.exec(sText)
    let iStart = _zBeginOfParagraph.lastIndex;
    let m;
    while ((m = _zEndOfSentence.exec(sText)) !== null) {
        yield [iStart, _zEndOfSentence.lastIndex];
        iStart = _zEndOfSentence.lastIndex;
    }
}

function _proofread (s, sx, nOffset, bParagraph, dDA, dPriority, sCountry, bDebug) {
    let dErrs = new Map();
    let bChange = false;
    let bIdRule = option('idrule');
    let m;
    let bCondMemo;
    let nErrorStart;

    for (let [sOption, lRuleGroup] of _getRules(bParagraph)) {
        if (!sOption || option(sOption)) {
            for (let [zRegex, bUppercase, sLineId, sRuleId, nPriority, lActions, lGroups, lNegLookBefore] of lRuleGroup) {
                if (!_aIgnoredRules.has(sRuleId)) {
                    while ((m = zRegex._exec2(s, lGroups, lNegLookBefore)) !== null) {
                        bCondMemo = null;
                        /*if (bDebug) {
                            echo(">>>> Rule # " + sLineId + " - Text: " + s + " opt: "+ sOption);
                        }*/
                        for (let [sFuncCond, cActionType, sWhat, ...eAct] of lActions) {
                        // action in lActions: [ condition, action type, replacement/suggestion/action[, iGroup[, message, URL]] ]
                            try {
                                //echo(oEvalFunc[sFuncCond]);
                                bCondMemo = (!sFuncCond || oEvalFunc[sFuncCond](s, sx, m, dDA, sCountry, bCondMemo))
                                if (bCondMemo) {
                                    switch (cActionType) {
                                        case "-":
                                            // grammar error
                                            //echo("-> error detected in " + sLineId + "\nzRegex: " + zRegex.source);
                                            nErrorStart = nOffset + m.start[eAct[0]];
                                            if (!dErrs.has(nErrorStart) || nPriority > dPriority.get(nErrorStart)) {
                                                dErrs.set(nErrorStart, _createError(s, sWhat, nOffset, m, eAct[0], sLineId, sRuleId, bUppercase, eAct[1], eAct[2], bIdRule, sOption));
                                                dPriority.set(nErrorStart, nPriority);
                                            }
                                            break;
                                        case "~":
                                            // text processor
                                            //echo("-> text processor by " + sLineId + "\nzRegex: " + zRegex.source);
                                            s = _rewrite(s, sWhat, eAct[0], m, bUppercase);
                                            bChange = true;
                                            if (bDebug) {
                                                echo("~ " + s + "  -- " + m[eAct[0]] + "  # " + sLineId);
                                            }
                                            break;
                                        case "=":
                                            // disambiguation
                                            //echo("-> disambiguation by " + sLineId + "\nzRegex: " + zRegex.source);
                                            oEvalFunc[sWhat](s, m, dDA);
                                            if (bDebug) {
                                                echo("= " + m[0] + "  # " + sLineId + "\nDA: " + dDA._toString());
                                            }
                                            break;
                                        case ">":
                                            // we do nothing, this test is just a condition to apply all following actions
                                            break;
                                        default:
                                            echo("# error: unknown action at " + sLineId);
                                    }
                                } else {
                                    if (cActionType == ">") {
                                        break;
                                    }
                                }
                            }
                            catch (e) {
                                echo(s);
                                echo("# id-rule:" + sLineId);
                                helpers.logerror(e);
                            }
                        }
                    }
                }
            }
        }
    }
    if (bChange) {
        return [s, dErrs];
    }
    return [false, dErrs];
}

function _createError (s, sRepl, nOffset, m, iGroup, sLineId, sRuleId, bUppercase, sMsg, sURL, bIdRule, sOption) {
    let oErr = {};
    oErr["nStart"] = nOffset + m.start[iGroup];
    oErr["nEnd"] = nOffset + m.end[iGroup];
    oErr["sLineId"] = sLineId;
    oErr["sRuleId"] = sRuleId;
    oErr["sType"] = (sOption) ? sOption : "notype";
    // suggestions
    if (sRepl[0] === "=") {
        let sugg = oEvalFunc[sRepl.slice(1)](s, m);
        if (sugg) {
            if (bUppercase && m[iGroup].slice(0,1)._isUpperCase()) {
                oErr["aSuggestions"] = capitalizeArray(sugg.split("|"));
            } else {
                oErr["aSuggestions"] = sugg.split("|");
            }
        } else {
            oErr["aSuggestions"] = [];
        }
    } else if (sRepl == "_") {
        oErr["aSuggestions"] = [];
    } else {
        if (bUppercase && m[iGroup].slice(0,1)._isUpperCase()) {
            oErr["aSuggestions"] = capitalizeArray(sRepl._expand(m).split("|"));
        } else {
            oErr["aSuggestions"] = sRepl._expand(m).split("|");
        }
    }
    // Message
    if (sMsg[0] === "=") {
        sMessage = oEvalFunc[sMsg.slice(1)](s, m)
    } else {
        sMessage = sMsg._expand(m);
    }
    if (bIdRule) {
        sMessage += "  #" + sLineId + " #" + sRuleId;
    }
    oErr["sMessage"] = sMessage;
    // URL
    oErr["URL"] = sURL || "";
    return oErr;
}

function _rewrite (s, sRepl, iGroup, m, bUppercase) {
    // text processor: write sRepl in s at iGroup position"
    let ln = m.end[iGroup] - m.start[iGroup];
    let sNew = "";
    if (sRepl === "*") {
        sNew = " ".repeat(ln);
    } else if (sRepl === ">" || sRepl === "_" || sRepl === "~") {
        sNew = sRepl + " ".repeat(ln-1);
    } else if (sRepl === "@") {
        sNew = "@".repeat(ln);
    } else if (sRepl.slice(0,1) === "=") {
        sNew = oEvalFunc[sRepl.slice(1)](s, m);
        sNew = sNew + " ".repeat(ln-sNew.length);
        if (bUppercase && m[iGroup].slice(0,1)._isUpperCase()) {
            sNew = sNew._toCapitalize();
        }
    } else {
        sNew = sRepl._expand(m);
        sNew = sNew + " ".repeat(ln-sNew.length);
    }
    //echo("\n"+s+"\nstart: "+m.start[iGroup]+" end:"+m.end[iGroup])
    return s.slice(0, m.start[iGroup]) + sNew + s.slice(m.end[iGroup]);
}

function ignoreRule (sRuleId) {
    _aIgnoredRules.add(sRuleId);
}

function resetIgnoreRules () {
    _aIgnoredRules.clear();
}

function reactivateRule (sRuleId) {
    _aIgnoredRules.delete(sRuleId);
}

function listRules (sFilter=null) {
    // generator: returns tuple (sOption, sLineId, sRuleId)
    try {
        for ([sOption, lRuleGroup] of _getRules(true)) {
            for ([_, _, sLineId, sRuleId, _, _] of lRuleGroup) {
                if (!sFilter || sRuleId.test(sFilter)) {
                    yield [sOption, sLineId, sRuleId];
                }
            }
        }
        for ([sOption, lRuleGroup] of _getRules(false)) {
            for ([_, _, sLineId, sRuleId, _, _] of lRuleGroup) {
                if (!sFilter || sRuleId.test(sFilter)) {
                    yield [sOption, sLineId, sRuleId];
                }
            }
        }
    }
    catch (e) {
        helpers.logerror(e);
    }
}


//////// init

function load () {
    try {
        _oDict = new ibdawg.IBDAWG("French.json");
    }
    catch (e) {
        helpers.logerror(e);
    }
}

function setOption (sOpt, bVal) {
    if (_dOptions.has(sOpt)) {
        _dOptions.set(sOpt, bVal);
    }
}

function setOptions (dOpt) {
    _dOptions._update(dOpt)
}

function getOptions () {
    return _dOptions;
}

function resetOptions () {
    _dOptions = gc_options.dOpt._shallowCopy();
}

function getDictionary () {
    return _oDict;
}

function _getRules (bParagraph) {
    if (!bParagraph) {
        return _rules.lSentenceRules;
    }
    return _rules.lParagraphRules;
}



//////// common functions

function option (sOpt) {
    // return true if option sOpt is active
    return _dOptions.get(sOpt);
}

function displayInfo (dDA, aWord) {
    // for debugging: info of word
    if (!aWord) {
        echo("> nothing to find");
        return true;
    }
    if (!_dAnalyses.has(aWord[1]) && !_storeMorphFromFSA(aWord[1])) {
        echo("> not in FSA");
        return true;
    }
    if (dDA.has(aWord[0])) {
        echo("DA: " + dDA.get(aWord[0]));
    }
    echo("FSA: " + _dAnalyses.get(aWord[1]));
    return true;
}

function _storeMorphFromFSA (sWord) {
    // retrieves morphologies list from _oDict -> _dAnalyses
    //echo("register: "+sWord + " " + _oDict.getMorph(sWord).toString())
    _dAnalyses.set(sWord, _oDict.getMorph(sWord));
    return !!_dAnalyses.get(sWord);
}

function morph (dDA, aWord, sPattern, bStrict=true, bNoWord=false) {
    // analyse a tuple (position, word), return true if sPattern in morphologies (disambiguation on)
    if (!aWord) {
        //echo("morph: noword, returns " + bNoWord);
        return bNoWord;
    }
    //echo("aWord: "+aWord.toString());
    if (!_dAnalyses.has(aWord[1]) && !_storeMorphFromFSA(aWord[1])) {
        return false;
    }
    let lMorph = dDA.has(aWord[0]) ? dDA.get(aWord[0]) : _dAnalyses.get(aWord[1]);
    //echo("lMorph: "+lMorph.toString());
    if (lMorph.length === 0) {
        return false;
    }
    //echo("***");
    if (bStrict) {
        return lMorph.every(s  =>  (s.search(sPattern) !== -1));
    }
    return lMorph.some(s  =>  (s.search(sPattern) !== -1));
}

function morphex (dDA, aWord, sPattern, sNegPattern, bNoWord=false) {
    // analyse a tuple (position, word), returns true if not sNegPattern in word morphologies and sPattern in word morphologies (disambiguation on)
    if (!aWord) {
        //echo("morph: noword, returns " + bNoWord);
        return bNoWord;
    }
    //echo("aWord: "+aWord.toString());
    if (!_dAnalyses.has(aWord[1]) && !_storeMorphFromFSA(aWord[1])) {
        return false;
    }
    let lMorph = dDA.has(aWord[0]) ? dDA.get(aWord[0]) : _dAnalyses.get(aWord[1]);
    //echo("lMorph: "+lMorph.toString());
    if (lMorph.length === 0) {
        return false;
    }
    //echo("***");
    // check negative condition
    if (lMorph.some(s  =>  (s.search(sNegPattern) !== -1))) {
        return false;
    }
    // search sPattern
    return lMorph.some(s  =>  (s.search(sPattern) !== -1));
}

function analyse (sWord, sPattern, bStrict=true) {
    // analyse a word, return true if sPattern in morphologies (disambiguation off)
    if (!_dAnalyses.has(sWord) && !_storeMorphFromFSA(sWord)) {
        return false;
    }
    if (bStrict) {
        return _dAnalyses.get(sWord).every(s  =>  (s.search(sPattern) !== -1));
    }
    return _dAnalyses.get(sWord).some(s  =>  (s.search(sPattern) !== -1));
}

function analysex (sWord, sPattern, sNegPattern) {
    // analyse a word, returns True if not sNegPattern in word morphologies and sPattern in word morphologies (disambiguation off)
    if (!_dAnalyses.has(sWord) && !_storeMorphFromFSA(sWord)) {
        return false;
    }
    // check negative condition
    if (_dAnalyses.get(sWord).some(s  =>  (s.search(sNegPattern) !== -1))) {
        return false;
    }
    // search sPattern
    return _dAnalyses.get(sWord).some(s  =>  (s.search(sPattern) !== -1));
}

function stem (sWord) {
    // returns a list of sWord's stems
    if (!sWord) {
        return [];
    }
    if (!_dAnalyses.has(sWord) && !_storeMorphFromFSA(sWord)) {
        return [];
    }
    return [ for (s of _dAnalyses.get(sWord))  s.slice(1, s.indexOf(" ")) ];
}


//// functions to get text outside pattern scope

// warning: check compile_rules.py to understand how it works

function nextword (s, iStart, n) {
    // get the nth word of the input string or empty string
    let z = new RegExp("^( +[a-zà-öA-Zø-ÿÀ-Ö0-9Ø-ßĀ-ʯﬁ-ﬆ%_-]+){" + (n-1).toString() + "} +([a-zà-öA-Zø-ÿÀ-Ö0-9Ø-ßĀ-ʯﬁ-ﬆ%_-]+)", "i");
    let m = z.exec(s.slice(iStart));
    if (!m) {
        return null;
    }
    return [iStart + RegExp.lastIndex - m[2].length, m[2]];
}

function prevword (s, iEnd, n) {
    // get the (-)nth word of the input string or empty string
    let z = new RegExp("([a-zà-öA-Zø-ÿÀ-Ö0-9Ø-ßĀ-ʯﬁ-ﬆ%_-]+) +([a-zà-öA-Zø-ÿÀ-Ö0-9Ø-ßĀ-ʯﬁ-ﬆ%_-]+ +){" + (n-1).toString() + "}$", "i");
    let m = z.exec(s.slice(0, iEnd));
    if (!m) {
        return null;
    }
    return [m.index, m[1]];
}

const _zNextWord = new RegExp ("^ +([a-zà-öA-Zø-ÿÀ-Ö0-9Ø-ßĀ-ʯﬁ-ﬆ_][a-zà-öA-Zø-ÿÀ-Ö0-9Ø-ßĀ-ʯﬁ-ﬆ_-]*)", "i");
const _zPrevWord = new RegExp ("([a-zà-öA-Zø-ÿÀ-Ö0-9Ø-ßĀ-ʯﬁ-ﬆ_][a-zà-öA-Zø-ÿÀ-Ö0-9Ø-ßĀ-ʯﬁ-ﬆ_-]*) +$", "i");

function nextword1 (s, iStart) {
    // get next word (optimization)
    let m = _zNextWord.exec(s.slice(iStart));
    if (!m) {
        return null;
    }
    return [iStart + RegExp.lastIndex - m[1].length, m[1]];
}

function prevword1 (s, iEnd) {
    // get previous word (optimization)
    //echo("prev1, s:"+s);
    //echo("prev1, s.slice(0, iEnd):"+s.slice(0, iEnd));
    let m = _zPrevWord.exec(s.slice(0, iEnd));
    //echo("prev1, m:"+m);
    if (!m) {
        return null;
    }
    //echo("prev1: " + m.index + " " + m[1]);
    return [m.index, m[1]];
}

function look (s, zPattern, zNegPattern=null) {
    // seek zPattern in s (before/after/fulltext), if antipattern zNegPattern not in s
    try {
        if (zNegPattern && zNegPattern.test(s)) {
            return false;
        }
        return zPattern.test(s);
    }
    catch (e) {
        helpers.logerror(e);
    }
    return false;
}

function look_chk1 (dDA, s, nOffset, zPattern, sPatternGroup1, sNegPatternGroup1=null) {
    // returns True if s has pattern zPattern and m.group(1) has pattern sPatternGroup1
    let m = zPattern._exec2(s, null);
    if (!m) {
        return false;
    }
    try {
        let sWord = m[1];
        let nPos = m.start[1] + nOffset;
        if (sNegPatternGroup1) {
            return morphex(dDA, [nPos, sWord], sPatternGroup1, sNegPatternGroup1);
        } 
        return morph(dDA, [nPos, sWord], sPatternGroup1, false);
    }
    catch (e) {
        helpers.logerror(e);
        return false;
    }
}


//////// Disambiguator

function select (dDA, nPos, sWord, sPattern, lDefault=null) {
    if (!sWord) {
        return true;
    }
    if (dDA.has(nPos)) {
        return true;
    }
    if (!_dAnalyses.has(sWord) && !_storeMorphFromFSA(sWord)) {
        return true;
    }
    //echo("morph: "+_dAnalyses.get(sWord).toString());
    if (_dAnalyses.get(sWord).length === 1) {
        return true;
    }
    let lSelect = [ for (sMorph of _dAnalyses.get(sWord))  if (sMorph.search(sPattern) !== -1)  sMorph ];
    //echo("lSelect: "+lSelect.toString());
    if (lSelect.length > 0) {
        if (lSelect.length != _dAnalyses.get(sWord).length) {
            dDA.set(nPos, lSelect);
        }
    } else if (lDefault) {
        dDA.set(nPos, lDefaul);
    }
    return true;
}

function exclude (dDA, nPos, sWord, sPattern, lDefault=null) {
    if (!sWord) {
        return true;
    }
    if (dDA.has(nPos)) {
        return true;
    }
    if (!_dAnalyses.has(sWord) && !_storeMorphFromFSA(sWord)) {
        return true;
    }
    if (_dAnalyses.get(sWord).length === 1) {
        return true;
    }
    let lSelect = [ for (sMorph of _dAnalyses.get(sWord))  if (sMorph.search(sPattern) === -1)  sMorph ];
    //echo("lSelect: "+lSelect.toString());
    if (lSelect.length > 0) {
        if (lSelect.length != _dAnalyses.get(sWord).length) {
            dDA.set(nPos, lSelect);
        }
    } else if (lDefault) {
        dDA.set(nPos, lDefault);
    }
    return true;
}

function define (dDA, nPos, lMorph) {
    dDA.set(nPos, lMorph);
    return true;
}

//////// GRAMMAR CHECKER PLUGINS



//// GRAMMAR CHECKING ENGINE PLUGIN: Parsing functions for French language

function rewriteSubject (s1, s2) {
    // s1 is supposed to be prn/patr/npr (M[12P])
    if (s2 == "lui") {
        return "ils";
    }
    if (s2 == "moi") {
        return "nous";
    }
    if (s2 == "toi") {
        return "vous";
    }
    if (s2 == "nous") {
        return "nous";
    }
    if (s2 == "vous") {
        return "vous";
    }
    if (s2 == "eux") {
        return "ils";
    }
    if (s2 == "elle" || s2 == "elles") {
        // We don’t check if word exists in _dAnalyses, for it is assumed it has been done before
        if (cr.mbNprMasNotFem(_dAnalyses._get(s1, ""))) {
            return "ils";
        }
        // si épicène, indéterminable, mais OSEF, le féminin l’emporte
        return "elles";
    }
    return s1 + " et " + s2;
}

function apposition (sWord1, sWord2) {
    // returns true if nom + nom (no agreement required)
    // We don’t check if word exists in _dAnalyses, for it is assumed it has been done before
    return cr.mbNomNotAdj(_dAnalyses._get(sWord2, "")) && cr.mbPpasNomNotAdj(_dAnalyses._get(sWord1, ""));
}

function isAmbiguousNAV (sWord) {
    // words which are nom|adj and verb are ambiguous (except être and avoir)
    if (!_dAnalyses.has(sWord) && !_storeMorphFromFSA(sWord)) {
        return false;
    }
    if (!cr.mbNomAdj(_dAnalyses._get(sWord, "")) || sWord == "est") {
        return false;
    }
    if (cr.mbVconj(_dAnalyses._get(sWord, "")) && !cr.mbMG(_dAnalyses._get(sWord, ""))) {
        return true;
    }
    return false;
}

function isAmbiguousAndWrong (sWord1, sWord2, sReqMorphNA, sReqMorphConj) {
    //// use it if sWord1 won’t be a verb; word2 is assumed to be true via isAmbiguousNAV
    // We don’t check if word exists in _dAnalyses, for it is assumed it has been done before
    let a2 = _dAnalyses._get(sWord2, null);
    if (!a2 || a2.length === 0) {
        return false;
    }
    if (cr.checkConjVerb(a2, sReqMorphConj)) {
        // verb word2 is ok
        return false;
    }
    let a1 = _dAnalyses._get(sWord1, null);
    if (!a1 || a1.length === 0) {
        return false;
    }
    if (cr.checkAgreement(a1, a2) && (cr.mbAdj(a2) || cr.mbAdj(a1))) {
        return false;
    }
    return true;
}

function isVeryAmbiguousAndWrong (sWord1, sWord2, sReqMorphNA, sReqMorphConj, bLastHopeCond) {
    //// use it if sWord1 can be also a verb; word2 is assumed to be true via isAmbiguousNAV
    // We don’t check if word exists in _dAnalyses, for it is assumed it has been done before
    let a2 = _dAnalyses._get(sWord2, null)
    if (!a2 || a2.length === 0) {
        return false;
    }
    if (cr.checkConjVerb(a2, sReqMorphConj)) {
        // verb word2 is ok
        return false;
    }
    let a1 = _dAnalyses._get(sWord1, null);
    if (!a1 || a1.length === 0) {
        return false;
    }
    if (cr.checkAgreement(a1, a2) && (cr.mbAdj(a2) || cr.mbAdjNb(a1))) {
        return false;
    }
    // now, we know there no agreement, and conjugation is also wrong
    if (cr.isNomAdj(a1)) {
        return true;
    }
    //if cr.isNomAdjVerb(a1): # considered true
    if (bLastHopeCond) {
        return true;
    }
    return false;
}

function checkAgreement (sWord1, sWord2) {
    // We don’t check if word exists in _dAnalyses, for it is assumed it has been done before
    let a2 = _dAnalyses._get(sWord2, null)
    if (!a2 || a2.length === 0) {
        return true;
    }
    let a1 = _dAnalyses._get(sWord1, null);
    if (!a1 || a1.length === 0) {
        return true;
    }
    return cr.checkAgreement(a1, a2);
}

function mbUnit (s) {
    if (/[µ\/⁰¹²³⁴⁵⁶⁷⁸⁹Ωℓ·]/.test(s)) {
        return true;
    }
    if (s.length > 1 && s.length < 16 && s.slice(0, 1)._isLowerCase() && (!s.slice(1)._isLowerCase() || /[0-9]/.test(s))) {
        return true;
    }
    return false;
}


//// Syntagmes

const _zEndOfNG1 = new RegExp ("^ +(?:, +|)(?:n(?:’|e |o(?:u?s|tre) )|l(?:’|e(?:urs?|s|) |a )|j(?:’|e )|m(?:’|es? |a |on )|t(?:’|es? |a |u )|s(?:’|es? |a )|c(?:’|e(?:t|tte|s|) )|ç(?:a |’)|ils? |vo(?:u?s|tre) )");
const _zEndOfNG2 = new RegExp ("^ +([a-zà-öA-Zø-ÿÀ-Ö0-9_Ø-ßĀ-ʯ][a-zà-öA-Zø-ÿÀ-Ö0-9_Ø-ßĀ-ʯ-]+)");
const _zEndOfNG3 = new RegExp ("^ *, +([a-zà-öA-Zø-ÿÀ-Ö0-9_Ø-ßĀ-ʯ][a-zà-öA-Zø-ÿÀ-Ö0-9_Ø-ßĀ-ʯ-]+)");

function isEndOfNG (dDA, s, iOffset) {
    if (_zEndOfNG1.test(s)) {
        return true;
    }
    let m = _zEndOfNG2._exec2(s, ["$"]);
    if (m && morphex(dDA, [iOffset+m.start[1], m[1]], ":[VR]", ":[NAQP]")) {
        return true;
    }
    m = _zEndOfNG3._exec2(s, ["$"]);
    if (m && !morph(dDA, [iOffset+m.start[1], m[1]], ":[NA]", false)) {
        return true;
    }
    return false;
}


const _zNextIsNotCOD1 = new RegExp ("^ *,");
const _zNextIsNotCOD2 = new RegExp ("^ +(?:[mtsnj](e +|’)|[nv]ous |tu |ils? |elles? )");
const _zNextIsNotCOD3 = new RegExp ("^ +([a-zéèî][a-zà-öA-Zø-ÿÀ-ÖØ-ßĀ-ʯ-]+)");

function isNextNotCOD (dDA, s, iOffset) {
    if (_zNextIsNotCOD1.test(s) || _zNextIsNotCOD2.test(s)) {
        return true;
    }
    let m = _zNextIsNotCOD3._exec2(s, ["$"]);
    if (m && morphex(dDA, [iOffset+m.start[1], m[1]], ":[123][sp]", ":[DM]")) {
        return true;
    }
    return false;
}


const _zNextIsVerb1 = new RegExp ("^ +[nmts](?:e |’)");
const _zNextIsVerb2 = new RegExp ("^ +([a-zà-öA-Zø-ÿÀ-Ö0-9_Ø-ßĀ-ʯ][a-zà-öA-Zø-ÿÀ-Ö0-9_Ø-ßĀ-ʯ-]+)");

function isNextVerb (dDA, s, iOffset) {
    if (_zNextIsVerb1.test(s)) {
        return true;
    }
    let m = _zNextIsVerb2._exec2(s, ["$"]);
    if (m && morph(dDA, [iOffset+m.start[1], m[1]], ":[123][sp]", false)) {
        return true;
    }
    return false;
}


//// Exceptions

const aREGULARPLURAL = new Set(["abricot", "amarante", "aubergine", "acajou", "anthracite", "brique", "caca", "café",
                                "carotte", "cerise", "chataigne", "corail", "citron", "crème", "grave", "groseille",
                                "jonquille", "marron", "olive", "pervenche", "prune", "sable"]);
const aSHOULDBEVERB = new Set(["aller", "manger"]);


//// GRAMMAR CHECKING ENGINE PLUGIN

// Check date validity

// WARNING: when creating a Date, month must be between 0 and 11


const _lDay = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
const _dMonth = new Map ([
    ["janvier", 1], ["février", 2], ["mars", 3], ["avril", 4], ["mai", 5], ["juin", 6], ["juillet", 7],
    ["août", 8], ["aout", 8], ["septembre", 9], ["octobre", 10], ["novembre", 11], ["décembre", 12]
]);
const _dDaysInMonth = new Map ([
    [1, 31], [2, 28], [3, 31], [4, 30], [5, 31], [6, 30], [7, 31],
    [8, 31], [8, 31], [9, 30], [10, 31], [11, 30], [12, 31]
]);

function _checkDate (nDay, nMonth, nYear) {
    // returns true or false
    if (nMonth > 12 || nMonth < 1 || nDay > 31 || nDay < 1) {
        return false;
    }
    if (nDay <= _dDaysInMonth.get(nMonth)) {
        return true;
    }
    if (nDay === 29) {
        // leap years, http://jsperf.com/ily/15
        return !(nYear & 3 || !(nYear % 25) && nYear & 15);
    }
    return false;
}

function checkDate (sDay, sMonth, sYear) {
    // to use if sMonth is a number
    return _checkDate(parseInt(sDay, 10), parseInt(sMonth, 10), parseInt(sYear, 10));
}

function checkDateWithString (sDay, sMonth, sYear) {
    // to use if sMonth is a noun
    return _checkDate(parseInt(sDay, 10), _dMonth.get(sMonth.toLowerCase()), parseInt(sYear, 10));
}

function checkDay (sWeekday, sDay, sMonth, sYear) {
    // to use if sMonth is a number
    if (checkDate(sDay, sMonth, sYear)) {
        let oDate = new Date(parseInt(sYear, 10), parseInt(sMonth, 10)-1, parseInt(sDay, 10));
        if (_lDay[oDate.getDay()] != sWeekday.toLowerCase()) {
            return false;
        }
        return true;
    }
    return false;
}

function checkDayWithString (sWeekday, sDay, sMonth, sYear) {
    // to use if sMonth is a noun
    if (checkDateWithString(sDay, sMonth, sYear)) {
        let oDate = new Date(parseInt(sYear, 10), _dMonth.get(sMonth.toLowerCase())-1, parseInt(sDay, 10));
        if (_lDay[oDate.getDay()] != sWeekday.toLowerCase()) {
            return false;
        }
        return true;
    }
    return false;
}

function getDay (sDay, sMonth, sYear) {
    // to use if sMonth is a number
    let oDate = new Date(parseInt(sYear, 10), parseInt(sMonth, 10)-1, parseInt(sDay, 10));
    return _lDay[oDate.getDay()];
}

function getDayWithString (sDay, sMonth, sYear) {
    // to use if sMonth is a noun
    let oDate = new Date(parseInt(sYear, 10), _dMonth.get(sMonth.toLowerCase())-1, parseInt(sDay, 10));
    return _lDay[oDate.getDay()];
}


//// GRAMMAR CHECKING ENGINE PLUGIN: Suggestion mechanisms

const conj = require("resource://grammalecte/fr/conj.js");
const mfsp = require("resource://grammalecte/fr/mfsp.js");
const phonet = require("resource://grammalecte/fr/phonet.js");


//// verbs

function suggVerb (sFlex, sWho, funcSugg2=null) {
    // we don’t check if word exists in _dAnalyses, for it is assumed it has been done before
    let aSugg = new Set();
    for (let sStem of stem(sFlex)) {
        let tTags = conj._getTags(sStem);
        if (tTags) {
            // we get the tense
            let aTense = new Set();
            for (let sMorph of _dAnalyses._get(sFlex, [])) {
                let m;
                let zVerb = new RegExp (sStem+" .*?(:(?:Y|I[pqsf]|S[pq]|K))", "g");
                while (m = zVerb.exec(sMorph)) {
                    // stem must be used in regex to prevent confusion between different verbs (e.g. sauras has 2 stems: savoir and saurer)
                    if (m) {
                        if (m[1] === ":Y") {
                            aTense.add(":Ip");
                            aTense.add(":Iq");
                            aTense.add(":Is");
                        } else if (m[1] === ":P") {
                            aTense.add(":Ip");
                        } else {
                            aTense.add(m[1]);
                        }
                    }
                }
            }
            for (let sTense of aTense) {
                if (sWho === ":1ś" && !conj._hasConjWithTags(tTags, sTense, ":1ś")) {
                    sWho = ":1s";
                }
                if (conj._hasConjWithTags(tTags, sTense, sWho)) {
                    aSugg.add(conj._getConjWithTags(sStem, tTags, sTense, sWho));
                }
            }
        }
    }
    if (funcSugg2) {
        let aSugg2 = funcSugg2(sFlex);
        if (aSugg2.size > 0) {
            aSugg.add(aSugg2);
        }
    }
    if (aSugg.size > 0) {
        return Array.from(aSugg).join("|");
    }
    return "";
}

function suggVerbPpas (sFlex, sWhat=null) {
    let aSugg = new Set();
    for (let sStem of stem(sFlex)) {
        let tTags = conj._getTags(sStem);
        if (tTags) {
            if (!sWhat) {
                aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q1"));
                aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q2"));
                aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q3"));
                aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q4"));
                aSugg.delete("");
            } else if (sWhat === ":m:s") {
                aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q1"));
            } else if (sWhat === ":m:p") {
                if (conj._hasConjWithTags(tTags, ":PQ", ":Q2")) {
                    aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q2"));
                } else {
                    aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q1"));
                }
            } else if (sWhat === ":f:s") {
                if (conj._hasConjWithTags(tTags, ":PQ", ":Q3")) {
                    aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q3"));
                } else {
                    aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q1"));
                }
            } else if (sWhat === ":f:p") {
                if (conj._hasConjWithTags(tTags, ":PQ", ":Q4")) {
                    aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q4"));
                } else {
                    aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q1"));
                }
            } else if (sWhat === ":s") {
                aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q1"));
                aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q3"));
                aSugg.delete("");
            } else if (sWhat === ":p") {
                aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q2"));
                aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q4"));
                aSugg.delete("");
            } else {
                aSugg.add(conj._getConjWithTags(sStem, tTags, ":PQ", ":Q1"));
            }
        }
    }
    if (aSugg.size > 0) {
        return Array.from(aSugg).join("|");
    }
    return "";
}

function suggVerbTense (sFlex, sTense, sWho) {
    let aSugg = new Set();
    for (let sStem of stem(sFlex)) {
        if (conj.hasConj(sStem, sTense, sWho)) {
            aSugg.add(conj.getConj(sStem, sTense, sWho));
        }
    }
    if (aSugg.size > 0) {
        return Array.from(aSugg).join("|");
    }
    return "";
}

function suggVerbImpe (sFlex) {
    let aSugg = new Set();
    for (let sStem of stem(sFlex)) {
        let tTags = conj._getTags(sStem);
        if (tTags) {
            if (conj._hasConjWithTags(tTags, ":E", ":2s")) {
                aSugg.add(conj._getConjWithTags(sStem, tTags, ":E", ":2s"));
            }
            if (conj._hasConjWithTags(tTags, ":E", ":1p")) {
                aSugg.add(conj._getConjWithTags(sStem, tTags, ":E", ":1p"));
            }
            if (conj._hasConjWithTags(tTags, ":E", ":2p")) {
                aSugg.add(conj._getConjWithTags(sStem, tTags, ":E", ":2p"));
            }
        }
    }
    if (aSugg.size > 0) {
        return Array.from(aSugg).join("|");
    }
    return "";
}

function suggVerbInfi (sFlex) {
    //return stem(sFlex).join("|");
    return [ for (sStem of stem(sFlex)) if (conj.isVerb(sStem)) sStem ].join("|");
}


const _dQuiEst = new Map ([
    ["je", ":1s"], ["j’", ":1s"], ["j’en", ":1s"], ["j’y", ":1s"],
    ["tu", ":2s"], ["il", ":3s"], ["on", ":3s"], ["elle", ":3s"],
    ["nous", ":1p"], ["vous", ":2p"], ["ils", ":3p"], ["elles", ":3p"]
]);
const _lIndicatif = [":Ip", ":Iq", ":Is", ":If"];
const _lSubjonctif = [":Sp", ":Sq"];

function suggVerbMode (sFlex, cMode, sSuj) {
    let lMode;
    if (cMode == ":I") {
        lMode = _lIndicatif;
    } else if (cMode == ":S") {
        lMode = _lSubjonctif;
    } else if (cMode.startsWith(":I") || cMode.startsWith(":S")) {
        lMode = [cMode];
    } else {
        return "";
    }
    let sWho = _dQuiEst._get(sSuj.toLowerCase(), null);
    if (!sWho) {
        if (sSuj[0]._isLowerCase()) { // pas un pronom, ni un nom propre
            return "";
        }
        sWho = ":3s";
    }
    let aSugg = new Set();
    for (let sStem of stem(sFlex)) {
        let tTags = conj._getTags(sStem);
        if (tTags) {
            for (let sTense of lMode) {
                if (conj._hasConjWithTags(tTags, sTense, sWho)) {
                    aSugg.add(conj._getConjWithTags(sStem, tTags, sTense, sWho));
                }
            }
        }
    }
    if (aSugg.size > 0) {
        return Array.from(aSugg).join("|");
    }
    return "";
}

//// Nouns and adjectives

function suggPlur (sFlex, sWordToAgree=null) {
    // returns plural forms assuming sFlex is singular
    if (sWordToAgree) {
        if (!_dAnalyses.has(sWordToAgree) && !_storeMorphFromFSA(sWordToAgree)) {
            return "";
        }
        let sGender = cr.getGender(_dAnalyses._get(sWordToAgree, []));
        if (sGender == ":m") {
            return suggMasPlur(sFlex);
        } else if (sGender == ":f") {
            return suggFemPlur(sFlex);
        }
    }
    let aSugg = new Set();
    if (!sFlex.includes("-")) {
        if (sFlex.endsWith("l")) {
            if (sFlex.endsWith("al") && sFlex.length > 2 && _oDict.isValid(sFlex.slice(0,-1)+"ux")) {
                aSugg.add(sFlex.slice(0,-1)+"ux");
            }
            if (sFlex.endsWith("ail") && sFlex.length > 3 && _oDict.isValid(sFlex.slice(0,-2)+"ux")) {
                aSugg.add(sFlex.slice(0,-2)+"ux");
            }
        }
        if (_oDict.isValid(sFlex+"s")) {
            aSugg.add(sFlex+"s");
        }
        if (_oDict.isValid(sFlex+"x")) {
            aSugg.add(sFlex+"x");
        }
    }
    if (mfsp.hasMiscPlural(sFlex)) {
        mfsp.getMiscPlural(sFlex).forEach(function(x) { aSugg.add(x); });
    }
    if (aSugg.size > 0) {
        return Array.from(aSugg).join("|");
    }
    return "";
}

function suggSing (sFlex) {
    // returns singular forms assuming sFlex is plural
    if (sFlex.includes("-")) {
        return "";
    }
    let aSugg = new Set();
    if (sFlex.endsWith("ux")) {
        if (_oDict.isValid(sFlex.slice(0,-2)+"l")) {
            aSugg.add(sFlex.slice(0,-2)+"l");
        }
        if (_oDict.isValid(sFlex.slice(0,-2)+"il")) {
            aSugg.add(sFlex.slice(0,-2)+"il");
        }
    }
    if (_oDict.isValid(sFlex.slice(0,-1))) {
        aSugg.add(sFlex.slice(0,-1));
    }
    if (aSugg.size > 0) {
        return Array.from(aSugg).join("|");
    }
    return "";
}

function suggMasSing (sFlex, bSuggSimil=false) {
    // returns masculine singular forms
    // we don’t check if word exists in _dAnalyses, for it is assumed it has been done before
    let aSugg = new Set();
    for (let sMorph of _dAnalyses._get(sFlex, [])) {
        if (!sMorph.includes(":V")) {
            // not a verb
            if (sMorph.includes(":m") || sMorph.includes(":e")) {
                aSugg.add(suggSing(sFlex));
            } else {
                let sStem = cr.getLemmaOfMorph(sMorph);
                if (mfsp.isFemForm(sStem)) {
                    mfsp.getMasForm(sStem, false).forEach(function(x) { aSugg.add(x); });
                }
            }
        } else {
            // a verb
            let sVerb = cr.getLemmaOfMorph(sMorph);
            if (conj.hasConj(sVerb, ":PQ", ":Q1") && conj.hasConj(sVerb, ":PQ", ":Q3")) {
                // We also check if the verb has a feminine form.
                // If not, we consider it’s better to not suggest the masculine one, as it can be considered invariable.
                aSugg.add(conj.getConj(sVerb, ":PQ", ":Q1"));
            }
        }
    }
    if (bSuggSimil) {
        for (let e of phonet.selectSimil(sFlex, ":m:[si]")) {
            aSugg.add(e);
        }
    }
    if (aSugg.size > 0) {
        return Array.from(aSugg).join("|");
    }
    return "";
}

function suggMasPlur (sFlex, bSuggSimil=false) {
    // returns masculine plural forms
    // we don’t check if word exists in _dAnalyses, for it is assumed it has been done before
    let aSugg = new Set();
    for (let sMorph of _dAnalyses._get(sFlex, [])) {
        if (!sMorph.includes(":V")) {
            // not a verb
            if (sMorph.includes(":m") || sMorph.includes(":e")) {
                aSugg.add(suggPlur(sFlex));
            } else {
                let sStem = cr.getLemmaOfMorph(sMorph);
                if (mfsp.isFemForm(sStem)) {
                    mfsp.getMasForm(sStem, true).forEach(function(x) { aSugg.add(x); });
                }
            }
        } else {
            // a verb
            let sVerb = cr.getLemmaOfMorph(sMorph);
            if (conj.hasConj(sVerb, ":PQ", ":Q2")) {
                aSugg.add(conj.getConj(sVerb, ":PQ", ":Q2"));
            } else if (conj.hasConj(sVerb, ":PQ", ":Q1")) {
                let sSugg = conj.getConj(sVerb, ":PQ", ":Q1");
                // it is necessary to filter these flexions, like “succédé” or “agi” that are not masculine plural
                if (sSugg.endsWith("s")) {
                    aSugg.add(sSugg);
                }
            }
        }
    }
    if (bSuggSimil) {
        for (let e of phonet.selectSimil(sFlex, ":m:[pi]")) {
            aSugg.add(e);
        }
    }
    if (aSugg.size > 0) {
        return Array.from(aSugg).join("|");
    }
    return "";
}


function suggFemSing (sFlex, bSuggSimil=false) {
    // returns feminine singular forms
    // we don’t check if word exists in _dAnalyses, for it is assumed it has been done before
    let aSugg = new Set();
    for (let sMorph of _dAnalyses._get(sFlex, [])) {
        if (!sMorph.includes(":V")) {
            // not a verb
            if (sMorph.includes(":f") || sMorph.includes(":e")) {
                aSugg.add(suggSing(sFlex));
            } else {
                let sStem = cr.getLemmaOfMorph(sMorph);
                if (mfsp.isFemForm(sStem)) {
                    aSugg.add(sStem);
                }
            }
        } else {
            // a verb
            let sVerb = cr.getLemmaOfMorph(sMorph);
            if (conj.hasConj(sVerb, ":PQ", ":Q3")) {
                aSugg.add(conj.getConj(sVerb, ":PQ", ":Q3"));
            }
        }
    }
    if (bSuggSimil) {
        for (let e of phonet.selectSimil(sFlex, ":f:[si]")) {
            aSugg.add(e);
        }
    }
    if (aSugg.size > 0) {
        return Array.from(aSugg).join("|");
    }
    return "";
}

function suggFemPlur (sFlex, bSuggSimil=false) {
    // returns feminine plural forms
    // we don’t check if word exists in _dAnalyses, for it is assumed it has been done before
    let aSugg = new Set();
    for (let sMorph of _dAnalyses._get(sFlex, [])) {
        if (!sMorph.includes(":V")) {
            // not a verb
            if (sMorph.includes(":f") || sMorph.includes(":e")) {
                aSugg.add(suggPlur(sFlex));
            } else {
                let sStem = cr.getLemmaOfMorph(sMorph);
                if (mfsp.isFemForm(sStem)) {
                    aSugg.add(sStem+"s");
                }
            }
        } else {
            // a verb
            let sVerb = cr.getLemmaOfMorph(sMorph);
            if (conj.hasConj(sVerb, ":PQ", ":Q4")) {
                aSugg.add(conj.getConj(sVerb, ":PQ", ":Q4"));
            }
        }
    }
    if (bSuggSimil) {
        for (let e of phonet.selectSimil(sFlex, ":f:[pi]")) {
            aSugg.add(e);
        }
    }
    if (aSugg.size > 0) {
        return Array.from(aSugg).join("|");
    }
    return "";
}

function hasFemForm (sFlex) {
    for (let sStem of stem(sFlex)) {
        if (mfsp.isFemForm(sStem) || conj.hasConj(sStem, ":PQ", ":Q3")) {
            return true;
        }
    }
    if (phonet.hasSimil(sFlex, ":f")) {
        return true;
    }
    return false;
}

function hasMasForm (sFlex) {
    for (let sStem of stem(sFlex)) {
        if (mfsp.isFemForm(sStem) || conj.hasConj(sStem, ":PQ", ":Q1")) {
            // what has a feminine form also has a masculine form
            return true;
        }
    }
    if (phonet.hasSimil(sFlex, ":m")) {
        return true;
    }
    return false;
}

function switchGender (sFlex, bPlur=null) {
    // we don’t check if word exists in _dAnalyses, for it is assumed it has been done before
    let aSugg = new Set();
    if (bPlur === null) {
        for (let sMorph of _dAnalyses._get(sFlex, [])) {
            if (sMorph.includes(":f")) {
                if (sMorph.includes(":s")) {
                    aSugg.add(suggMasSing(sFlex));
                } else if (sMorph.includes(":p")) {
                    aSugg.add(suggMasPlur(sFlex));
                }
            } else if (sMorph.includes(":m")) {
                if (sMorph.includes(":s")) {
                    aSugg.add(suggFemSing(sFlex));
                } else if (sMorph.includes(":p")) {
                    aSugg.add(suggFemPlur(sFlex));
                } else {
                    aSugg.add(suggFemSing(sFlex));
                    aSugg.add(suggFemPlur(sFlex));
                }
            }
        }
    } else if (bPlur) {
        for (let sMorph of _dAnalyses._get(sFlex, [])) {
            if (sMorph.includes(":f")) {
                aSugg.add(suggMasPlur(sFlex));
            } else if (sMorph.includes(":m")) {
                aSugg.add(suggFemPlur(sFlex));
            }
        }
    } else {
        for (let sMorph of _dAnalyses._get(sFlex, [])) {
            if (sMorph.includes(":f")) {
                aSugg.add(suggMasSing(sFlex));
            } else if (sMorph.includes(":m")) {
                aSugg.add(suggFemSing(sFlex));
            }
        }
    }
    if (aSugg.size > 0) {
        return Array.from(aSugg).join("|");
    }
    return "";
}

function switchPlural (sFlex) {
    let aSugg = new Set();
    for (let sMorph of _dAnalyses._get(sFlex, [])) { // we don’t check if word exists in _dAnalyses, for it is assumed it has been done before
        if (sMorph.includes(":s")) {
            aSugg.add(suggPlur(sFlex));
        } else if (sMorph.includes(":p")) {
            aSugg.add(suggSing(sFlex));
        }
    }
    if (aSugg.size > 0) {
        return Array.from(aSugg).join("|");
    }
    return "";
}

function hasSimil (sWord, sPattern=null) {
    return phonet.hasSimil(sWord, sPattern);
}

function suggSimil (sWord, sPattern) {
    // return list of words phonetically similar to sWord and whom POS is matching sPattern
    let aSugg = phonet.selectSimil(sWord, sPattern);
    for (let sMorph of _dAnalyses._get(sWord, [])) {
        for (let e of conj.getSimil(sWord, sMorph)) {
            aSugg.add(e); 
        }
    }
    if (aSugg.size > 0) {
        return Array.from(aSugg).join("|");
    }
    return "";
}

function suggCeOrCet (sWord) {
    if (/^[aeéèêiouyâîï]/i.test(sWord)) {
        return "cet";
    }
    if (sWord[0] == "h" || sWord[0] == "H") {
        return "ce|cet";
    }
    return "ce";
}

function suggLesLa (sWord) {
    // we don’t check if word exists in _dAnalyses, for it is assumed it has been done before
    if (_dAnalyses._get(sWord, []).some(s  =>  s.includes(":p"))) {
        return "les|la";
    }
    return "la";
}

function formatNumber (s) {
    let nLen = s.length;
    if (nLen == 10) {
        let sRes = s[0] + " " + s.slice(1,4) + " " + s.slice(4,7) + " " + s.slice(7);                       // nombre ordinaire
        if (s.startsWith("0")) {
            sRes += "|" + s.slice(0,2) + " " + s.slice(2,4) + " " + s.slice(4,6) + " " + s.slice(6,8) + " " + s.slice(8);   // téléphone français
            if (s[1] == "4" && (s[2]=="7" || s[2]=="8" || s[2]=="9")) {
                sRes += "|" + s.slice(0,4) + " " + s.slice(4,6) + " " + s.slice(6,8) + " " + s.slice(8);    // mobile belge
            }
            sRes += "|" + s.slice(0,3) + " " + s.slice(3,6) + " " + s.slice(6,8) + " " + s.slice(8);        // téléphone suisse
        }
        sRes += "|" + s.slice(0,4) + " " + s.slice(4,7) + "-" + s.slice(7);                                 // téléphone canadien ou américain
        return sRes;
    } else if (nLen == 9) {
        let sRes = s.slice(0,3) + " " + s.slice(3,6) + " " + s.slice(6);                                    // nombre ordinaire
        if (s.startsWith("0")) {
            sRes += "|" + s.slice(0,3) + " " + s.slice(3,5) + " " + s.slice(5,7) + " " + s.slice(7,9);      // fixe belge 1
            sRes += "|" + s.slice(0,2) + " " + s.slice(2,5) + " " + s.slice(5,7) + " " + s.slice(7,9);      // fixe belge 2
        }
        return sRes;
    } else if (nLen < 4) {
        return "";
    }
    let sRes = "";
    let nEnd = nLen;
    while (nEnd > 0) {
        let nStart = Math.max(nEnd-3, 0);
        sRes = sRes ? s.slice(nStart, nEnd) + " " + sRes : sRes = s.slice(nStart, nEnd);
        nEnd = nEnd - 3;
    }
    return sRes;
}

function formatNF (s) {
    try {
        let m = /NF[  -]?(C|E|P|Q|S|X|Z|EN(?:[  -]ISO|))[  -]?([0-9]+(?:[\/‑-][0-9]+|))/i.exec(s);
        if (!m) {
            return "";
        }
        return "NF " + m[1].toUpperCase().replace(/ /g, " ").replace(/-/g, " ") + " " + m[2].replace(/\//g, "‑").replace(/-/g, "‑");
    }
    catch (e) {
        helpers.logerror(e);
        return "# erreur #";
    }
}

function undoLigature (c) {
    if (c == "ﬁ") {
        return "fi";
    } else if (c == "ﬂ") {
        return "fl";
    } else if (c == "ﬀ") {
        return "ff";
    } else if (c == "ﬃ") {
        return "ffi";
    } else if (c == "ﬄ") {
        return "ffl";
    } else if (c == "ﬅ") {
        return "ft";
    } else if (c == "ﬆ") {
        return "st";
    }
    return "_";
}



// generated code, do not edit
const oEvalFunc = {
    c351p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\w$/);
    },
    c351p_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), /^\w/);
    },
    c355p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\w$/);
    },
    c355p_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), /^\w/);
    },
    p379p_1: function (s, m) {
        return m[1]._toCapitalize();
    },
    p392p_1: function (s, m) {
        return m[1].replace(/\./g, "")+".";
    },
    c393p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[0].search(/^(?:i\.e\.|s\.[tv]\.p\.|e\.g\.|a\.k\.a\.|c\.q\.f\.d\.|b\.a\.|n\.b\.)$/i) >= 0);
    },
    s393p_1: function (s, m) {
        return m[0].replace(/\./g, "").toUpperCase();
    },
    c393p_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0] != "b.a.";
    },
    p393p_2: function (s, m) {
        return m[0].replace(/\./g, "_");
    },
    p397p_1: function (s, m) {
        return m[0].replace(/\./g, "").replace(/-/g,"");
    },
    c399p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^etc/i) >= 0);
    },
    c405p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":M[12]", false) && (morph(dDA, [m.start[3], m[3]], ":(?:M[12]|V)", false) || ! _oDict.isValid(m[3]));
    },
    c406p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":M[12]", false) && look(s.slice(m.end[0]), /^\W+[a-zéèêîïâ]/);
    },
    p408p_1: function (s, m) {
        return m[0].replace(/ /g, "_");
    },
    c417p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1]._isDigit();
    },
    c417p_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo;
    },
    c479p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return option("typo") && ! m[0].endsWith("·e·s");
    },
    c479p_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ]", ":G");
    },
    d479p_2: function (s, m, dDA) {
        return define(dDA, m.start[0], [":N:A:Q:e:i"]);
    },
    c494p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return option("typo") && ! m[0].endsWith("·e");
    },
    c494p_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ]", false);
    },
    d494p_2: function (s, m, dDA) {
        return define(dDA, m.start[0], [":N:A:Q:e:s"]);
    },
    c505p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^(?:etc|[A-Z]|chap|cf|fig|hab|litt|circ|coll|r[eé]f|étym|suppl|bibl|bibliogr|cit|op|vol|déc|nov|oct|janv|juil|avr|sept)$/i) >= 0) && morph(dDA, [m.start[1], m[1]], ":", false) && morph(dDA, [m.start[2], m[2]], ":", false);
    },
    s505p_1: function (s, m) {
        return m[2]._toCapitalize();
    },
    c517p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":[DR]", false);
    },
    c552p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[1]._isDigit();
    },
    c556p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (m[1].length > 1 && ! m[1]._isDigit() && _oDict.isValid(m[1])) || look(s.slice(m.end[0]), /^’/);
    },
    s581p_1: function (s, m) {
        return m[1].slice(0,-1);
    },
    s582p_1: function (s, m) {
        return (m[1].slice(1,3) == "os" ) ? "nᵒˢ"  : "nᵒ";
    },
    c590p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /etc$/i);
    },
    s591p_1: function (s, m) {
        return m[0].replace(/\.\.\./g, "…")._trimRight(".");
    },
    c607p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^(?:etc|[A-Z]|fig|hab|litt|circ|coll|ref|étym|suppl|bibl|bibliogr|cit|vol|déc|nov|oct|janv|juil|avr|sept|pp?)$/) >= 0);
    },
    s631p_1: function (s, m) {
        return ",|" + m[1];
    },
    s632p_1: function (s, m) {
        return ";|" + m[1];
    },
    s633p_1: function (s, m) {
        return ":|" + m[0][1];
    },
    c647p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[3], m[3]], ";S", ":[VCR]") || mbUnit(m[3]) || ! _oDict.isValid(m[3]);
    },
    c652p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (! (m[2].search(/^[0-9][0-9]{1,3}$/) >= 0) && ! _oDict.isValid(m[3])) || morphex(dDA, [m.start[3], m[3]], ";S", ":[VCR]") || mbUnit(m[3]);
    },
    c676p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return sCountry != "CA";
    },
    s676p_1: function (s, m) {
        return " "+m[0];
    },
    c713p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /[a-zA-Zéïîùàâäôö]$/);
    },
    s737p_1: function (s, m) {
        return undoLigature(m[0]);
    },
    s776p_1: function (s, m) {
        return m[1].slice(0,-1)+"’";
    },
    c778p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! option("mapos") && morph(dDA, [m.start[2], m[2]], ":V", false);
    },
    s778p_1: function (s, m) {
        return m[1].slice(0,-1)+"’";
    },
    c782p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return option("mapos") && ! look(s.slice(0,m.index), /(?:lettre|caractère|glyphe|dimension|variable|fonction|point) *$/i);
    },
    s782p_1: function (s, m) {
        return m[1].slice(0,-1)+"’";
    },
    c799p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[2].search(/^(?:onz[ei]|énième|iourte|ouistiti|ouate|one-?step|ouf|Ouagadougou|I(?:I|V|X|er|ᵉʳ|ʳᵉ|è?re))/i) >= 0) && ! m[2]._isUpperCase() && ! morph(dDA, [m.start[2], m[2]], ":G", false);
    },
    s799p_1: function (s, m) {
        return m[1][0]+"’";
    },
    c817p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[2].search(/^(?:onz|énième|ouf|énième|ouistiti|one-?step|I(?:I|V|X|er|ᵉʳ))/i) >= 0) && morph(dDA, [m.start[2], m[2]], ":[me]");
    },
    c826p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[0].search(/^NF (?:C|E|P|Q|S|X|Z|EN(?: ISO|)) [0-9]+(?:‑[0-9]+|)/) >= 0);
    },
    s826p_1: function (s, m) {
        return formatNF(m[0]);
    },
    s835p_1: function (s, m) {
        return m[0].replace(/2/g, "₂").replace(/3/g, "₃").replace(/4/g, "₄");
    },
    c846p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /NF[  -]?(C|E|P|Q|X|Z|EN(?:[  -]ISO|)) */);
    },
    s846p_1: function (s, m) {
        return formatNumber(m[0]);
    },
    c861p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return option("num");
    },
    s861p_1: function (s, m) {
        return m[0].replace(/\./g, " ");
    },
    p861p_2: function (s, m) {
        return m[0].replace(/\./g, "");
    },
    c869p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return option("num");
    },
    s869p_1: function (s, m) {
        return m[0].replace(/ /g, " ");
    },
    p869p_2: function (s, m) {
        return m[0].replace(/ /g, "");
    },
    c881p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! checkDate(m[1], m[2], m[3]) && ! look(s.slice(0,m.index), /\bversions? +$/i);
    },
    p881p_2: function (s, m) {
        return m[0].replace(/\./g, "-").replace(/ /g, "-").replace(/\//g, "-");
    },
    c897p_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":(?:G|V0)|>(?:t(?:antôt|emps|rès)|loin|souvent|parfois|quelquefois|côte|petit|même) ", false) && ! m[1][0]._isUpperCase();
    },
    c897p_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    p915p_1: function (s, m) {
        return m[0].replace(/‑/g, "");
    },
    p916p_1: function (s, m) {
        return m[0].replace(/‑/g, "");
    },
    c978s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^([nv]ous|faire|en|la|lui|donnant|œuvre|h[éoa]|hou|olé|joli|Bora|couvent|dément|sapiens|très|vroum|[0-9]+)$/i) >= 0) && ! ((m[1].search(/^(?:est|une?)$/) >= 0) && look(s.slice(0,m.index), /[’']$/)) && ! (m[1] == "mieux" && look(s.slice(0,m.index), /qui +$/i));
    },
    c994s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! option("ocr");
    },
    s994s_1: function (s, m) {
        return m[0].replace(/O/g, "0");
    },
    c995s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! option("ocr");
    },
    s995s_1: function (s, m) {
        return m[0].replace(/O/g, "0");
    },
    c1016s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! checkDateWithString(m[1], m[2], m[3]);
    },
    c1023s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), /^ +av(?:ant|) +J(?:C|ésus-Christ)/) && ! checkDay(m[1], m[2], m[3], m[4]);
    },
    s1023s_1: function (s, m) {
        return getDay(m[2], m[3], m[4]);
    },
    c1031s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), /^ +av(?:ant|) +J(?:C|ésus-Christ)/) && ! checkDayWithString(m[1], m[2], m[3], m[4]);
    },
    s1031s_1: function (s, m) {
        return getDayWithString(m[2], m[3], m[4]);
    },
    c1079s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[0], m[0]], ":", false);
    },
    c1082s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D", false);
    },
    c1083s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":A", false) && ! morph(dDA, prevword1(s, m.index), ":D", false);
    },
    c1106s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "I";
    },
    c1115s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return _oDict.isValid(m[0].replace(/ /g, "_"));
    },
    p1115s_1: function (s, m) {
        return m[0].replace(/ /g, "_");
    },
    c1184s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return _oDict.isValid(m[1]+"-"+m[2]) && analyse(m[1]+"-"+m[2], ":", false);
    },
    c1192s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[NB]", false);
    },
    c1194s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[NB]", false) && ! nextword1(s, m.end[0]);
    },
    c1203s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":N") && ! (m[1].search(/^(?:aequo|nihilo|cathedra|absurdo|abrupto)/i) >= 0);
    },
    c1211s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ]", false);
    },
    c1217s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":N", ":[AGW]");
    },
    c1226s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ]", ":G");
    },
    c1232s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return _oDict.isValid(m[1]+"-"+m[2]) && analyse(m[1]+"-"+m[2], ":", false);
    },
    c1243s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":N");
    },
    c1243s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":N");
    },
    c1252s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return _oDict.isValid(m[1]+"-"+m[2]) && analyse(m[1]+"-"+m[2], ":", false) && morph(dDA, prevword1(s, m.index), ":D", false, ! Boolean((m[1].search(/^(?:s(?:ans|ous)|non)$/i) >= 0)));
    },
    c1261s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return _oDict.isValid(m[1]+"-"+m[2]) && analyse(m[1]+"-"+m[2], ":N", false) && morph(dDA, prevword1(s, m.index), ":(?:D|V0e)", false, true) && ! (morph(dDA, [m.start[1], m[1]], ":G", false) && morph(dDA, [m.start[2], m[2]], ":[GYB]", false));
    },
    s1272s_1: function (s, m) {
        return m[0].replace(/ /g, "-");
    },
    s1273s_1: function (s, m) {
        return m[0].replace(/ /g, "-");
    },
    s1279s_1: function (s, m) {
        return m[0].replace(/ /g, "-").replace(/si/g, "ci");
    },
    c1283s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, prevword1(s, m.index), ":Cs", false, true);
    },
    s1290s_1: function (s, m) {
        return m[0].replace(/ /g, "-");
    },
    c1296s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! nextword1(s, m.end[0]);
    },
    c1298s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, prevword1(s, m.index), ":G");
    },
    c1303s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return look(s.slice(0,m.index), /\b(?:les?|du|des|un|ces?|[mts]on) +/i);
    },
    s1311s_1: function (s, m) {
        return m[0].replace(/ /g, "-");
    },
    c1312s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! ( morph(dDA, prevword1(s, m.index), ":R", false) && look(s.slice(m.end[0]), /^ +qu[e’]/) );
    },
    c1375s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), /^ +s(?:i |’)/);
    },
    s1444s_1: function (s, m) {
        return m[0].replace(/ /g, "-");
    },
    c1447s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /quatre $/i);
    },
    s1447s_1: function (s, m) {
        return m[0].replace(/ /g, "-").replace(/vingts/g, "vingt");
    },
    s1450s_1: function (s, m) {
        return m[0].replace(/ /g, "-");
    },
    s1453s_1: function (s, m) {
        return m[0].replace(/ /g, "-").replace(/vingts/g, "vingt");
    },
    s1482s_1: function (s, m) {
        return m[0].replace(/-/g, " ");
    },
    c1484s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D", false, false);
    },
    s1485s_1: function (s, m) {
        return m[0].replace(/-/g, " ");
    },
    s1486s_1: function (s, m) {
        return m[0].replace(/-/g, " ");
    },
    s1487s_1: function (s, m) {
        return m[0].replace(/-/g, " ");
    },
    c1500s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":V0|>en ", false);
    },
    c1509s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\bd[eè]s +$/i);
    },
    s1509s_1: function (s, m) {
        return m[0].replace(/ /g, "");
    },
    c1518s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":M", ":G") && ! morph(dDA, [m.start[2], m[2]], ":N", false) && ! prevword1(s, m.index);
    },
    c1530s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":E", false) && morph(dDA, [m.start[3], m[3]], ":M", false);
    },
    c1541s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":Y", false) && morph(dDA, [m.start[2], m[2]], ":M", false) && ! morph(dDA, prevword1(s, m.index), ">à ", false, false);
    },
    c1552s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return option("mapos");
    },
    s1552s_1: function (s, m) {
        return m[1].slice(0,-1)+"’";
    },
    c1561s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[GNAY]", ":(?:Q|3s)|>(?:priori|post[eé]riori|contrario|capella|fortiori) ");
    },
    c1583s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D.*:p|>[a-z]+ièmes ", false, false);
    },
    d1583s_1: function (s, m, dDA) {
        return select(dDA, m.start[0], m[0], ":P");
    },
    c1587s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":(?:O[sp]|X)", false);
    },
    d1587s_1: function (s, m, dDA) {
        return select(dDA, m.start[1], m[1], ":V");
    },
    c1589s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":X", false);
    },
    d1589s_1: function (s, m, dDA) {
        return select(dDA, m.start[1], m[1], ":V");
    },
    d1591s_1: function (s, m, dDA) {
        return select(dDA, m.start[1], m[1], ":V");
    },
    d1593s_1: function (s, m, dDA) {
        return select(dDA, m.start[1], m[1], ":[123][sp]");
    },
    c1595s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":(?:Oo|X)", false);
    },
    d1595s_1: function (s, m, dDA) {
        return select(dDA, m.start[1], m[1], ":[123][sp]");
    },
    c1597s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, prevword1(s, m.index), ":Cs", false, true) && ! morph(dDA, [m.start[1], m[1]], ":(?:Oo|X)", false);
    },
    d1597s_1: function (s, m, dDA) {
        return select(dDA, m.start[1], m[1], ":[123][sp]");
    },
    c1599s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":M") && m[2]._isLowerCase() && morphex(dDA, [m.start[2], m[2]], ":[123][sg]", ":Q") && morph(dDA, [m.start[2], m[2]], ":N", false) && morph(dDA, prevword1(s, m.index), ":Cs", false, true);
    },
    d1599s_1: function (s, m, dDA) {
        return select(dDA, m.start[2], m[2], ":[123][sp]");
    },
    d1602s_1: function (s, m, dDA) {
        return exclude(dDA, m.start[1], m[1], ":E");
    },
    c1607s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":[YD]", false);
    },
    d1607s_1: function (s, m, dDA) {
        return exclude(dDA, m.start[1], m[1], ":V");
    },
    d1609s_1: function (s, m, dDA) {
        return exclude(dDA, m.start[1], m[1], ":V");
    },
    d1611s_1: function (s, m, dDA) {
        return exclude(dDA, m.start[1], m[1], ":V");
    },
    c1613s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":Y", false);
    },
    d1613s_1: function (s, m, dDA) {
        return exclude(dDA, m.start[1], m[1], ":V");
    },
    d1615s_1: function (s, m, dDA) {
        return exclude(dDA, m.start[1], m[1], ":V");
    },
    d1617s_1: function (s, m, dDA) {
        return exclude(dDA, m.start[1], m[1], ":V");
    },
    d1619s_1: function (s, m, dDA) {
        return exclude(dDA, m.start[1], m[1], ":[123][sp]");
    },
    c1636s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return look(s.slice(m.end[0]), /^(?: +[A-ZÉÈÂ(]|…|[.][.]+| *$)/);
    },
    s1645s_1: function (s, m) {
        return m[0].slice(0,-1);
    },
    c1653s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0] == "II";
    },
    c1653s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && ! m[0]._isDigit();
    },
    s1653s_2: function (s, m) {
        return m[0].replace(/O/g, "0").replace(/I/g, "1");
    },
    s1663s_1: function (s, m) {
        return m[0].replace(/a/g, "â").replace(/A/g, "Â");
    },
    s1669s_1: function (s, m) {
        return m[0].replace(/n/g, "");
    },
    c1698s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b([jnlmts]’|il |on |elle )$/i);
    },
    c1704s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b[jn]e +$/i);
    },
    c1722s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":N.*:f:s", false);
    },
    c1728s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D.*:f:[si]");
    },
    c1734s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, nextword1(s, m.end[0]), ">(?:et|o[uù]) ");
    },
    c1745s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[0].search(/^contre$/i) >= 0);
    },
    c1751s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D.*:p", false, false);
    },
    c1752s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D.*:p", false, false);
    },
    s1761s_1: function (s, m) {
        return m[0].replace(/rn/g, "m");
    },
    c1769s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("é") && ! morph(dDA, prevword1(s, m.index), ":D.*:m:[si]", false, false);
    },
    c1769s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("s") && ! morph(dDA, prevword1(s, m.index), ":D.*:m:p", false, false);
    },
    c1779s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("o");
    },
    c1779s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && ! morph(dDA, prevword1(s, m.index), ":D.*:[me]", false, false);
    },
    c1788s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\bau /i);
    },
    c1800s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NA]:[me]:[si]", ":Y");
    },
    c1808s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("e") && ( morph(dDA, prevword1(s, m.index), ":R", false, true) || isNextVerb(dDA, s.slice(m.end[0]), m.end[0]) );
    },
    c1808s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("s") && ( morph(dDA, prevword1(s, m.index), ":R", false, true) || isNextVerb(dDA, s.slice(m.end[0]), m.end[0]) );
    },
    c1823s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /[0-9] +$/);
    },
    c1830s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("l");
    },
    c1830s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo;
    },
    c1856s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! prevword1(s, m.index) && morph(dDA, [m.start[2], m[2]], ":(?:O[on]|3s)", false);
    },
    c1864s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("s");
    },
    c1864s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo;
    },
    c1873s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[0].endsWith("s");
    },
    c1873s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo;
    },
    s1888s_1: function (s, m) {
        return m[0].replace(/o/g, "e");
    },
    c1894s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return look(s.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/i) || ! morph(dDA, [m.start[2], m[2]], ":Y", false);
    },
    c1909s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, nextword1(s, m.end[0]), ";S", false) && ! morph(dDA, prevword1(s, m.index), ":R", false);
    },
    c1920s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0]._isTitle() && look(s.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/i) && morphex(dDA, [m.start[0], m[0]], ":", ":M");
    },
    c1920s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return _oDict.isValid(m[1]);
    },
    c1920s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo;
    },
    c1925s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return look(s.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/i) && morphex(dDA, [m.start[0], m[0]], ":", ":M") && _oDict.isValid(m[1]);
    },
    c1939s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return look(s.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/i);
    },
    s1947s_1: function (s, m) {
        return m[0].replace(/é/g, "e").replace(/É/g, "E").replace(/è/g, "e").replace(/È/g, "E").replace(/1/g, "l");
    },
    c1954s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("e");
    },
    c1954s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && m[0].endsWith("a");
    },
    c1954s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && m[0].endsWith("à");
    },
    c1954s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo;
    },
    c1973s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":(?:V0|N.*:m:[si])", false, false);
    },
    c1986s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D:[me]:p", false, false);
    },
    c1987s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D:(?:m:s|e:p)", false, false);
    },
    c1988s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ">(?:homme|ce|quel|être) ", false, false);
    },
    c1998s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("e") && ! morph(dDA, prevword1(s, m.index), ":D.*:[me]:[si]", false, false);
    },
    c1998s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("s") && ! morph(dDA, prevword1(s, m.index), ":D.*:[me]:[pi]", false, false);
    },
    s2001s_1: function (s, m) {
        return m[0].replace(/è/g, "ê").replace(/È/g, "Ê");
    },
    s2002s_1: function (s, m) {
        return m[0].replace(/é/g, "ê").replace(/É/g, "Ê");
    },
    s2010s_1: function (s, m) {
        return m[0].replace(/l/g, "t").replace(/L/g, "T");
    },
    c2044s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:ne|il|on|elle|je) +$/i) && morph(dDA, [m.start[2], m[2]], ":[NA].*:[me]:[si]", false);
    },
    c2047s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:ne|il|on|elle) +$/i) && morph(dDA, [m.start[2], m[2]], ":[NA].*:[fe]:[si]", false);
    },
    c2050s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:ne|tu) +$/i) && morph(dDA, [m.start[2], m[2]], ":[NA].*:[pi]", false);
    },
    c2066s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("") && ! morph(dDA, prevword1(s, m.index), ":D.*:m:s", false, false);
    },
    c2066s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("x") && ! morph(dDA, prevword1(s, m.index), ":D.*:m:p", false, false);
    },
    c2081s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D.*:m:p", false, false);
    },
    c2087s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D.*:f:s", false, false);
    },
    c2093s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D.*:[me]:p", false, false);
    },
    c2099s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("a") && ! look(s.slice(0,m.index), /sine +$/);
    },
    c2099s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("o") && ! look(s.slice(0,m.index), /statu +$/);
    },
    c2118s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D.*:m:s", false, false);
    },
    c2124s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0].endsWith("s");
    },
    c2124s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo;
    },
    c2139s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:ce|[mts]on|du|un|le) $/i);
    },
    c2151s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return look(s.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/i);
    },
    c2159s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:je|il|elle|on|ne) $/i);
    },
    s2159s_1: function (s, m) {
        return m[0].replace(/è/g, "ê").replace(/È/g, "Ê");
    },
    s2173s_1: function (s, m) {
        return m[0].replace(/a/g, "o").replace(/A/g, "O");
    },
    s2179s_1: function (s, m) {
        return m[0].replace(/n/g, "").replace(/N/g, "U");
    },
    c2185s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":(?:N.*:f:p|V0e.*:3p)", false, false);
    },
    c2193s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:ce|d[eu]|un|quel|leur|le) +/i);
    },
    c2213s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0]._isTitle() && look(s.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/i);
    },
    c2213s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[0], m[0]], ":G", ":M");
    },
    s2213s_2: function (s, m) {
        return m[0].toLowerCase();
    },
    c2213s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && morphex(dDA, [m.start[0], m[0]], ":[123][sp]", ":[MNA]|>Est ");
    },
    s2213s_3: function (s, m) {
        return m[0].toLowerCase();
    },
    c2232s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return look(s.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/i);
    },
    s2232s_1: function (s, m) {
        return m[0].toLowerCase();
    },
    c2241s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[0].search(/[0-9aàAÀyYdlnmtsjcçDLNMTSJCÇ]/) >= 0) && ! look(s.slice(0,m.index), /\d +$/) && ! (m[0]._isUpperCase() && look(sx.slice(m.end[0]), /^\./));
    },
    c2256s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[0] != "<" && m[0] != ">";
    },
    c2269s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D:[me]" ,false, false);
    },
    s2278s_1: function (s, m) {
        return suggSimil(m[2], ":[NA].*:[pi]");
    },
    s2281s_1: function (s, m) {
        return suggSimil(m[2], ":[NA].*:[si]");
    },
    s2284s_1: function (s, m) {
        return suggSimil(m[2], ":[NA].*:[pi]");
    },
    c2312s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^avoir$/i) >= 0) && morph(dDA, [m.start[1], m[1]], ">avoir ", false);
    },
    c2329s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:être|mettre) ", false);
    },
    c2378s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look_chk1(dDA, s.slice(m.end[0]), m.end[0], / [a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+ en ([aeo][a-zû]*)/i, ":V0a");
    },
    c2399s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">abolir ", false);
    },
    c2400s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">acculer ", false);
    },
    c2401s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">achever ", false);
    },
    c2402s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), / +de?\b/);
    },
    c2408s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">avancer ", false);
    },
    c2411s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, prevword1(s, m.index), ":A|>un", false);
    },
    c2415s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">collaborer ", false);
    },
    c2417s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">comparer ", false);
    },
    c2418s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">contraindre ", false);
    },
    c2422s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">enchevêtrer ", false);
    },
    c2423s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">entraider ", false);
    },
    c2429s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">joindre ");
    },
    c2436s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">monter ", false);
    },
    c2447s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">rénov(?:er|ation) ", false);
    },
    c2449s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">réunir ", false);
    },
    c2450s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">recul(?:er|) ", false);
    },
    c2454s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">suffire ", false);
    },
    c2455s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">talonner ", false);
    },
    c2528s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:prévenir|prévoir|prédire|présager|préparer|pressentir|pronostiquer|avertir|devancer|deviner|réserver) ", false);
    },
    c2538s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:ajourner|différer|reporter) ", false);
    },
    c2572s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[3], m[3]], ":[123][sp]", ":[PY]");
    },
    c2572s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[3], m[3]], ":3p", false);
    },
    s2572s_2: function (s, m) {
        return suggVerb(m[2], ":P");
    },
    c2582s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":", ":[GNAWM]");
    },
    s2582s_1: function (s, m) {
        return suggSimil(m[1], ":[NA]");
    },
    c2589s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V.*:(?:Y|[123][sp])", ":[NAQ]") && m[2][0]._isLowerCase();
    },
    s2589s_1: function (s, m) {
        return suggSimil(m[2], ":[NA]:[fe]:[si]");
    },
    c2597s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V.*:(?:Y|[123][sp])", ":N.*:[fe]|:[AW]") && m[2][0]._isLowerCase() || m[2] == "va";
    },
    c2597s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V.*:(?:Y|[123][sp])", ":[NAQ]") && m[2][0]._isLowerCase() && hasSimil(m[2]);
    },
    s2597s_2: function (s, m) {
        return suggSimil(m[2], ":[NA]:[fe]:[si]");
    },
    c2614s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V.*:(?:Y|[123][sp])", ":[NAQ]") && m[2][0]._isLowerCase() && ! (m[2] == "sortir" && (m[1].search(/au/i) >= 0));
    },
    s2614s_1: function (s, m) {
        return suggSimil(m[2], ":[NA]:[me]:[si]");
    },
    c2622s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V.*:(?:Y|[123][sp])", ":[NAQ]:.:[si]|:V0e.*:3[sp]|>devoir") && m[2][0]._isLowerCase() && hasSimil(m[2]);
    },
    s2622s_1: function (s, m) {
        return suggSimil(m[2], ":[NA]:[me]:[si]");
    },
    c2630s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V.*:(?:Y|[123][sp])", ":[NAQ]") && m[2][0]._isLowerCase();
    },
    s2630s_1: function (s, m) {
        return suggSimil(m[2], ":[NA]:.:[si]");
    },
    c2638s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V.*:(?:Y|[123][sp])") && m[1][0]._isLowerCase() && ! prevword1(s, m.index);
    },
    s2638s_1: function (s, m) {
        return suggSimil(m[1], ":[NA]:[me]:[si]");
    },
    c2646s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V.*:(?:Y|[123][sp])", ":[NAQ]") && m[2][0]._isLowerCase() && ! (m[0].search(/^quelques? soi(?:ent|t|s)\b/i) >= 0);
    },
    s2646s_1: function (s, m) {
        return suggSimil(m[2], ":[NA]:.:[pi]");
    },
    c2654s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V.*:(?:Y|[123][sp])", ":[NAQ]") && m[2][0]._isLowerCase();
    },
    s2654s_1: function (s, m) {
        return suggSimil(m[2], ":[NA]:[me]:[pi]");
    },
    c2662s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V.*:(?:Y|[123][sp])", ":[NAQ]") && m[2][0]._isLowerCase();
    },
    s2662s_1: function (s, m) {
        return suggSimil(m[2], ":[NA]:[fe]:[pi]");
    },
    c2670s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[123][sp]", ":[NAQ]");
    },
    s2670s_1: function (s, m) {
        return suggSimil(m[1], ":(?:[NA]:[fe]:[si])");
    },
    c2681s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:[me]", ":[YG]") && m[2][0]._isLowerCase();
    },
    c2681s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[123][sp]", false);
    },
    s2681s_2: function (s, m) {
        return suggSimil(m[2], ":Y");
    },
    c2689s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[123][sp]", ":[NAQ]");
    },
    s2689s_1: function (s, m) {
        return suggSimil(m[1], ":(?:[NA]:.:[si])");
    },
    c2696s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":(?:Y|[123][sp])") && ! look(s.slice(0,m.index), /(?:dont|sauf|un à) +$/i);
    },
    s2696s_1: function (s, m) {
        return suggSimil(m[1], ":[NAQ]:[me]:[si]");
    },
    c2704s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1][0]._isLowerCase() && morph(dDA, [m.start[1], m[1]], ":V.*:[123][sp]");
    },
    s2704s_1: function (s, m) {
        return suggSimil(m[1], ":[NA]");
    },
    c2711s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1][0]._isLowerCase() && morphex(dDA, [m.start[1], m[1]], ":V.*:[123][sp]", ":[GNA]") && ! look(s.slice(0,m.index), /\b(?:plus|moins) +$/i);
    },
    s2711s_1: function (s, m) {
        return suggSimil(m[1], ":[NA]");
    },
    c2721s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":", ":(?:[123][sp]|O[onw]|X)|ou ") && morphex(dDA, prevword1(s, m.index), ":", ":3s", true);
    },
    s2721s_1: function (s, m) {
        return suggSimil(m[1], ":(?:3s|Oo)");
    },
    c2729s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":", ":(?:[123][sp]|O[onw]|X)|ou ") && morphex(dDA, prevword1(s, m.index), ":", ":3p", true);
    },
    s2729s_1: function (s, m) {
        return suggSimil(m[1], ":(?:3p|Oo)");
    },
    c2738s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":", ":(?:[123][sp]|O[onw]|X)") && morphex(dDA, prevword1(s, m.index), ":", ":1s", true);
    },
    s2738s_1: function (s, m) {
        return suggSimil(m[1], ":(?:1s|Oo)");
    },
    c2746s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":", ":(?:[123][sp]|O[onw]|X)") && morphex(dDA, prevword1(s, m.index), ":", ":(?:2s|V0e)", true);
    },
    s2746s_1: function (s, m) {
        return suggSimil(m[1], ":(?:2s|Oo)");
    },
    c2761s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":", ":P");
    },
    c2762s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ]");
    },
    c2772s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":", ":(?:[123][sp]|O[onw])");
    },
    s2772s_1: function (s, m) {
        return suggSimil(m[2], ":1s");
    },
    c2776s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":", ":(?:[123][sp]|Y|P|O[onw]|X)|>(?:[lmtsn]|surtout|guère|presque|même) ") && ! (m[2].search(/-(?:ils?|elles?|[nv]ous|je|tu|on|ce)$/i) >= 0);
    },
    s2776s_1: function (s, m) {
        return suggSimil(m[2], ":(?:[123][sp]|Oo|Y)");
    },
    c2780s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":", ":(?:[123][sp]|Y|P|O[onw]|X)") && ! (m[2].search(/-(?:ils?|elles?|[nv]ous|je|tu|on|ce)$/i) >= 0);
    },
    s2780s_1: function (s, m) {
        return suggSimil(m[2], ":(?:[123][sp]|Y)");
    },
    c2784s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":", ":(?:[123][sp]|Y|P|O[onw]|X)") && ! (m[2].search(/-(?:ils?|elles?|[nv]ous|je|tu|on|ce)$/i) >= 0);
    },
    s2784s_1: function (s, m) {
        return suggSimil(m[2], ":(?:[123][sp]|Y)");
    },
    c2788s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[0].search(/^se que?/i) >= 0) && morphex(dDA, [m.start[2], m[2]], ":", ":(?:[123][sp]|Y|P|Oo)|>[lmts] ") && ! (m[2].search(/-(?:ils?|elles?|[nv]ous|je|tu|on|ce)$/i) >= 0);
    },
    s2788s_1: function (s, m) {
        return suggSimil(m[2], ":(?:[123][sp]|Oo|Y)");
    },
    c2793s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":", ":(?:[123][sp]|Y|P|Oo)") && ! (m[2].search(/-(?:ils?|elles?|[nv]ous|je|tu|on|ce)$/i) >= 0);
    },
    s2793s_1: function (s, m) {
        return suggSimil(m[2], ":(?:[123][sp]|Y)");
    },
    c2797s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":", ":(?:[123][sp]|Y|P)|>(?:en|y|ils?) ") && ! (m[2].search(/-(?:ils?|elles?|[nv]ous|je|tu|on|ce)$/i) >= 0);
    },
    s2797s_1: function (s, m) {
        return suggSimil(m[2], ":(?:[123][sp]|Y)");
    },
    c2801s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":", ":(?:[123][sp]|Y|P)|>(?:en|y|ils?|elles?) ") && ! (m[2].search(/-(?:ils?|elles?|[nv]ous|je|tu|on|ce)$/i) >= 0);
    },
    s2801s_1: function (s, m) {
        return suggSimil(m[2], ":(?:[123][sp]|Y)");
    },
    c2805s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":", ":[123][sp]|>(?:en|y|que?) ") && ! (m[2].search(/-(?:ils?|elles?|[nv]ous|je|tu|on|dire)$/i) >= 0);
    },
    s2805s_1: function (s, m) {
        return suggSimil(m[2], ":3s");
    },
    c2838s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":(?:Y|[123][sp])", ":[AQW]");
    },
    s2838s_1: function (s, m) {
        return suggSimil(m[1], ":[AW]");
    },
    c2845s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[123][sp]", ":[GNAQWM]") && ! look(s.slice(0,m.index), /\bce que? /i);
    },
    c2856s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[1][0]._isUpperCase() && morphex(dDA, [m.start[1], m[1]], ":[123][sp]", ":[GNAQM]");
    },
    c2863s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[1][0]._isUpperCase() && morphex(dDA, [m.start[1], m[1]], ":[123][sp]", ":[GNAQM]") && ! morph(dDA, prevword1(s, m.index), ":[NA]:[me]:si", false);
    },
    c2871s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[123][sp]", ":[GNAQWMT]") && morphex(dDA, nextword1(s, m.end[0]), ":", ":D", true);
    },
    s2871s_1: function (s, m) {
        return suggSimil(m[1], ":[AWGT]");
    },
    c2880s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":(?:[123][sp]|Y)", ":[GAQW]") && ! morph(dDA, prevword1(s, m.index), ":V[123].*:[123][sp]|>(?:pouvoir|vouloir|falloir) ", false, false);
    },
    s2880s_1: function (s, m) {
        return suggVerbPpas(m[1]);
    },
    c2892s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, prevword1(s, m.index), ":[VN]", false, true);
    },
    c2893s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! prevword1(s, m.index);
    },
    c2896s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:[lmts]a|leur|une|en) +$/i);
    },
    c2898s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":(?:D|Oo|M)", false);
    },
    c2899s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">être :V") && ! look(s.slice(0,m.index), /\bce que? /i);
    },
    c2913s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[2].search(/^(?:côtés?|coups?|peu(?:-près|)|pics?|propos|valoir|plat-ventrismes?)/i) >= 0);
    },
    c2913s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (m[2].search(/^(?:côtés?|coups?|peu(?:-pr(?:ès|êts?|és?)|)|pics?|propos|valoir|plat-ventrismes?)/i) >= 0);
    },
    c2919s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":3s", false, false);
    },
    c2922s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":(?:3s|R)", false, false) && ! morph(dDA, nextword1(s, m.end[0]), ":Oo|>qui ", false, false);
    },
    c2928s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":Q", ":M[12P]");
    },
    c2930s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ]", ":(?:Y|Oo)");
    },
    c2933s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ]", ":(?:Y|Oo)");
    },
    c2938s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\bce que?\b/i);
    },
    c2942s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":(?:M[12]|D|Oo)");
    },
    c2950s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[2]._isLowerCase();
    },
    c2950s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":(?:V.......[_z][az].*:Q|V1.*:Ip:2p)", ":[MGWNY]");
    },
    c2950s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && morph(dDA, [m.start[2], m[2]], "V1.*:(?:Ip:2p|Q)", false) && ! look(s.slice(0,m.index), /\b(?:il +|elle +|on +|l(?:es|ui|leur) +|[nv]ous +|y +|en +|[nmtsld]’)$/i);
    },
    s2950s_3: function (s, m) {
        return suggVerbInfi(m[2]);
    },
    c2950s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && morph(dDA, [m.start[2], m[2]], ":[123][sp]") && ! m[2].startsWith("tord");
    },
    c2950s_5: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":V2.*:Ip:3s");
    },
    s2950s_5: function (s, m) {
        return suggVerbPpas(m[2], ":m:s");
    },
    c2950s_6: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    c2950s_7: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo;
    },
    c2964s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /[ln]’$|\b(?:il|elle|on|y|n’en) +$/i);
    },
    c2968s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /(?:\bque? |[ln]’$|\b(?:il|elle|on|y|n’en) +$)/i);
    },
    c2972s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /(?:\bque? |[ln]’$|\b(?:il|elle|on|y|n’en) +$)/i);
    },
    c2976s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":Y", false) && ! look(s.slice(0,m.index), /\bque? |(?:il|elle|on|n’(?:en|y)) +$/i);
    },
    c3055s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! prevword1(s, m.index);
    },
    c3067s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f") && ! (m[2].search(/^seule?s?/) >= 0);
    },
    c3069s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":G", ">(?:tr(?:ès|op)|peu|bien|plus|moins|toute) |:[NAQ].*:f");
    },
    c3073s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:[oO]h|[aA]h) +$/);
    },
    c3074s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":R");
    },
    c3092s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":Y")  && m[1] != "CE";
    },
    c3095s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":V[123].*:(?:Y|[123][sp])") && ! morph(dDA, [m.start[2], m[2]], ">(?:devoir|pouvoir) ") && m[2][0]._isLowerCase() && m[1] != "CE";
    },
    c3099s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (m[0].indexOf(",") >= 0 || morphex(dDA, [m.start[2], m[2]], ":G", ":[AYD]"));
    },
    c3109s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":[NAQ].*:[me]") || look(s.slice(0,m.index), /\b[cs]e +/i);
    },
    c3116s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ">(?:être|pouvoir|devoir) .*:3s", false);
    },
    c3120s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[123]s", ":P");
    },
    c3123s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ]", ":([123][sp]|Y|P|Q)|>l[ea]? ");
    },
    c3126s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":N.*:s", ":(?:A.*:[pi]|P|R)|>autour ");
    },
    c3164s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":N.*:p", ":(?:G|W|M|A.*:[si])");
    },
    c3176s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1].endsWith("en") || look(s.slice(0,m.index), /^ *$/);
    },
    c3192s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0e", false) && morphex(dDA, [m.start[3], m[3]], ":[NAQ]", ":G");
    },
    c3195s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":Q");
    },
    c3198s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ">(?:profiter|bénéficier) ", false);
    },
    c3214s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, prevword1(s, m.index), ":W", false, false);
    },
    s3214s_1: function (s, m) {
        return m[0].replace(/end/g, "ent");
    },
    c3222s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! prevword1(s, m.index) && ! morph(dDA, nextword1(s, m.end[0]), ":[WAY]", false, false);
    },
    c3226s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[1].startsWith("B");
    },
    c3269s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":E|>le ", false, false);
    },
    c3288s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":(?:[123][sp]|Y)", ":(?:G|N|A|M[12P])") && ! look(s.slice(0,m.index), /\b[ld]es +$/i);
    },
    c3305s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":W", ":3s") && ! morph(dDA, prevword1(s, m.index), ":V.*:3s", false, false);
    },
    s3314s_1: function (s, m) {
        return m[1].replace(/pal/g, "pâl");
    },
    s3318s_1: function (s, m) {
        return m[1].replace(/pal/g, "pâl");
    },
    c3328s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /très +$/);
    },
    c3334s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[AQ]", false);
    },
    c3340s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, prevword1(s, m.index), ":C", false, true);
    },
    c3346s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /(?:quelqu|l|d)’/i);
    },
    c3358s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":A") && ! (m[2].search(/^seule?s?$/i) >= 0);
    },
    c3385s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":D|>bord ", false) && ! morph(dDA, prevword1(s, m.index), ":D.*:[me]|>(?:grande|petite) ", false, false);
    },
    c3404s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /(?:peu|de|au plus) $/i) && morph(dDA, [m.start[2], m[2]], ":Y|>(?:tout|les?|la) ");
    },
    c3407s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":(?:Y|M[12P])|>(?:en|y|les?) ", false);
    },
    c3420s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ">(?:arriver|venir|à|revenir|partir|aller) ");
    },
    c3425s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":P", false);
    },
    c3426s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), /^ +ne s(?:ai[st]|u[st]|urent|avai(?:[ts]|ent)) /);
    },
    c3443s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ]", ":(?:G|[123][sp]|W)");
    },
    s3443s_1: function (s, m) {
        return m[1].replace(/ /g, "");
    },
    c3451s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0e", false);
    },
    c3460s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! prevword1(s, m.index) && morph(dDA, [m.start[2], m[2]], ":V", false);
    },
    c3463s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! prevword1(s, m.index) && morph(dDA, [m.start[2], m[2]], ":V", false) && ! ( m[1] == "sans" && morph(dDA, [m.start[2], m[2]], ":[NY]", false) );
    },
    c3484s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":M[12]", false);
    },
    c3493s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), /^[ ’](?:lieux|endroits|places|mondes|villes|pays|régions|cités)/);
    },
    c3527s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">ouvrir ", false);
    },
    c3542s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[2].search(/^(?:grand|petit|rouge)$/) >= 0) && morphex(dDA, [m.start[2], m[2]], ":A", ":[NGM]") && ! m[2]._isTitle() && ! look(s.slice(0,m.index), /\bne (?:pas |jamais |) *$/i) && ! morph(dDA, prevword1(s, m.index), ":O[os]|>(?:ne|falloir|pouvoir|savoir|de) ", false);
    },
    c3549s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, prevword1(s, m.index), ":Cs|>(?:ni|et|sans|pour|falloir|[pv]ouvoir|aller) ", true, false);
    },
    c3596s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return look(s.slice(0,m.index), /\b(aux|[ldmts]es|[nv]os) +$/);
    },
    c3597s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[AQ].*:[pi]", false);
    },
    c3601s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! prevword1(s, m.index);
    },
    c3607s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:d[eu]|avant|après|sur|malgré) +$/i);
    },
    c3615s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:d[eu]|avant|après|sur|malgré) +$/i) && ! morph(dDA, [m.start[2], m[2]], ":(?:3s|Oo)", false);
    },
    c3623s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:d[eu]|avant|après|sur|malgré) +$/i);
    },
    c3640s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":f", ":(?:[123][sp]|[me])") && morphex(dDA, prevword1(s, m.index), ":", ":(?:R|[123][sp]|Q)|>(?:[nv]ous|eux) ", true);
    },
    c3640s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s3640s_2: function (s, m) {
        return suggMasPlur(m[2], true);
    },
    c3645s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":m", ":(?:[123][sp]|[fe])") && morphex(dDA, prevword1(s, m.index), ":", ":(?:R|[123][sp]|Q)|>(?:[nv]ous|eux) ", true);
    },
    c3645s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s3645s_2: function (s, m) {
        return suggFemPlur(m[2], true);
    },
    c3655s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":N.*:[fp]", ":(?:A|W|G|M[12P]|Y|[me]:i|3s)") && morph(dDA, prevword1(s, m.index), ":R|>de ", false, true);
    },
    s3655s_1: function (s, m) {
        return suggMasSing(m[1], true);
    },
    c3660s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[mp]") && morph(dDA, prevword1(s, m.index), ":R|>de ", false, true);
    },
    s3660s_1: function (s, m) {
        return suggFemSing(m[1], true);
    },
    c3665s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[fs]") && morph(dDA, prevword1(s, m.index), ":R|>de ", false, true);
    },
    s3665s_1: function (s, m) {
        return suggMasPlur(m[1], true);
    },
    c3670s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[ms]") && morph(dDA, prevword1(s, m.index), ":R|>de ", false, true);
    },
    s3670s_1: function (s, m) {
        return suggFemPlur(m[1], true);
    },
    c3690s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[123][sp]", false) && ! ((m[2].search(/^(?:jamais|rien)$/i) >= 0) && look(s.slice(0,m.index), /\b(?:que?|plus|moins) /));
    },
    c3695s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[123][sp]", false) && ! ((m[2].search(/^(?:jamais|rien)$/i) >= 0) && look(s.slice(0,m.index), /\b(?:que?|plus|moins) /));
    },
    c3700s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[123][sp]", false) && ! ((m[3].search(/^(?:jamais|rien)$/i) >= 0) && look(s.slice(0,m.index), /\b(?:que?|plus|moins) /));
    },
    c3705s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[123][sp]", false) && ! ((m[3].search(/^(?:jamais|rien)$/i) >= 0) && look(s.slice(0,m.index), /\b(?:que?|plus|moins) /));
    },
    c3721s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":(?:Y|W|O[ow])|>que? ", false) && _oDict.isValid(m[1]);
    },
    s3721s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c3758s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, nextword1(s, m.end[0]), ":[AN].*:[pi]", false, false);
    },
    c3759s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":A.*:s");
    },
    c3760s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":A.*:s", false);
    },
    p3913s_1: function (s, m) {
        return m[0].replace(/ /g, "_");
    },
    c4010s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ]", ":G");
    },
    c4017s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":R", false, false);
    },
    c4029s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[2].search(/^(?:janvier|février|mars|avril|mai|juin|juillet|ao[ûu]t|septembre|octobre|novembre|décembre|vendémiaire|brumaire|frimaire|nivôse|pluviôse|ventôse|germinal|floréal|prairial|messidor|thermidor|fructidor)s?$/i) >= 0);
    },
    c4036s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:une|la|cette|[mts]a|[nv]otre|de) +/i);
    },
    c4069s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">faire ", false);
    },
    c4069s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">faire ", false);
    },
    c4089s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[2]._isDigit() || morph(dDA, [m.start[2], m[2]], ":B", false);
    },
    c4095s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return look(s.slice(0,m.index), /\b[lL]a +$/);
    },
    d4095s_1: function (s, m, dDA) {
        return define(dDA, m.start[0], [">numéro :N:f:s"]);
    },
    c4106s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">prendre ", false);
    },
    c4110s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">rester ", false);
    },
    c4115s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:sembler|para[îi]tre) ") && morphex(dDA, [m.start[3], m[3]], ":A", ":G");
    },
    c4119s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">tenir ", false);
    },
    c4122s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">trier ", false);
    },
    c4124s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">venir ", false);
    },
    c4139s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:[pi]", ":(?:G|3p)");
    },
    c4144s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:[pi]", ":(?:G|3p)");
    },
    c4151s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":B", false);
    },
    c4152s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":A.*:[me]:[si]", false);
    },
    c4153s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return isEndOfNG(dDA, s.slice(m.end[0]), m.end[0]);
    },
    c4154s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":W", false);
    },
    c4155s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":A .*:m:s", false);
    },
    c4157s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, prevword1(s, m.index), ":(?:R|C[sc])", false, true);
    },
    c4158s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":B", false) || (m[1].search(/^(?:plusieurs|maintes)/i) >= 0);
    },
    c4159s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, nextword1(s, m.end[0]), ":[NAQR]", false, true);
    },
    c4160s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ]", ":V0");
    },
    c4162s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":D", false);
    },
    c4163s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":D.*:[me]:[si]", false);
    },
    c4164s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, nextword1(s, m.end[0]), ":([AQ].*:[me]:[pi])", false, false);
    },
    c4165s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":A", false);
    },
    c4166s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:croire|devoir|estimer|imaginer|penser) ");
    },
    c4168s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":(?:R|D|[123]s|X)", false);
    },
    c4169s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":[AQ]:[ef]:[si]", false);
    },
    c4170s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":[AQ]:[em]:[si]", false);
    },
    c4171s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:il +|n’)$/i);
    },
    c4172s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D", false, false);
    },
    c4173s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\bt(?:u|oi qui)[ ,]/i);
    },
    c4174s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D", false, false);
    },
    c4175s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":A", false);
    },
    c4176s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D", false, false);
    },
    c4177s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":W", false);
    },
    c4178s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[AW]", ":G");
    },
    c4179s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[AW]", false);
    },
    c4180s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":Y", false);
    },
    c4183s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NV]", ":D");
    },
    c4184s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":(?:3s|X)", false);
    },
    c4185s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[me]", false);
    },
    c4192s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":M[12]", false) && (morph(dDA, [m.start[2], m[2]], ":(?:M[12]|V)", false) || ! _oDict.isValid(m[2]));
    },
    c4193s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":M", false) && morph(dDA, [m.start[2], m[2]], ":M", false);
    },
    c4194s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":M", false);
    },
    c4195s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":(?:M[12]|N)") && morph(dDA, [m.start[2], m[2]], ":(?:M[12]|N)");
    },
    c4196s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":MP");
    },
    c4197s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":M[12]", false);
    },
    c4198s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":M[12]", false);
    },
    c4201s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[MT]", false) && morph(dDA, prevword1(s, m.index), ":Cs", false, true) && ! look(s.slice(0,m.index), /\b(?:plus|moins|aussi) .* que +$/);
    },
    p4201s_1: function (s, m) {
        return rewriteSubject(m[1],m[2]);
    },
    c4206s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0e", false);
    },
    c4208s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0e", false);
    },
    c4210s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":(?:V0e|N)", false) && morph(dDA, [m.start[3], m[3]], ":[AQ]", false);
    },
    c4212s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0", false);
    },
    c4214s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0", false) && morph(dDA, [m.start[3], m[3]], ":[QY]", false);
    },
    c4216s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false) && ! (m[2] == "crainte" && look(s.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/));
    },
    c4218s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false);
    },
    c4220s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false) && morph(dDA, [m.start[3], m[3]], ":B", false) && morph(dDA, [m.start[4], m[4]], ":(?:Q|V1.*:Y)", false);
    },
    c4224s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":A:[fe]:s", false);
    },
    c4225s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":A:[fe]:p", false);
    },
    c4228s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V", false);
    },
    c4229s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V[123]");
    },
    c4230s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V[123]", false);
    },
    c4231s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V", false);
    },
    c4234s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":G");
    },
    c4237s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], "[NAQ].*:[me]:[si]", false);
    },
    c4239s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[me]", ":G") && morph(dDA, [m.start[3], m[3]], ":[AQ].*:[me]", false);
    },
    c4241s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[fe]", ":G") && morph(dDA, [m.start[3], m[3]], ":[AQ].*:[fe]", false);
    },
    c4243s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[pi]", ":[123][sp]") && morph(dDA, [m.start[3], m[3]], ":[AQ].*:[pi]", false);
    },
    c4246s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[AW]");
    },
    c4248s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[AW]", false);
    },
    c4250s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[AQ]", false);
    },
    c4252s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":W", ":3p");
    },
    c4254s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[AW]", ":[123][sp]");
    },
    c4258s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ]", false) && morph(dDA, [m.start[3], m[3]], ":W", false) && morph(dDA, [m.start[4], m[4]], ":[AQ]", false);
    },
    c4260s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D", false, true);
    },
    c4261s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":W\\b");
    },
    c4264s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ]", false);
    },
    c4268s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":(?:N|A|Q|V0e)", false);
    },
    c4292s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\bne +$/i);
    },
    c4318s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":A.*:[me]:[pi]", false);
    },
    c4319s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":(?:A.*:[fe]:[si]|Oo|[123][sp])", false);
    },
    c4320s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":(?:A.*:[me]:[si]|Oo|[123][sp])", false);
    },
    c4321s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":A.*:[me]:[si]", false);
    },
    c4322s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":A.*:[me]:[si]", false);
    },
    c4323s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":A.*:[me]:[pi]", false);
    },
    c4324s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":A.*:[fe]:[pi]", false);
    },
    c4325s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":A.*:[fe]:[pi]", false);
    },
    c4326s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":A.*:[fe]:[pi]", false);
    },
    c4327s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":A.*:[fe]:[pi]", false);
    },
    c4328s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":A.*:[me]:[pi]", false);
    },
    c4329s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":A.*:[me]:[si]", false);
    },
    c4379s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":1s", false, false);
    },
    c4380s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":2s", false, false);
    },
    c4381s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":3s", false, false);
    },
    c4382s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":1p", false, false);
    },
    c4383s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":2p", false, false);
    },
    c4384s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":3p", false, false);
    },
    c4391s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return isAmbiguousNAV(m[3]) && morphex(dDA, [m.start[1], m[1]], ":[NAQ]", ">telle ");
    },
    c4394s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return isAmbiguousNAV(m[3]) && morphex(dDA, [m.start[1], m[1]], ":[NAQ]", ">telle ") && ! (m[0].search(/^[dD](?:’une?|e l(?:a|eur)) /) >= 0);
    },
    c4397s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return isAmbiguousNAV(m[3]) && ( morph(dDA, [m.start[1], m[1]], ":[NAQ]", false) || (morphex(dDA, [m.start[1], m[1]], ":[NAQ]", ":3[sp]") && ! prevword1(s, m.index)) );
    },
    c4414s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":(?:G|V0)|>même ", false);
    },
    c4414s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    c4433s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[NAQ]", false);
    },
    c4435s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[NAQ]", false);
    },
    c4437s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[NAQ].*:[fe]", false);
    },
    c4448s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:p", ":[123][sp]|:[si]");
    },
    s4448s_1: function (s, m) {
        return suggSing(m[1]);
    },
    c4457s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f", ":(?:e|m|P|G|W|[123][sp]|Y)");
    },
    s4457s_1: function (s, m) {
        return suggLesLa(m[2]);
    },
    c4457s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasMasForm(m[2]);
    },
    s4457s_2: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c4457s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:p");
    },
    s4457s_3: function (s, m) {
        return suggMasSing(m[2]);
    },
    c4457s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    c4463s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:f", ":(?:e|m|P|G|W|[123][sp]|Y)") || ( morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:f", ":[me]") && morphex(dDA, [m.start[1], m[1]], ":R", ">(?:e[tn]|ou) ") && ! (morph(dDA, [m.start[1], m[1]], ":Rv", false) && morph(dDA, [m.start[3], m[3]], ":Y", false)) );
    },
    s4463s_1: function (s, m) {
        return suggLesLa(m[3]);
    },
    c4463s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasMasForm(m[3]);
    },
    s4463s_2: function (s, m) {
        return suggMasSing(m[3], true);
    },
    c4463s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && morph(dDA, [m.start[3], m[3]], ":[NAQ].*:p") || ( morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:p", ":[si]") && morphex(dDA, [m.start[1], m[1]], ":[RC]", ">(?:e[tn]|ou)") && ! (morph(dDA, [m.start[1], m[1]], ":Rv", false) && morph(dDA, [m.start[3], m[3]], ":Y", false)) );
    },
    s4463s_3: function (s, m) {
        return suggMasSing(m[3]);
    },
    c4463s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    c4473s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f", ":(?:e|m|P|G|W|Y)");
    },
    s4473s_1: function (s, m) {
        return suggLesLa(m[2]);
    },
    c4473s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasMasForm(m[2]);
    },
    s4473s_2: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c4473s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siGW]");
    },
    s4473s_3: function (s, m) {
        return suggMasSing(m[2]);
    },
    c4473s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    c4488s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f", ":[GWme]");
    },
    c4488s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasMasForm(m[2]);
    },
    s4488s_2: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c4488s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siGW]");
    },
    s4488s_3: function (s, m) {
        return suggMasSing(m[2]);
    },
    c4493s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f", ":(?:e|m|G|W|V0|3s)");
    },
    c4493s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasMasForm(m[2]);
    },
    s4493s_2: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c4493s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siGW]") && ! morph(dDA, prevword(s, m.index, 2), ":B", false);
    },
    s4493s_3: function (s, m) {
        return suggMasSing(m[2]);
    },
    c4498s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f", ":(?:e|m|G|W|V0|3s)");
    },
    c4498s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasMasForm(m[2]);
    },
    s4498s_2: function (s, m) {
        return suggMasPlur(m[2], true);
    },
    c4502s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f", ":[GWme]");
    },
    c4502s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasMasForm(m[2]);
    },
    s4502s_2: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c4502s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siGW]");
    },
    s4502s_3: function (s, m) {
        return suggMasSing(m[2]);
    },
    c4507s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f", ":[GWme]");
    },
    c4507s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasMasForm(m[2]);
    },
    s4507s_2: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c4507s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ">[bcçdfgjklmnpqrstvwxz].+:[NAQ].*:m", ":[efGW]");
    },
    c4507s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siGW]");
    },
    s4507s_4: function (s, m) {
        return suggMasSing(m[2]);
    },
    c4513s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f", ":(?:3s|[GWme])");
    },
    c4513s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasMasForm(m[2]);
    },
    s4513s_2: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c4513s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f", ":[GWme]") && morph(dDA, [m.start[2], m[2]], ":3s", false);
    },
    c4513s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siGW]");
    },
    s4513s_4: function (s, m) {
        return suggMasSing(m[2]);
    },
    c4519s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ">[bcdfgjklmnpqrstvwxz].*:[NAQ].*:f", ":[GWme]");
    },
    s4519s_1: function (s, m) {
        return m[1].replace(/on/g, "a");
    },
    c4519s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasMasForm(m[2]);
    },
    s4519s_2: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c4519s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siGW]");
    },
    s4519s_3: function (s, m) {
        return suggMasSing(m[2]);
    },
    c4524s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f:s", ":[GWme]");
    },
    c4524s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasMasForm(m[2]);
    },
    s4524s_2: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c4524s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siGW]");
    },
    s4524s_3: function (s, m) {
        return suggMasSing(m[2]);
    },
    c4524s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    c4545s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m", ":(?:e|f|P|G|W|[1-3][sp]|Y)");
    },
    c4545s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4545s_2: function (s, m) {
        return suggFemSing(m[2], true);
    },
    c4545s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:p");
    },
    s4545s_3: function (s, m) {
        return suggFemSing(m[2]);
    },
    c4550s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:m", ":(?:e|f|P|G|W|[1-3][sp]|Y)") || ( morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:m", ":[fe]") && morphex(dDA, [m.start[1], m[1]], ":[RC]", ">(?:e[tn]|ou) ") && ! (morph(dDA, [m.start[1], m[1]], ":(?:Rv|C)", false) && morph(dDA, [m.start[3], m[3]], ":Y", false)) );
    },
    c4550s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[3]);
    },
    s4550s_2: function (s, m) {
        return suggFemSing(m[3], true);
    },
    c4550s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && morph(dDA, [m.start[3], m[3]], ":[NAQ].*:p") || ( morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:p", ":[si]") && morphex(dDA, [m.start[1], m[1]], ":[RC]", ">(?:e[tn]|ou)") && ! (morph(dDA, [m.start[1], m[1]], ":Rv", false) && morph(dDA, [m.start[3], m[3]], ":Y", false)) );
    },
    s4550s_3: function (s, m) {
        return suggFemSing(m[3]);
    },
    c4559s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m", ":[efPGWY]");
    },
    c4559s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4559s_2: function (s, m) {
        return suggFemSing(m[2], true);
    },
    c4559s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siGW]");
    },
    s4559s_3: function (s, m) {
        return suggFemSing(m[2]);
    },
    c4574s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m", ":[efGW]");
    },
    c4574s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4574s_2: function (s, m) {
        return suggFemSing(m[2], true);
    },
    c4574s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siGW]");
    },
    s4574s_3: function (s, m) {
        return suggFemSing(m[2]);
    },
    c4583s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m", ":(?:e|f|G|W|V0|3s|P)") && ! ( m[2] == "demi" && morph(dDA, nextword1(s, m.end[0]), ":N.*:f") );
    },
    c4583s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4583s_2: function (s, m) {
        return suggFemSing(m[2], true);
    },
    c4583s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siGW]") && ! morph(dDA, prevword(s, m.index, 2), ":B", false);
    },
    s4583s_3: function (s, m) {
        return suggFemSing(m[2]);
    },
    c4589s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m", ":(?:e|f|G|W|V0|3s)");
    },
    c4589s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4589s_2: function (s, m) {
        return suggFemPlur(m[2], true);
    },
    c4601s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m", ":[efGW]");
    },
    s4601s_1: function (s, m) {
        return suggCeOrCet(m[2]);
    },
    c4601s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4601s_2: function (s, m) {
        return suggFemSing(m[2], true);
    },
    c4601s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siGW]");
    },
    s4601s_3: function (s, m) {
        return suggFemSing(m[2]);
    },
    c4606s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m", ":[efGW]");
    },
    s4606s_1: function (s, m) {
        return m[1].replace(/a/g, "on");
    },
    c4606s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && ! (m[2].search(/^[aâeéèêiîoôuûyœæ]/i) >= 0) && hasFemForm(m[2]);
    },
    s4606s_2: function (s, m) {
        return suggFemSing(m[2], true);
    },
    c4606s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ">[aâeéèêiîoôuûyœæ].+:[NAQ].*:f", ":[eGW]");
    },
    s4606s_3: function (s, m) {
        return m[1].replace(/a/g, "on");
    },
    c4606s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siGW]");
    },
    s4606s_4: function (s, m) {
        return suggFemSing(m[2]);
    },
    c4624s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f", ":[emGWP]");
    },
    c4624s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasMasForm(m[2]);
    },
    s4624s_2: function (s, m) {
        return suggMasPlur(m[2], true);
    },
    c4624s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:s", ":(?:[ipGWP]|V0)") && ! (look(s.slice(m.end[0]), /^ +(?:et|ou) /) && morph(dDA, nextword(s, m.end[0], 2), ":[NAQ]", true, false))) || m[1] in aREGULARPLURAL;
    },
    s4624s_3: function (s, m) {
        return suggPlur(m[2]);
    },
    c4632s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f", ":[emGW]");
    },
    c4632s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasMasForm(m[2]);
    },
    s4632s_2: function (s, m) {
        return suggMasPlur(m[2], true);
    },
    c4637s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m", ":[efGWP]");
    },
    c4637s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4637s_2: function (s, m) {
        return suggFemPlur(m[2], true);
    },
    c4637s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:s", ":[ipGWP]") && ! (look(s.slice(m.end[0]), /^ +(?:et|ou) /) && morph(dDA, nextword(s, m.end[0], 2), ":[NAQ]", true, false))) || m[2] in aREGULARPLURAL;
    },
    s4637s_3: function (s, m) {
        return suggPlur(m[1]);
    },
    c4645s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m", ":[efGW]");
    },
    c4645s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4645s_2: function (s, m) {
        return suggFemPlur(m[2], true);
    },
    c4659s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[NAQ].*:p");
    },
    c4659s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    s4659s_2: function (s, m) {
        return suggSing(m[2]);
    },
    c4663s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[3], m[3]], ":[NAQ].*:p") || ( morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:p", ":[si]") && morphex(dDA, [m.start[1], m[1]], ":[RC]|>de ", ">(?:e[tn]|ou)") && ! (morph(dDA, [m.start[1], m[1]], ":Rv", false) && morph(dDA, [m.start[3], m[3]], ":Y", false)) );
    },
    c4663s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    s4663s_2: function (s, m) {
        return suggSing(m[3]);
    },
    c4668s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siGW]");
    },
    c4668s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    s4668s_2: function (s, m) {
        return suggSing(m[2]);
    },
    c4678s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:p", ":[siGW]");
    },
    s4678s_1: function (s, m) {
        return suggSing(m[1]);
    },
    c4685s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[siG]");
    },
    c4694s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ( morph(dDA, [m.start[1], m[1]], ":[NAQ].*:s") && ! (look(s.slice(m.end[0]), /^ +(?:et|ou) /) && morph(dDA, nextword(s, m.end[0], 2), ":[NAQ]", true, false)) ) || m[1] in aREGULARPLURAL;
    },
    s4694s_1: function (s, m) {
        return suggPlur(m[1]);
    },
    c4699s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ( morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s") || (morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:s", ":[pi]|>avoir") && morphex(dDA, [m.start[1], m[1]], ":[RC]", ">(?:e[tn]|ou) ") && ! (morph(dDA, [m.start[1], m[1]], ":Rv", false) && morph(dDA, [m.start[2], m[2]], ":Y", false))) ) && ! (look(s.slice(m.end[0]), /^ +(?:et|ou) /) && morph(dDA, nextword(s, m.end[0], 2), ":[NAQ]", true, false));
    },
    s4699s_1: function (s, m) {
        return suggPlur(m[2]);
    },
    c4705s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:s", ":[ipYPGW]") && ! (look(s.slice(m.end[0]), /^ +(?:et|ou) /) && morph(dDA, nextword(s, m.end[0], 2), ":[NAQ]", true, false))) || m[1] in aREGULARPLURAL;
    },
    s4705s_1: function (s, m) {
        return suggPlur(m[1]);
    },
    c4719s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:s", ":(?:[ipGW]|[123][sp])") && ! (look(s.slice(m.end[0]), /^ +(?:et|ou) /) && morph(dDA, nextword(s, m.end[0], 2), ":[NAQ]", true, false))) || m[2] in aREGULARPLURAL;
    },
    s4719s_1: function (s, m) {
        return suggPlur(m[2]);
    },
    c4719s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    c4730s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:s", ":[ipGW]") && ! (look(s.slice(m.end[0]), /^ +(?:et|ou) /) && morph(dDA, nextword(s, m.end[0], 2), ":[NAQ]", true, false))) || m[1] in aREGULARPLURAL;
    },
    s4730s_1: function (s, m) {
        return suggPlur(m[1]);
    },
    c4736s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:s", ":[ipGWP]") && ! (look(s.slice(m.end[0]), /^ +(?:et|ou) /) && morph(dDA, nextword(s, m.end[0], 2), ":[NAQ]", true, false))) || m[1] in aREGULARPLURAL;
    },
    s4736s_1: function (s, m) {
        return suggPlur(m[1]);
    },
    c4762s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:s", ":[ip]|>o(?:nde|xydation|or)\\b") && morphex(dDA, prevword1(s, m.index), ":(?:G|[123][sp])", ":[AD]", true)) || m[1] in aREGULARPLURAL;
    },
    s4762s_1: function (s, m) {
        return suggPlur(m[1]);
    },
    c4771s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:s", ":[ip]") || m[1] in aREGULARPLURAL;
    },
    s4771s_1: function (s, m) {
        return suggPlur(m[1]);
    },
    c4779s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:s", ":[ip]") || m[1] in aREGULARPLURAL;
    },
    s4779s_1: function (s, m) {
        return suggPlur(m[1]);
    },
    c4791s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":B.*:p", false) && m[2] != "cents";
    },
    c4816s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s") && ! (m[2].search(/^(janvier|février|mars|avril|mai|juin|juillet|ao[ûu]t|septembre|octobre|novembre|décembre|rue|route|ruelle|place|boulevard|avenue|allée|chemin|sentier|square|impasse|cour|quai|chaussée|côte|vendémiaire|brumaire|frimaire|nivôse|pluviôse|ventôse|germinal|floréal|prairial|messidor|thermidor|fructidor)$/i) >= 0)) || m[2] in aREGULARPLURAL;
    },
    s4816s_1: function (s, m) {
        return suggPlur(m[2]);
    },
    c4826s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s") && ! morph(dDA, prevword1(s, m.index), ":N", false) && ! (m[2].search(/^(janvier|février|mars|avril|mai|juin|juillet|ao[ûu]t|septembre|octobre|novembre|décembre|rue|route|ruelle|place|boulevard|avenue|allée|chemin|sentier|square|impasse|cour|quai|chaussée|côte|vendémiaire|brumaire|frimaire|nivôse|pluviôse|ventôse|germinal|floréal|prairial|messidor|thermidor|fructidor)$/i) >= 0)) || m[2] in aREGULARPLURAL;
    },
    s4826s_1: function (s, m) {
        return suggPlur(m[2]);
    },
    c4836s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morph(dDA, [m.start[1], m[1]], ":[NAQ].*:s") || m[1] in aREGULARPLURAL) && ! look(s.slice(0,m.index), /\b(?:le|un|ce|du) +$/i);
    },
    s4836s_1: function (s, m) {
        return suggPlur(m[1]);
    },
    c4844s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ].*:p") && ! (m[1].search(/^(janvier|février|mars|avril|mai|juin|juillet|ao[ûu]t|septembre|octobre|novembre|décembre|rue|route|ruelle|place|boulevard|avenue|allée|chemin|sentier|square|impasse|cour|quai|chaussée|côte|vendémiaire|brumaire|frimaire|nivôse|pluviôse|ventôse|germinal|floréal|prairial|messidor|thermidor|fructidor|Rois|Corinthiens|Thessaloniciens)$/i) >= 0);
    },
    s4844s_1: function (s, m) {
        return suggSing(m[1]);
    },
    c4854s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^0*[01]$/) >= 0) && ((morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s") && ! (m[2].search(/^(janvier|février|mars|avril|mai|juin|juillet|ao[ûu]t|septembre|octobre|novembre|décembre|rue|route|ruelle|place|boulevard|avenue|allée|chemin|sentier|square|impasse|cour|quai|chaussée|côte|vendémiaire|brumaire|frimaire|nivôse|pluviôse|ventôse|germinal|floréal|prairial|messidor|thermidor|fructidor)$/i) >= 0)) || m[1] in aREGULARPLURAL);
    },
    s4854s_1: function (s, m) {
        return suggPlur(m[2]);
    },
    c4866s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f:p", ":(?:V0e|[NAQ].*:[me]:[si])");
    },
    c4866s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4866s_2: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c4866s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m:p", ":(?:V0e|[NAQ].*:[me]:[si])");
    },
    c4866s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    s4866s_4: function (s, m) {
        return suggSing(m[2]);
    },
    c4866s_5: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f:[si]", ":(?:V0e|[NAQ].*:[me]:[si])");
    },
    c4866s_6: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4866s_6: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c4874s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f:s", ":(?:V0e|[NAQ].*:[me]:[pi])");
    },
    c4874s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4874s_2: function (s, m) {
        return suggMasPlur(m[2], true);
    },
    c4874s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m:s", ":(?:V0e|[NAQ].*:[me]:[pi])");
    },
    c4874s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    s4874s_4: function (s, m) {
        return suggPlur(m[2]);
    },
    c4874s_5: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f:[pi]", ":(?:V0e|[NAQ].*:[me]:[pi])");
    },
    c4874s_6: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4874s_6: function (s, m) {
        return suggMasPlur(m[2], true);
    },
    c4882s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m:p", ":(?:V0e|[NAQ].*:[fe]:[si])");
    },
    c4882s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4882s_2: function (s, m) {
        return suggFemSing(m[2], true);
    },
    c4882s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f:p", ":(?:V0e|[NAQ].*:[fe]:[si])");
    },
    c4882s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    s4882s_4: function (s, m) {
        return suggSing(m[2]);
    },
    c4882s_5: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m:[si]", ":(?:V0e|[NAQ].*:[fe]:[si])");
    },
    c4882s_6: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4882s_6: function (s, m) {
        return suggFemSing(m[2], true);
    },
    c4890s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m:s", ":(?:V0e|[NAQ].*:[fe]:[pi])");
    },
    c4890s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4890s_2: function (s, m) {
        return suggFemPlur(m[2], true);
    },
    c4890s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:f:s", ":(?:V0e|[NAQ].*:[fe]:[pi])");
    },
    c4890s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    s4890s_4: function (s, m) {
        return suggPlur(m[2]);
    },
    c4890s_5: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:m:[pi]", ":(?:V0e|[NAQ].*:[fe]:[pi])");
    },
    c4890s_6: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[2]);
    },
    s4890s_6: function (s, m) {
        return suggFemPlur(m[2], true);
    },
    c4907s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\btel(?:le|)s? +$/);
    },
    c4912s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\btel(?:le|)s? +$/);
    },
    s4912s_1: function (s, m) {
        return m[1].slice(0,-1);
    },
    c4917s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\btel(?:le|)s? +$/) && morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:f", ":[me]");
    },
    c4922s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\btel(?:le|)s? +$/) && morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:m", ":[fe]");
    },
    c4927s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\btel(?:le|)s? +$/) && morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:f", ":[me]");
    },
    c4932s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\btel(?:le|)s? +$/) && morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:m", ":[fe]");
    },
    c4949s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":V0e", false);
    },
    c4953s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":V0e", false) && morphex(dDA, [m.start[4], m[4]], ":[NAQ].*:m", ":[fe]");
    },
    s4953s_1: function (s, m) {
        return m[1].replace(/lle/g, "l");
    },
    c4965s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":V0e", false);
    },
    c4969s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":V0e", false) && morphex(dDA, [m.start[4], m[4]], ":[NAQ].*:f", ":[me]");
    },
    s4969s_1: function (s, m) {
        return m[1].replace(/l/g, "lle");
    },
    c4982s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">trouver ", false) && morphex(dDA, [m.start[3], m[3]], ":A.*:(?:f|m:p)", ":(?:G|3[sp]|M[12P])");
    },
    s4982s_1: function (s, m) {
        return suggMasSing(m[3]);
    },
    c4994s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ((morph(dDA, [m.start[1], m[1]], ":[NAQ].*:m") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f")) || (morph(dDA, [m.start[1], m[1]], ":[NAQ].*:f") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m"))) && ! apposition(m[1], m[2]);
    },
    s4994s_1: function (s, m) {
        return switchGender(m[2]);
    },
    c4994s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[1]);
    },
    s4994s_2: function (s, m) {
        return switchGender(m[1]);
    },
    c4994s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ((morph(dDA, [m.start[1], m[1]], ":[NAQ].*:s") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:p")) || (morph(dDA, [m.start[1], m[1]], ":[NAQ].*:p") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s"))) && ! apposition(m[1], m[2]);
    },
    s4994s_3: function (s, m) {
        return switchPlural(m[2]);
    },
    c4994s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    s4994s_4: function (s, m) {
        return switchPlural(m[1]);
    },
    c5009s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ( (morph(dDA, [m.start[1], m[1]], ":[NAQ].*:m") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f")) || (morph(dDA, [m.start[1], m[1]], ":[NAQ].*:f") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m")) ) && ! apposition(m[1], m[2]) && morph(dDA, prevword1(s, m.index), ":[VRX]", true, true);
    },
    s5009s_1: function (s, m) {
        return switchGender(m[2]);
    },
    c5009s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[1]);
    },
    s5009s_2: function (s, m) {
        return switchGender(m[1]);
    },
    c5009s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ( (morph(dDA, [m.start[1], m[1]], ":[NAQ].*:p") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s")) || (morph(dDA, [m.start[1], m[1]], ":[NAQ].*:s") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:p")) ) && ! apposition(m[1], m[2]) && morph(dDA, prevword1(s, m.index), ":[VRX]", true, true);
    },
    s5009s_3: function (s, m) {
        return switchPlural(m[2]);
    },
    c5009s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    s5009s_4: function (s, m) {
        return switchPlural(m[1]);
    },
    c5024s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ( (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:m", ":[GYfe]") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f")) || (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:f", ":[GYme]") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m")) ) && ! apposition(m[1], m[2]) && morph(dDA, prevword1(s, m.index), ":[VRX]", true, true);
    },
    s5024s_1: function (s, m) {
        return switchGender(m[2]);
    },
    c5024s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[1]);
    },
    s5024s_2: function (s, m) {
        return switchGender(m[1]);
    },
    c5024s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ( (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:p", ":[GYsi]") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s")) || (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:s", ":[GYpi]") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:p")) ) && ! apposition(m[1], m[2]) && morph(dDA, prevword1(s, m.index), ":[VRX]", true, true);
    },
    s5024s_3: function (s, m) {
        return switchPlural(m[2]);
    },
    c5024s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    s5024s_4: function (s, m) {
        return switchPlural(m[1]);
    },
    c5039s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ( (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:m", ":(?:[Gfe]|V0e|Y)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f")) || (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:f", ":(?:[Gme]|V0e|Y)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m")) ) && ! apposition(m[1], m[2]) && morph(dDA, prevword1(s, m.index), ":[VRX]", true, true);
    },
    s5039s_1: function (s, m) {
        return switchGender(m[2]);
    },
    c5039s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[1]);
    },
    s5039s_2: function (s, m) {
        return switchGender(m[1]);
    },
    c5039s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ( (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:p", ":(?:[Gsi]|V0e|Y)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s")) || (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:s", ":(?:[Gpi]|V0e|Y)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:p")) ) && ! apposition(m[1], m[2]) && morph(dDA, prevword1(s, m.index), ":[VRX]", true, true);
    },
    s5039s_3: function (s, m) {
        return switchPlural(m[2]);
    },
    c5039s_4: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo;
    },
    s5039s_4: function (s, m) {
        return switchPlural(m[1]);
    },
    c5065s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^air$/i) >= 0) && ! m[2].startsWith("seul") && ( (morph(dDA, [m.start[1], m[1]], ":m") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f")) || (morph(dDA, [m.start[1], m[1]], ":f") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m")) ) && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5065s_1: function (s, m) {
        return switchGender(m[2], false);
    },
    c5065s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[1]);
    },
    s5065s_2: function (s, m) {
        return switchGender(m[1]);
    },
    c5065s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^air$/i) >= 0) && ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[si]") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:p") && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5065s_3: function (s, m) {
        return suggSing(m[2]);
    },
    c5076s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && ( (morph(dDA, [m.start[1], m[1]], ":m") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f")) || (morph(dDA, [m.start[1], m[1]], ":f") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m")) ) && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]", false, false);
    },
    s5076s_1: function (s, m) {
        return switchGender(m[2], false);
    },
    c5076s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[1]);
    },
    s5076s_2: function (s, m) {
        return switchGender(m[1]);
    },
    c5076s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^air$/i) >= 0) && ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[si]") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:p") && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]", false, false);
    },
    s5076s_3: function (s, m) {
        return suggSing(m[2]);
    },
    c5096s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[me]", ":(?:B|G|V0|f)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f") && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5096s_1: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c5096s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[si]", false) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:p") && ! m[2].startsWith("seul") && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|d’) *$/);
    },
    s5096s_2: function (s, m) {
        return suggMasSing(m[2]);
    },
    c5105s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[me]", ":(?:B|G|V0|f)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f") && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]|>(?:et|ou) ", false, false);
    },
    s5105s_1: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c5105s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[si]", false) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:p") && ! m[2].startsWith("seul") && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQB]|>(?:et|ou) ", false, false);
    },
    s5105s_2: function (s, m) {
        return suggMasSing(m[2]);
    },
    c5125s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[fe]", ":(?:B|G|V0|m)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m") && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5125s_1: function (s, m) {
        return suggFemSing(m[2], true);
    },
    c5125s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "fois" && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[si]", false) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:p") && ! m[2].startsWith("seul") && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|d’) *$/);
    },
    s5125s_2: function (s, m) {
        return suggFemSing(m[2]);
    },
    c5134s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[fe]", ":(?:B|G|V0|m)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m") && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]|>(?:et|ou) ", false, false);
    },
    s5134s_1: function (s, m) {
        return suggFemSing(m[2], true);
    },
    c5134s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "fois" && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[si]", false) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:p") && ! m[2].startsWith("seul") && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQB]|>(?:et|ou) ", false, false);
    },
    s5134s_2: function (s, m) {
        return suggFemSing(m[2]);
    },
    c5155s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[me]", ":(?:B|G|V0|f)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f") && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5155s_1: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c5155s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[si]", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GWsi]") && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5155s_2: function (s, m) {
        return suggMasSing(m[2]);
    },
    c5165s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[me]", ":(?:B|G|V0|f)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f") && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]|>(?:et|ou) ", false, false);
    },
    s5165s_1: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c5165s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[si]", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GWsi]") && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]|>(?:et|ou) ", false, false);
    },
    s5165s_2: function (s, m) {
        return suggMasSing(m[2]);
    },
    c5180s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:m", ":(?:B|G|e|V0|f)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f") && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5180s_1: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c5180s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[si]", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GWsi]") && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5180s_2: function (s, m) {
        return suggMasSing(m[2]);
    },
    c5190s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:m", ":(?:B|G|e|V0|f)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f") && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]|>(?:et|ou) ", false, false);
    },
    s5190s_1: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c5190s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[si]", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GWsi]") && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]|>(?:et|ou) ", false, false);
    },
    s5190s_2: function (s, m) {
        return suggMasSing(m[2]);
    },
    c5206s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "fois" && ! m[2].startsWith("seul") && morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[fe]", ":(?:B|G|V0|m)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m") && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5206s_1: function (s, m) {
        return suggFemSing(m[2], true);
    },
    c5206s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[si]", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GWsi]") && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5206s_2: function (s, m) {
        return suggFemSing(m[2]);
    },
    c5216s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "fois" && ! m[2].startsWith("seul") && morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[fe]", ":(?:B|G|V0|m)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m") && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]|>(?:et|ou) ", false, false);
    },
    s5216s_1: function (s, m) {
        return suggFemSing(m[2], true);
    },
    c5216s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[si]", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GWsi]") && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]|>(?:et|ou) ", false, false);
    },
    s5216s_2: function (s, m) {
        return suggFemSing(m[2]);
    },
    c5233s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "fois" && ! m[2].startsWith("seul") && ! (m[0].search(/^quelque chose/i) >= 0) && ((morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:m", ":(?:B|e|G|V0|f)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f")) || (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:f", ":(?:B|e|G|V0|m)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m"))) && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5233s_1: function (s, m) {
        return switchGender(m[2], false);
    },
    c5233s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[1]);
    },
    s5233s_2: function (s, m) {
        return switchGender(m[1], false);
    },
    c5233s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[si]", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GWsi]") && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5233s_3: function (s, m) {
        return suggSing(m[2]);
    },
    c5244s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "fois" && ! m[2].startsWith("seul") && ! (m[0].search(/quelque chose/i) >= 0) && ((morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:m", ":(?:B|e|G|V0|f)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f")) || (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:f", ":(?:B|e|G|V0|m)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m"))) && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]|>(?:et|ou) ", false, false);
    },
    s5244s_1: function (s, m) {
        return switchGender(m[2], false);
    },
    c5244s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[1]);
    },
    s5244s_2: function (s, m) {
        return switchGender(m[1], false);
    },
    c5244s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[si]", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GWsi]") && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]|>(?:et|ou) ", false, false);
    },
    s5244s_3: function (s, m) {
        return suggSing(m[2]);
    },
    c5261s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[me]", ":(?:B|G|V0|f)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f") && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5261s_1: function (s, m) {
        return suggMasPlur(m[2], true);
    },
    c5261s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[pi]", false) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s") && ! apposition(m[1], m[2]) && ! (look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ +et +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A") || look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ *, +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A.*:[si]")) && ! look(s.slice(0,m.index), /\bune de /i);
    },
    s5261s_2: function (s, m) {
        return suggMasPlur(m[2]);
    },
    c5272s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[me]", ":(?:B|G|V0|f)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f") && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]|>(?:et|ou) ", false, false);
    },
    s5272s_1: function (s, m) {
        return suggMasPlur(m[2], true);
    },
    c5272s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[pi]", false) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s") && ! apposition(m[1], m[2]) && ! (look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ +et +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A") || look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ *, +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A.*:[si]")) && ! ( look(s.slice(0,m.index), /\bune? de /i) || (m[0].startsWith("de") && look(s.slice(0,m.index), /\bune? +$/i)) );
    },
    s5272s_2: function (s, m) {
        return suggMasPlur(m[2]);
    },
    c5289s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "fois" && ! m[2].startsWith("seul") && morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[fe]", ":(?:B|G|V0|m)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m") && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5289s_1: function (s, m) {
        return suggFemPlur(m[2], true);
    },
    c5289s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[pi]", false) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s") && ! apposition(m[1], m[2]) && ! (look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ +et +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A") || look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ *, +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A.*:[si]")) && ! look(s.slice(0,m.index), /\bune de /i);
    },
    s5289s_2: function (s, m) {
        return suggFemPlur(m[2]);
    },
    c5300s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "fois" && ! m[2].startsWith("seul") && morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:[fe]", ":(?:B|G|V0|m)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m") && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]|>(?:et|ou) ", false, false);
    },
    s5300s_1: function (s, m) {
        return suggFemPlur(m[2], true);
    },
    c5300s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[pi]", false) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s") && ! apposition(m[1], m[2]) && ! (look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ +et +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A") || look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ *, +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A.*:[si]")) && ! ( look(s.slice(0,m.index), /\bune? de /i) || (m[0].startsWith("de") && look(s.slice(0,m.index), /\bune? +$/i)) );
    },
    s5300s_2: function (s, m) {
        return suggFemPlur(m[2]);
    },
    c5317s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "fois" && ! m[2].startsWith("seul") && ((morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:m", ":(?:B|e|G|V0|f)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f")) || (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:f", ":(?:B|e|G|V0|m)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m"))) && ! apposition(m[1], m[2]) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s5317s_1: function (s, m) {
        return switchGender(m[2], true);
    },
    c5317s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[1]);
    },
    s5317s_2: function (s, m) {
        return switchGender(m[1], true);
    },
    c5317s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "fois" && ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[pi]", false) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s") && ! apposition(m[1], m[2]) && ! (look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ +et +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A") || look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ *, +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A.*:[si]")) && ! look(s.slice(0,m.index), /\bune? de /i);
    },
    s5317s_3: function (s, m) {
        return suggPlur(m[2]);
    },
    c5329s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "fois" && ! m[2].startsWith("seul") && ((morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:m", ":(?:B|e|G|V0|f)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f")) || (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:f", ":(?:B|e|G|V0|m)") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m"))) && ! apposition(m[1], m[2]) && ! morph(dDA, prevword1(s, m.index), ":[NAQ]|>(?:et|ou) ", false, false);
    },
    s5329s_1: function (s, m) {
        return switchGender(m[2], true);
    },
    c5329s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[1]);
    },
    s5329s_2: function (s, m) {
        return switchGender(m[1], true);
    },
    c5329s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "fois" && ! m[2].startsWith("seul") && morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[pi]", false) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s") && ! apposition(m[1], m[2]) && ! (look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ +et +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A") || look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ *, +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A.*:[si]")) && ! ( look(s.slice(0,m.index), /\bune? de /i) || (m[0].startsWith("de") && look(s.slice(0,m.index), /\bune? +$/i)) );
    },
    s5329s_3: function (s, m) {
        return suggPlur(m[2]);
    },
    c5350s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "fois" && ! m[2].startsWith("seul") && ( (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:m", ":[fe]") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f")) || (morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:f", ":[me]") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m")) ) && ! apposition(m[1], m[2]) && ! (look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ +et +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A") || look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ *, +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A.*:[si]")) && morph(dDA, prevword1(s, m.index), ":[VRBX]|>comme ", true, true);
    },
    s5350s_1: function (s, m) {
        return switchGender(m[2], true);
    },
    c5350s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && hasFemForm(m[1]);
    },
    s5350s_2: function (s, m) {
        return switchGender(m[1]);
    },
    c5350s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[pi]", false) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:s") && ! apposition(m[1], m[2]) && ! (look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ +et +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A") || look_chk1(dDA, s.slice(m.end[0]), m.end[0], /^ *, +([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":A.*:[si]")) && (morphex(dDA, [m.start[2], m[2]], ":N", ":[AQ]") || morph(dDA, prevword1(s, m.index), ":[VRBX]|>comme ", true, true));
    },
    s5350s_3: function (s, m) {
        return suggPlur(m[2]);
    },
    c5379s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morph(dDA, [m.start[1], m[1]], ":[NAQ].*:p") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:[pi]") && morph(dDA, [m.start[3], m[3]], ":[NAQ].*:s")) || (morph(dDA, [m.start[1], m[1]], ":[NAQ].*:s") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:[si]") && morph(dDA, [m.start[3], m[3]], ":[NAQ].*:p"));
    },
    s5379s_1: function (s, m) {
        return switchPlural(m[3]);
    },
    c5388s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[pi]") && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:[pi]") && morph(dDA, [m.start[3], m[3]], ":[NAQ].*:s");
    },
    s5388s_1: function (s, m) {
        return suggPlur(m[3]);
    },
    c5396s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[NAQ].*:[si]", false) && morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:[si]", ":G") && morph(dDA, [m.start[4], m[4]], ":[NAQ].*:p");
    },
    s5396s_1: function (s, m) {
        return suggSing(m[4]);
    },
    c5405s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[NAQ].*:[pi]", false) && morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:[pi]", ":G") && morph(dDA, [m.start[4], m[4]], ":[NAQ].*:s") && ! look(s.slice(0,m.index), /\bune? de /i);
    },
    s5405s_1: function (s, m) {
        return suggPlur(m[4]);
    },
    c5417s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:(?:m|f:p)", ":(?:G|P|[fe]:[is]|V0|3[sp])") && ! apposition(m[1], m[2]);
    },
    s5417s_1: function (s, m) {
        return suggFemSing(m[2], true);
    },
    c5422s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:(?:f|m:p)", ":(?:G|P|[me]:[is]|V0|3[sp])") && ! apposition(m[1], m[2]);
    },
    s5422s_1: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c5427s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":[NAQ].*:f|>[aéeiou].*:e", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:(?:f|m:p)", ":(?:G|P|m:[is]|V0|3[sp])") && ! apposition(m[1], m[2]);
    },
    s5427s_1: function (s, m) {
        return suggMasSing(m[2], true);
    },
    c5432s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:m", ":G|>[aéeiou].*:[ef]") && morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:(?:f|m:p)", ":(?:G|P|[me]:[is]|V0|3[sp])") && ! apposition(m[2], m[3]);
    },
    s5432s_1: function (s, m) {
        return suggMasSing(m[3], true);
    },
    c5438s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:m", ":G|>[aéeiou].*:[ef]") && ! morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f|>[aéeiou].*:e", false) && morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:(?:f|m:p)", ":(?:G|P|[me]:[is]|V0|3[sp])") && ! apposition(m[2], m[3]);
    },
    s5438s_1: function (s, m) {
        return suggMasSing(m[3], true);
    },
    c5444s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:s", ":(?:G|P|[me]:[ip]|V0|3[sp])") && ! apposition(m[1], m[2]);
    },
    s5444s_1: function (s, m) {
        return suggPlur(m[2]);
    },
    c5485s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! prevword1(s, m.index);
    },
    c5487s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! prevword1(s, m.index);
    },
    c5489s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! prevword1(s, m.index);
    },
    c5503s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\bquatre $/i);
    },
    c5505s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, nextword1(s, m.end[0]), ":B", false) && ! look(s.slice(0,m.index), /\b(?:numéro|page|chapitre|référence|année|test|série)s? +$/i);
    },
    s5520s_1: function (s, m) {
        return m[0].slice(0,-1);
    },
    c5528s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, nextword1(s, m.end[0]), ":B|>une?", false, true) && ! look(s.slice(0,m.index), /\b(?:numéro|page|chapitre|référence|année|test|série)s? +$/i);
    },
    c5532s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, nextword1(s, m.end[0]), ":B|>une?", false, false);
    },
    c5536s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:[pi]", ":G") && morphex(dDA, prevword1(s, m.index), ":[VR]", ":B", true);
    },
    c5547s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, nextword1(s, m.end[0]), ":B|:N.*:p", ":[QA]", false) || (morph(dDA, prevword1(s, m.index), ":B") && morph(dDA, nextword1(s, m.end[0]), ":[NAQ]", false));
    },
    c5560s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, prevword1(s, m.index), ":D.*:[si]", false, true);
    },
    s5568s_1: function (s, m) {
        return suggPlur(m[1]);
    },
    s5573s_1: function (s, m) {
        return suggPlur(m[1]);
    },
    c5590s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:mettre|mise) ", false);
    },
    c5610s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">faire ", false);
    },
    c5613s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">faire ", false) && morph(dDA, [m.start[3], m[3]], ":(?:N|MP)");
    },
    s5655s_1: function (s, m) {
        return m[1]._trimRight("e");
    },
    c5663s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":(?:V0e|W)|>très", false);
    },
    c5672s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:co[ûu]ter|payer) ", false);
    },
    c5681s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">donner ", false);
    },
    c5719s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:avoir|perdre) ", false);
    },
    c5722s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:lit|fauteuil|armoire|commode|guéridon|tabouret|chaise)s?\b/i);
    },
    c5735s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, prevword1(s, m.index), ":(?:V|[NAQ].*:s)", ":(?:[NA]:.:[pi]|V0e.*:[123]p)", true);
    },
    c5786s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (look(s.slice(m.end[0]), /^ [ldmtsc]es /) && ! look(s.slice(0,m.index), /\b(?:ils?|elles?|ne) +/i)) || ( morph(dDA, prevword1(s, m.index), ":Cs", false, true) && ! look(s.slice(0,m.index), /, +$/) && ! look(s.slice(m.end[0]), /^ +(?:ils?|elles?)\b/i) && ! morph(dDA, nextword1(s, m.end[0]), ":Q", false, false) );
    },
    c5813s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D.*:f:s", false, false);
    },
    c5815s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:aller|partir) ", false);
    },
    c5826s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":V0e.*:3p", false, false) || morph(dDA, nextword1(s, m.end[0]), ":Q", false, false);
    },
    s5850s_1: function (s, m) {
        return m[1].replace(/â/g, "a").replace(/Â/g, "A");
    },
    c5858s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, prevword1(s, m.index), ">(?:être|go[ûu]t|humeur|odeur|parole|parfum|remarque|reproche|réponse|saveur|senteur|sensation|vin)", false, false);
    },
    s5858s_1: function (s, m) {
        return m[0].replace(/a/g, "â").replace(/A/g, "Â");
    },
    c5868s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:être|devenir|para[îi]tre|rendre|sembler) ", false);
    },
    s5868s_1: function (s, m) {
        return m[2].replace(/oc/g, "o");
    },
    s5873s_1: function (s, m) {
        return m[1].replace(/oc/g, "o");
    },
    c5893s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">tenir ");
    },
    c5910s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">mettre ", false);
    },
    c5912s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">faire ", false);
    },
    c5953s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:être|aller) ", false);
    },
    s5956s_1: function (s, m) {
        return m[1].replace(/auspice/g, "hospice");
    },
    s5959s_1: function (s, m) {
        return m[1].replace(/auspice/g, "hospice").replace(/Auspice/g, "Hospice");
    },
    c5993s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, nextword1(s, m.end[0]), ":[AQ]");
    },
    s6001s_1: function (s, m) {
        return m[0].replace(/ite/g, "itte");
    },
    c6008s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "bonne et due forme";
    },
    c6023s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[3], m[3]], ":[AM]", ":[QG]");
    },
    s6032s_1: function (s, m) {
        return m[1].replace(/cane/g, "canne");
    },
    c6042s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:appuyer|battre|frapper|lever|marcher) ", false);
    },
    s6042s_1: function (s, m) {
        return m[2].replace(/cane/g, "canne");
    },
    c6050s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^C(?:annes|ANNES)/) >= 0);
    },
    c6054s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^C(?:annes|ANNES)/) >= 0);
    },
    c6070s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">faire ", false);
    },
    s6082s_1: function (s, m) {
        return m[1].replace(/nt/g, "mp");
    },
    c6099s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0e", false) && morph(dDA, [m.start[3], m[3]], ":(?:Y|Oo)", false);
    },
    s6099s_1: function (s, m) {
        return m[2].replace(/sens/g, "cens");
    },
    s6109s_1: function (s, m) {
        return m[1].replace(/c/g, "s").replace(/C/g, "S");
    },
    c6125s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false);
    },
    c6128s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, prevword1(s, m.index), ":[VR]", false);
    },
    c6137s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[0].search(/^à cor et à cri$/i) >= 0);
    },
    s6146s_1: function (s, m) {
        return m[1].replace(/o/g, "ô");
    },
    s6154s_1: function (s, m) {
        return m[1].replace(/o/g, "ô").replace(/tt/g, "t");
    },
    s6160s_1: function (s, m) {
        return m[1].replace(/ô/g, "o").replace(/tt/g, "t");
    },
    s6163s_1: function (s, m) {
        return m[1].replace(/ô/g, "o").replace(/t/g, "tt");
    },
    c6166s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false);
    },
    c6196s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">tordre ", false);
    },
    c6199s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">rendre ", false);
    },
    c6213s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">couper ");
    },
    c6215s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:avoir|donner|laisser) ", false);
    },
    c6233s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:[lmtsc]es|des?|[nv]os|leurs|quels) +$/i);
    },
    c6247s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ">(?:desceller|desseller) ", false);
    },
    s6247s_1: function (s, m) {
        return m[2].replace(/descell/g, "décel").replace(/dessell/g, "décel");
    },
    c6252s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:desceller|desseller) ", false);
    },
    s6252s_1: function (s, m) {
        return m[1].replace(/descell/g, "décel").replace(/dessell/g, "décel");
    },
    c6263s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, nextword1(s, m.end[0]), ":[GVX]", ":[NAQ]", true);
    },
    c6267s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, nextword1(s, m.end[0]), ":[GV]", ":[NAQ]", false);
    },
    c6271s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, nextword1(s, m.end[0]), ":[GV]", ":[NAQ]", true);
    },
    c6275s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, nextword1(s, m.end[0]), ":G", ":[NAQ]", false);
    },
    c6279s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0e", false);
    },
    s6279s_1: function (s, m) {
        return m[2].replace(/nd/g, "nt");
    },
    c6296s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, prevword1(s, m.index), ":V0e", false, false);
    },
    c6303s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ">(?:abandonner|céder|résister) ", false) && ! look(s.slice(m.end[0]), /^ d(?:e |’)/);
    },
    c6316s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D.*:[me]:[sp]", false);
    },
    c6318s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0", false);
    },
    s6318s_1: function (s, m) {
        return m[2].replace(/î/g, "i");
    },
    c6328s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:[vn]ous|lui|leur|et toi) +$|[nm]’$/i);
    },
    s6338s_1: function (s, m) {
        return m[1].replace(/and/g, "ant");
    },
    c6345s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! ( m[1] == "bonne" && look(s.slice(0,m.index), /\bune +$/i) && look(s.slice(m.end[0]), /^ +pour toute/i) );
    },
    c6349s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:faire|perdre|donner) ", false);
    },
    c6380s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":D", false);
    },
    s6468s_1: function (s, m) {
        return m[0].slice(0,-1).replace(/ /g, "-")+"à";
    },
    c6470s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":[NAQ]");
    },
    c6472s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ]", ":[123][sp]");
    },
    c6485s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[123][sp]", ":[GQ]");
    },
    c6488s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[123][sp]", ":[GQ]");
    },
    c6494s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[123][sp]", ":[GQ]");
    },
    s6515s_1: function (s, m) {
        return m[0].replace(/ée/g, "er");
    },
    c6522s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">soulever ", false);
    },
    s6522s_1: function (s, m) {
        return m[1].slice(3);
    },
    c6540s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:être|habiter|trouver|situer|rester|demeurer?) ", false);
    },
    c6545s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">avoir ", false);
    },
    c6563s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return look(s.slice(0,m.index), /(?:la|une|cette|quelle|cette|[mts]a) +$/i);
    },
    c6570s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false);
    },
    c6579s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false);
    },
    c6603s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1] == "Notre" && look(s.slice(m.end[0]), /Père/));
    },
    s6603s_1: function (s, m) {
        return m[1].replace(/otre/g, "ôtre");
    },
    c6606s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(les?|la|du|des|aux?) +/i) && morph(dDA, [m.start[2], m[2]], ":[NAQ]", false);
    },
    s6606s_1: function (s, m) {
        return m[1].replace(/ôtre/g, "otre")._trimRight("s");
    },
    c6616s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D", false, false);
    },
    c6637s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! prevword1(s, m.index);
    },
    c6645s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ( (m[2].search(/^[nmts]e$/) >= 0) || (! (m[2].search(/^(?:confiance|envie|peine|prise|crainte|affaire|hâte|force|recours|somme)$/i) >= 0) && morphex(dDA, [m.start[2], m[2]], ":[0123][sp]", ":[QG]")) ) && morph(dDA, prevword1(s, m.index), ":Cs", false, true);
    },
    c6656s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V.*:(?:[1-3][sp])", ":(?:G|1p)") && ! ( m[0].indexOf(" leur ") && morph(dDA, [m.start[2], m[2]], ":[NA].*:[si]", false) ) && ! prevword1(s, m.index);
    },
    c6679s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":[VR]", false, false) && ! morph(dDA, nextword1(s, m.end[0]), ":(?:3s|Oo|X)", false);
    },
    c6694s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":3s", false) && ! prevword1(s, m.index);
    },
    c6710s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":3[sp]", ":Y");
    },
    c6714s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":D", false, false);
    },
    s6726s_1: function (s, m) {
        return m[1].replace(/pin/g, "pain");
    },
    c6729s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:manger|dévorer|avaler|engloutir) ");
    },
    s6729s_1: function (s, m) {
        return m[2].replace(/pin/g, "pain");
    },
    c6743s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">aller ", false);
    },
    c6751s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0e", false);
    },
    s6751s_1: function (s, m) {
        return m[2].replace(/pal/g, "pâl");
    },
    s6755s_1: function (s, m) {
        return m[1].replace(/pal/g, "pâl");
    },
    c6765s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">prendre ", false);
    },
    c6767s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">tirer ", false);
    },
    c6769s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">faire ", false);
    },
    c6773s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">prendre ", false);
    },
    c6791s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[NAQ]");
    },
    c6800s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":(?:N|A|Q|G|MP)");
    },
    c6827s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ( m[0].endsWith("s") && look(s.slice(0,m.index), /\b(?:[mtscd]es|[nv]os|leurs|quels) $/i) ) || ( m[0].endsWith("e") && look(s.slice(0,m.index), /\b(?:mon|ce|quel|un|du) $/i) );
    },
    s6827s_1: function (s, m) {
        return m[0].replace(/que/g, "c");
    },
    c6838s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false);
    },
    c6845s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, nextword1(s, m.end[0]), ":(?:Os|C)", false, true);
    },
    c6856s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, nextword1(s, m.end[0]), ":[AQ]", false);
    },
    c6897s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! nextword1(s, m.end[0]);
    },
    c6904s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">résonner ", false);
    },
    s6904s_1: function (s, m) {
        return m[1].replace(/réso/g, "raiso");
    },
    c6920s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":M1", false) && morph(dDA, prevword1(s, m.index), ":(?:R|[123][sp])", false, true);
    },
    s6940s_1: function (s, m) {
        return m[1].replace(/sale/g, "salle");
    },
    c6944s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0e", false);
    },
    s6944s_1: function (s, m) {
        return m[2].replace(/salle/g, "sale");
    },
    s6963s_1: function (s, m) {
        return m[1].replace(/scep/g,"sep");
    },
    c6966s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:être|demeurer) ", false);
    },
    s6966s_1: function (s, m) {
        return m[2].replace(/sep/g, "scep");
    },
    c6976s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">suivre ", false);
    },
    c6984s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[0].search(/^soi-disant$/i) >= 0);
    },
    c6992s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), / soit /);
    },
    c6994s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, nextword1(s, m.end[0]), ":[GY]", true, true) && ! look(s.slice(0,m.index), /quel(?:s|les?|) qu $|on $|il $/i) && ! look(s.slice(m.end[0]), / soit /);
    },
    c7000s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, prevword1(s, m.index), ":[YQ]|>(?:avec|contre|par|pour|sur) ", false, true);
    },
    c7022s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ( morphex(dDA, [m.start[2], m[2]], ":N.*:[me]:s", ":[GW]") || ((m[2].search(/^[aeéiîou]/i) >= 0) && morphex(dDA, [m.start[2], m[2]], ":N.*:f:s", ":G")) ) && ( look(s.slice(0,m.index), /^ *$|\b(?:à|avec|chez|dès|contre|devant|derrière|par|pour|sans|sur) +$|, +$| en +$|^en +$/i) || (morphex(dDA, prevword1(s, m.index), ":V", ":(?:G|W|[NA].*:[pi])") && ! look(s.slice(0,m.index), /\bce que?\b/i)) );
    },
    s7038s_1: function (s, m) {
        return m[1].replace(/sur/g, "sûr");
    },
    s7042s_1: function (s, m) {
        return m[1].replace(/sur/g, "sûr");
    },
    c7050s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":Y", false);
    },
    s7050s_1: function (s, m) {
        return m[1].replace(/sur/g, "sûr");
    },
    c7068s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":N", ":[GMY]|>(?:fonds?|grande (?:envergure|ampleur|importance)|envergure|ampleur|importance|départ|surveillance) ") && ! look(s.slice(0,m.index), /accompl|dél[éè]gu/);
    },
    s7068s_1: function (s, m) {
        return m[1].replace(/â/g, "a");
    },
    s7073s_1: function (s, m) {
        return m[1].replace(/â/g, "a");
    },
    c7088s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">aller ", false);
    },
    c7091s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">faire ", false);
    },
    s7094s_1: function (s, m) {
        return m[1].replace(/au/g, "ô");
    },
    c7106s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0e", false) && morph(dDA, [m.start[3], m[3]], ":Y|>(?:ne|en|y) ", false);
    },
    c7128s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">avoir ", false);
    },
    s7139s_1: function (s, m) {
        return m[1].replace(/énén/g, "enim");
    },
    s7142s_1: function (s, m) {
        return m[1].replace(/enim/g, "énén");
    },
    s7154s_1: function (s, m) {
        return m[1].replace(/re/g, "").replace(/t/g, "");
    },
    c7164s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[NAQ].*:[me]:s");
    },
    c7194s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[1]._isDigit() && ! m[2]._isDigit() && ! morph(dDA, [m.start[0], m[0]], ":", false) && ! morph(dDA, [m.start[2], m[2]], ":G", false) && _oDict.isValid(m[1]+m[2]);
    },
    c7194s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[2] != "là" && ! (m[1].search(/^(?:ex|mi|quasi|semi|non|demi|pro|anti|multi|pseudo|proto|extra)$/i) >= 0) && ! m[1]._isDigit() && ! m[2]._isDigit() && ! morph(dDA, [m.start[2], m[2]], ":G", false) && ! morph(dDA, [m.start[0], m[0]], ":", false) && ! _oDict.isValid(m[1]+m[2]);
    },
    c7209s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return look(s.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ,] +$/);
    },
    s7209s_1: function (s, m) {
        return m[0].toLowerCase();
    },
    c7218s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return look(s.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ,] +$/) && !( ( m[0]=="Juillet" && look(s.slice(0,m.index), /monarchie +de +$/i) ) || ( m[0]=="Octobre" && look(s.slice(0,m.index), /révolution +d’$/i) ) );
    },
    s7218s_1: function (s, m) {
        return m[0].toLowerCase();
    },
    c7244s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[0].search(/^fonctions? /i) >= 0) || ! look(s.slice(0,m.index), /\ben $/i);
    },
    s7249s_1: function (s, m) {
        return m[1].replace(/é/g, "É");
    },
    c7261s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[2]._isTitle() && morphex(dDA, [m.start[1], m[1]], ":N", ":(?:A|V0e|D|R|B)") && ! (m[0].search(/^[oO]céan Indien/i) >= 0);
    },
    s7261s_1: function (s, m) {
        return m[2].toLowerCase();
    },
    c7261s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[2]._isLowerCase() && ! m[2].startsWith("canadienne") && ( (m[1].search(/^(?:certaine?s?|cette|ce[ts]?|[dl]es|[nv]os|quelques|plusieurs|chaque|une|aux)$/i) >= 0) || ( (m[1].search(/^un$/i) >= 0) && ! look(s.slice(m.end[0]), /(?:approximatif|correct|courant|parfait|facile|aisé|impeccable|incompréhensible)/) ) );
    },
    s7261s_2: function (s, m) {
        return m[2]._toCapitalize();
    },
    s7280s_1: function (s, m) {
        return m[1]._toCapitalize();
    },
    c7288s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:parler|cours|leçon|apprendre|étudier|traduire|enseigner|professeur|enseignant|dictionnaire|méthode) ", false);
    },
    s7288s_1: function (s, m) {
        return m[2].toLowerCase();
    },
    s7293s_1: function (s, m) {
        return m[1].toLowerCase();
    },
    c7321s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return look(s.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/);
    },
    s7335s_1: function (s, m) {
        return m[1]._toCapitalize();
    },
    s7338s_1: function (s, m) {
        return m[1]._toCapitalize();
    },
    c7348s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (m[2].search(/^(?:Mètre|Watt|Gramme|Seconde|Ampère|Kelvin|Mole|Cand[eé]la|Hertz|Henry|Newton|Pascal|Joule|Coulomb|Volt|Ohm|Farad|Tesla|W[eé]ber|Radian|Stéradian|Lumen|Lux|Becquerel|Gray|Sievert|Siemens|Katal)s?|(?:Exa|P[ée]ta|Téra|Giga|Méga|Kilo|Hecto|Déc[ai]|Centi|Mi(?:lli|cro)|Nano|Pico|Femto|Atto|Ze(?:pto|tta)|Yo(?:cto|etta))(?:mètre|watt|gramme|seconde|ampère|kelvin|mole|cand[eé]la|hertz|henry|newton|pascal|joule|coulomb|volt|ohm|farad|tesla|w[eé]ber|radian|stéradian|lumen|lux|becquerel|gray|sievert|siemens|katal)s?/) >= 0);
    },
    s7348s_1: function (s, m) {
        return m[2].toLowerCase();
    },
    c7364s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":Y");
    },
    s7364s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7371s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V1") && ! m[1].slice(0,1)._isUpperCase() && (m[1].endsWith("z") || ! look(s.slice(0,m.index), /\b(?:quelqu(?:e chose|’une?)|(?:l(es?|a)|nous|vous|me|te|se)[ @]trait|personne|point +$|rien(?: +[a-zéèêâîûù]+|) +$)/i));
    },
    s7371s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7381s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V1", ":M[12P]");
    },
    s7381s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7388s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V1", false);
    },
    s7388s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7395s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":[123][sp]");
    },
    c7402s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V1", ":[NM]") && ! morph(dDA, prevword1(s, m.index), ">(?:tenir|passer) ", false);
    },
    s7402s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7410s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V1", false);
    },
    s7410s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7417s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V1", ":[NM]");
    },
    s7417s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7424s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":Q", false) && ! morph(dDA, prevword1(s, m.index), "V0.*[12]p", false);
    },
    c7431s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:devoir|savoir|pouvoir) ", false) && morphex(dDA, [m.start[2], m[2]], ":(?:Q|A|[123][sp])", ":[GYW]");
    },
    s7431s_1: function (s, m) {
        return suggVerbInfi(m[2]);
    },
    c7440s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":(?:V1.*:Q|[13]s|2[sp])", ":[GYWM]") && ! look(s.slice(0,m.index), /\bque? +$/i);
    },
    s7440s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7451s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:commencer|finir) ", false) && morphex(dDA, [m.start[2], m[2]], ":V", ":[NGM]") && ! m[2].slice(0,1)._isUpperCase();
    },
    s7451s_1: function (s, m) {
        return suggVerbInfi(m[2]);
    },
    c7460s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:cesser|décider|défendre|suggérer|commander|essayer|tenter|choisir|permettre|interdire) ", false) && analysex(m[2], ":(?:Q|2p)", ":M");
    },
    s7460s_1: function (s, m) {
        return suggVerbInfi(m[2]);
    },
    c7471s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":N.*:m:[si]", ":G") && morphex(dDA, [m.start[2], m[2]], ":Y", ">aller |:M") && isNextVerb(dDA, s.slice(m.end[0]), m.end[0]);
    },
    s7471s_1: function (s, m) {
        return suggVerbPpas(m[2], ":m:s");
    },
    c7476s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":N.*:f:[si]", ":G") && morphex(dDA, [m.start[2], m[2]], ":Y", ">aller |:M") && isNextVerb(dDA, s.slice(m.end[0]), m.end[0]);
    },
    s7476s_1: function (s, m) {
        return suggVerbPpas(m[2], ":f:s");
    },
    c7481s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":N.*:[si]", ":G") && morphex(dDA, [m.start[2], m[2]], ":Y", ">aller |:M") && isNextVerb(dDA, s.slice(m.end[0]), m.end[0]);
    },
    s7481s_1: function (s, m) {
        return suggVerbPpas(m[2], ":s");
    },
    c7491s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":N.*:[pi]", ":G") && morphex(dDA, [m.start[2], m[2]], ":Y", ">aller |:M") && isNextVerb(dDA, s.slice(m.end[0]), m.end[0]);
    },
    s7491s_1: function (s, m) {
        return suggVerbPpas(m[2], ":p");
    },
    c7503s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":A", false);
    },
    s7503s_1: function (s, m) {
        return m[1].slice(0,-1);
    },
    c7523s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V", false);
    },
    c7527s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">sembler ", false);
    },
    c7543s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ]", false) && isEndOfNG(dDA, s.slice(m.end[0]), m.end[0]);
    },
    c7548s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V[123]_i", false) && isNextNotCOD(dDA, s.slice(m.end[0]), m.end[0]);
    },
    c7550s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":A", false) && morphex(dDA, [m.start[2], m[2]], ":A", ":[GM]");
    },
    c7552s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":A", false);
    },
    c7554s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ].*:s", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:s", ":[GV]") && isEndOfNG(dDA, s.slice(m.end[0]), m.end[0]);
    },
    c7557s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ]", ":V0") && morphex(dDA, [m.start[2], m[2]], ":[NAQ]", ":(?:G|[123][sp]|P)");
    },
    c7568s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ]", false) && isEndOfNG(dDA, s.slice(m.end[0]), m.end[0]);
    },
    c7572s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:[jn]’|tu )$/i);
    },
    c7580s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ]", ":[GY]") && isEndOfNG(dDA, s.slice(m.end[0]), m.end[0]);
    },
    c7583s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ]", false) && isEndOfNG(dDA, s.slice(m.end[0]), m.end[0]);
    },
    c7586s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ]", false) && isEndOfNG(dDA, s.slice(m.end[0]), m.end[0]);
    },
    c7590s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! prevword1(s, m.index);
    },
    c7593s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":N", ":[GY]") && isEndOfNG(dDA, s.slice(m.end[0]), m.end[0]);
    },
    c7595s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ]", false) && isEndOfNG(dDA, s.slice(m.end[0]), m.end[0]);
    },
    c7597s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ]", ":Y") && isEndOfNG(dDA, s.slice(m.end[0]), m.end[0]);
    },
    c7619s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0e", false);
    },
    c7619s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[2].endsWith("e") && morphex(dDA, [m.start[2], m[2]], ":V1.*:Ip.*:[13]s", ":(?:[GM]|A:e)") && ! look(s.slice(0,m.index), /\belle +(?:ne +|n’|)$/i);
    },
    s7619s_2: function (s, m) {
        return suggVerbPpas(m[2], ":m:s");
    },
    c7619s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && m[2].endsWith("s") && morphex(dDA, [m.start[2], m[2]], ":V1.*:Ip.*:2s", ":(?:[GM]|A:e)") && ! look(s.slice(0,m.index), /\belles +(?:ne +|n’|)$/i);
    },
    s7619s_3: function (s, m) {
        return suggVerbPpas(m[2], ":m:p");
    },
    c7627s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false);
    },
    c7627s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[2].endsWith("e") && morphex(dDA, [m.start[2], m[2]], ":V1.*:Ip.*:[13]s", ":[GM]|>envie ");
    },
    s7627s_2: function (s, m) {
        return suggVerbPpas(m[2], ":m:s");
    },
    c7627s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && m[2].endsWith("s") && morphex(dDA, [m.start[2], m[2]], ":V1.*:Ip.*:2s", ":[GM]");
    },
    s7627s_3: function (s, m) {
        return suggVerbPpas(m[2], ":m:p");
    },
    c7685s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (m[2].search(/^(?:fini|terminé)s?/i) >= 0) && morph(dDA, prevword1(s, m.index), ":C", false, true);
    },
    c7685s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (m[2].search(/^(?:assez|trop)$/i) >= 0) && (look(s.slice(m.end[0]), /^ +d(?:e |’)/) || ! nextword1(s, m.end[0]));
    },
    c7685s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":A", ":[GVW]") && morph(dDA, prevword1(s, m.index), ":C", false, true);
    },
    c7705s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">aller", false) && ! look(s.slice(m.end[0]), / soit /);
    },
    c7713s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":[AN].*:[me]:[pi]|>(?:être|sembler|devenir|re(?:ster|devenir)|para[îi]tre) .*:[123]p|>(?:affirmer|trouver|croire|désirer|estime|préférer|penser|imaginer|voir|vouloir|aimer|adorer|souhaiter) ") && ! morph(dDA, nextword1(s, m.end[0]), ":A.*:[me]:[pi]", false);
    },
    c7730s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V", false);
    },
    s7730s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7737s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V", false);
    },
    s7737s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7744s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V", false);
    },
    s7744s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7752s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:faire|vouloir) ", false) && ! look(s.slice(0,m.index), /\b(?:en|[mtsld]es?|[nv]ous|un) +$/i) && morphex(dDA, [m.start[2], m[2]], ":V", ":M") && ! ((m[1].search(/^(?:fait|vouloir)$/i) >= 0) && m[2].endsWith("é")) && ! ((m[1].search(/^(?:fait|vouloir)s$/i) >= 0) && m[2].endsWith("és"));
    },
    s7752s_1: function (s, m) {
        return suggVerbInfi(m[2]);
    },
    c7763s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">faire ", false) && morphex(dDA, [m.start[2], m[2]], ":V", ":M");
    },
    s7763s_1: function (s, m) {
        return suggVerbInfi(m[2]);
    },
    c7771s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":M");
    },
    s7771s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7779s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">savoir :V", false) && morph(dDA, [m.start[2], m[2]], ":V", false) && ! look(s.slice(0,m.index), /\b(?:[mts]e|[vn]ous|les?|la|un) +$/i);
    },
    s7779s_1: function (s, m) {
        return suggVerbInfi(m[2]);
    },
    c7787s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":(?:Q|2p)", false);
    },
    s7787s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7795s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":(?:Q|2p)", ":N");
    },
    s7795s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7803s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":Q", false);
    },
    s7803s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c7812s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">être ", false);
    },
    c7812s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":(?:Y|[123][sp])", ":Q");
    },
    s7812s_2: function (s, m) {
        return suggVerbPpas(m[2]);
    },
    c7812s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && morph(dDA, [m.start[1], m[1]], ":[123]s", false) && morph(dDA, [m.start[2], m[2]], ":Q.*:p", false) && ! look(s.slice(0,m.index), /\bque?[, ]|\bon (?:ne |)$/i);
    },
    s7812s_3: function (s, m) {
        return suggSing(m[2]);
    },
    c7865s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morph(dDA, [m.start[1], m[1]], ">(?:être|sembler|devenir|re(?:ster|devenir)|para[îi]tre) ", false) || m[1].endsWith(" été")) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GWYsi]");
    },
    s7865s_1: function (s, m) {
        return suggSing(m[2]);
    },
    c7886s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morph(dDA, [m.start[1], m[1]], ">(?:être|sembler|devenir|re(?:ster|devenir)|para[îi]tre) ", false) || m[1].endsWith(" été")) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GWYsi]");
    },
    s7886s_1: function (s, m) {
        return suggSing(m[2]);
    },
    c7895s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morph(dDA, [m.start[2], m[2]], ">(?:être|sembler|devenir|re(?:ster|devenir)|para[îi]tre) ", false) || m[2].endsWith(" été")) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:p", ":[GWYsi]") || morphex(dDA, [m.start[3], m[3]], ":[AQ].*:f", ":[GWYme]"));
    },
    s7895s_1: function (s, m) {
        return suggMasSing(m[3]);
    },
    c7909s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (morph(dDA, [m.start[1], m[1]], ">seule ", false) && look(s.slice(m.end[0]), /^ +que? /)) && ( morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:p", ":[GWYsi]") || ( morphex(dDA, [m.start[1], m[1]], ":[AQ].*:f", ":[GWYme]") && ! morph(dDA, nextword1(s, m.end[0]), ":N.*:f", false, false) ) );
    },
    s7909s_1: function (s, m) {
        return suggMasSing(m[1]);
    },
    c7920s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ].*:p", ":[GWYsi]") || ( morphex(dDA, [m.start[1], m[1]], ":[AQ].*:f", ":[GWYme]") && ! morph(dDA, nextword1(s, m.end[0]), ":N.*:f", false, false) );
    },
    s7920s_1: function (s, m) {
        return suggMasSing(m[1]);
    },
    c7928s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morph(dDA, [m.start[2], m[2]], ">(?:être|sembler|devenir|re(?:ster|devenir)|para[îi]tre) ", false) || m[2].endsWith(" été")) && ( morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:p", ":[GWYsi]") || ( morphex(dDA, [m.start[3], m[3]], ":[AQ].*:f", ":[GWYme]") && ! morph(dDA, nextword1(s, m.end[0]), ":N.*:f", false, false) ) ) && ! morph(dDA, prevword1(s, m.index), ":R", false, false);
    },
    s7928s_1: function (s, m) {
        return suggMasSing(m[3]);
    },
    c7940s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morph(dDA, [m.start[2], m[2]], ">(?:être|sembler|devenir|re(?:ster|devenir)|para[îi]tre) ", false) || m[2].endsWith(" été")) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:p", ":[GWYsi]") || morphex(dDA, [m.start[3], m[3]], ":[AQ].*:m", ":[GWYfe]")) && ! morph(dDA, prevword1(s, m.index), ":R|>de ", false, false);
    },
    s7940s_1: function (s, m) {
        return suggFemSing(m[3]);
    },
    c7954s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return (morph(dDA, [m.start[2], m[2]], ">(?:être|sembler|devenir|re(?:ster|devenir)|para[îi]tre) ", false) || m[2].endsWith(" été")) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:p", ":[GWYsi]") || morphex(dDA, [m.start[3], m[3]], ":[AQ].*:m", ":[GWYfe]"));
    },
    s7954s_1: function (s, m) {
        return suggFemSing(m[3]);
    },
    c7963s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[2].search(/^légion$/i) >= 0) && ! look(s.slice(0,m.index), /\b(?:nous|ne) +$/i) && ((morph(dDA, [m.start[1], m[1]], ">(?:être|sembler|devenir|re(?:ster|devenir)|para[îi]tre) ", false) && morph(dDA, [m.start[1], m[1]], ":1p", false)) || m[1].endsWith(" été")) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:s", ":[GWYpi]");
    },
    s7963s_1: function (s, m) {
        return suggPlur(m[2]);
    },
    c7974s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[3].search(/^légion$/i) >= 0) && (morph(dDA, [m.start[2], m[2]], ">(?:être|sembler|devenir|re(?:ster|devenir)|para[îi]tre) ", false) || m[2].endsWith(" été")) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:s", ":[GWYpi]") || morphex(dDA, [m.start[3], m[3]], ":[AQ].*:f", ":[GWYme]")) && ! look(s.slice(0,m.index), /ce que? +$/i) && (! (m[1].search(/^(?:ceux-(?:ci|là)|lesquels)$/) >= 0) || ! morph(dDA, prevword1(s, m.index), ":R", false, false));
    },
    s7974s_1: function (s, m) {
        return suggMasPlur(m[3]);
    },
    c7993s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[3].search(/^légion$/i) >= 0) && (morph(dDA, [m.start[2], m[2]], ">(?:être|sembler|devenir|re(?:ster|devenir)|para[îi]tre) ", false) || m[2].endsWith(" été")) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:s", ":[GWYpi]") || morphex(dDA, [m.start[3], m[3]], ":[AQ].*:m", ":[GWYfe]")) && (! (m[1].search(/^(?:elles|celles-(?:ci|là)|lesquelles)$/i) >= 0) || ! morph(dDA, prevword1(s, m.index), ":R", false, false));
    },
    s7993s_1: function (s, m) {
        return suggFemPlur(m[3]);
    },
    c8006s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">avoir ", false) && morphex(dDA, [m.start[2], m[2]], ":[123]s", ":[GNAQWY]");
    },
    s8006s_1: function (s, m) {
        return suggVerbPpas(m[2]);
    },
    c8021s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:sembler|para[îi]tre|pouvoir|penser|préférer|croire|d(?:evoir|éclarer|ésirer|étester|ire)|vouloir|affirmer|aimer|adorer|souhaiter|estimer|imaginer|risquer) ", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GWYsi]");
    },
    s8021s_1: function (s, m) {
        return suggSing(m[2]);
    },
    c8034s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:sembler|para[îi]tre|pouvoir|penser|préférer|croire|d(?:evoir|éclarer|ésirer|étester|ire)|vouloir|affirmer|aimer|adorer|souhaiter|estimer|imaginer|risquer) ", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GWYsi]");
    },
    s8034s_1: function (s, m) {
        return suggSing(m[2]);
    },
    c8044s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ">(?:sembler|para[îi]tre|pouvoir|penser|préférer|croire|d(?:evoir|éclarer|ésirer|étester|ire)|vouloir|affirmer|aimer|adorer|souhaiter|estimer|imaginer|risquer) ", false) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:p", ":[GWYsi]") || morphex(dDA, [m.start[3], m[3]], ":[AQ].*:f", ":[GWYme]"));
    },
    s8044s_1: function (s, m) {
        return suggMasSing(m[3]);
    },
    c8057s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ">(?:sembler|para[îi]tre|pouvoir|penser|préférer|croire|d(?:evoir|éclarer|ésirer|étester|ire)|vouloir|affirmer|aimer|adorer|souhaiter|estimer|imaginer|risquer) ", false) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:p", ":[MWYsi]") || morphex(dDA, [m.start[3], m[3]], ":[AQ].*:f", ":[GWYme]")) && ! morph(dDA, prevword1(s, m.index), ":R", false, false);
    },
    s8057s_1: function (s, m) {
        return suggMasSing(m[3]);
    },
    c8067s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ">(?:sembler|para[îi]tre|pouvoir|penser|préférer|croire|d(?:evoir|éclarer|ésirer|étester|ire)|vouloir|affirmer|aimer|adorer|souhaiter|estimer|imaginer|risquer) ", false) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:p", ":[GWYsi]") || morphex(dDA, [m.start[3], m[3]], ":[AQ].*:m", ":[GWYfe]")) && ! morph(dDA, prevword1(s, m.index), ":R", false, false);
    },
    s8067s_1: function (s, m) {
        return suggFemSing(m[3]);
    },
    c8078s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ">(?:sembler|para[îi]tre|pouvoir|penser|préférer|croire|d(?:evoir|éclarer|ésirer|étester|ire)|vouloir|affirmer|aimer|adorer|souhaiter|estimer|imaginer|risquer) ", false) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:p", ":[MWYsi]") || morphex(dDA, [m.start[3], m[3]], ":[AQ].*:m", ":[GWYfe]"));
    },
    s8078s_1: function (s, m) {
        return suggFemSing(m[3]);
    },
    c8087s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[2].search(/^légion$/i) >= 0) && morph(dDA, [m.start[1], m[1]], ">(?:sembler|para[îi]tre|pouvoir|penser|préférer|croire|d(?:evoir|éclarer|ésirer|étester|ire)|vouloir|affirmer|aimer|adorer|souhaiter|estimer|imaginer|risquer) ", false) && morph(dDA, [m.start[1], m[1]], ":1p", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:s", ":[GWYpi]");
    },
    s8087s_1: function (s, m) {
        return suggPlur(m[2]);
    },
    c8097s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[3].search(/^légion$/i) >= 0) && morph(dDA, [m.start[2], m[2]], ">(?:sembler|para[îi]tre|pouvoir|penser|préférer|croire|d(?:evoir|éclarer|ésirer|étester|ire)|vouloir|affirmer|aimer|adorer|souhaiter|estimer|imaginer|risquer) ", false) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:s", ":[GWYpi]") || morphex(dDA, [m.start[3], m[3]], ":[AQ].*:f", ":[GWYme]")) && (! (m[1].search(/^(?:ceux-(?:ci|là)|lesquels)$/) >= 0) || ! morph(dDA, prevword1(s, m.index), ":R", false, false));
    },
    s8097s_1: function (s, m) {
        return suggMasPlur(m[3]);
    },
    c8107s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[3].search(/^légion$/i) >= 0) && morph(dDA, [m.start[2], m[2]], ">(?:sembler|para[îi]tre|pouvoir|penser|préférer|croire|d(?:evoir|éclarer|ésirer|étester|ire)|vouloir|affirmer|aimer|adorer|souhaiter|estimer|imaginer|risquer) ", false) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:s", ":[GWYpi]") || morphex(dDA, [m.start[3], m[3]], ":[AQ].*:m", ":[GWYfe]")) && (! (m[1].search(/^(?:elles|celles-(?:ci|là)|lesquelles)$/) >= 0) || ! morph(dDA, prevword1(s, m.index), ":R", false, false));
    },
    s8107s_1: function (s, m) {
        return suggFemPlur(m[3]);
    },
    c8125s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GMWYsi]") && ! morph(dDA, [m.start[1], m[1]], ":G", false);
    },
    s8125s_1: function (s, m) {
        return suggSing(m[2]);
    },
    c8130s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[2].search(/^légion$/i) >= 0) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:s", ":[GWYpi]") && ! morph(dDA, [m.start[1], m[1]], ":G", false);
    },
    s8130s_1: function (s, m) {
        return suggPlur(m[2]);
    },
    c8138s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[3].search(/^légion$/i) >= 0) && ((morphex(dDA, [m.start[3], m[3]], ":[AQ].*:f", ":[GWme]") && morphex(dDA, [m.start[2], m[2]], ":m", ":[Gfe]")) || (morphex(dDA, [m.start[3], m[3]], ":[AQ].*:m", ":[GWfe]") && morphex(dDA, [m.start[2], m[2]], ":f", ":[Gme]"))) && ! ( morph(dDA, [m.start[3], m[3]], ":p", false) && morph(dDA, [m.start[2], m[2]], ":s", false) ) && ! morph(dDA, prevword1(s, m.index), ":(?:R|P|Q|Y|[123][sp])", false, false) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s8138s_1: function (s, m) {
        return switchGender(m[3]);
    },
    c8158s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[2].search(/^légion$/i) >= 0) && ((morphex(dDA, [m.start[1], m[1]], ":M[1P].*:f", ":[GWme]") && morphex(dDA, [m.start[2], m[2]], ":m", ":[GWfe]")) || (morphex(dDA, [m.start[1], m[1]], ":M[1P].*:m", ":[GWfe]") && morphex(dDA, [m.start[2], m[2]], ":f", ":[GWme]"))) && ! morph(dDA, prevword1(s, m.index), ":(?:R|P|Q|Y|[123][sp])", false, false) && ! look(s.slice(0,m.index), /\b(?:et|ou|de) +$/);
    },
    s8158s_1: function (s, m) {
        return switchGender(m[2]);
    },
    c8177s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":A.*:p", ":(?:G|E|M1|W|s|i)");
    },
    s8177s_1: function (s, m) {
        return suggSing(m[1]);
    },
    c8185s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":A.*:[fp]", ":(?:G|E|M1|W|m:[si])");
    },
    s8185s_1: function (s, m) {
        return suggMasSing(m[1]);
    },
    c8193s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":A.*:[mp]", ":(?:G|E|M1|W|f:[si])|>(?:désoler|pire) ");
    },
    s8193s_1: function (s, m) {
        return suggFemSing(m[1]);
    },
    c8201s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":A.*:[fs]", ":(?:G|E|M1|W|m:[pi])|>(?:désoler|pire) ");
    },
    s8201s_1: function (s, m) {
        return suggMasPlur(m[1]);
    },
    c8213s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":A.*:[ms]", ":(?:G|E|M1|W|f:[pi])|>(?:désoler|pire) ");
    },
    s8213s_1: function (s, m) {
        return suggFemPlur(m[1]);
    },
    c8223s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], "V0e", false) && m[3] != "rendu";
    },
    c8233s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":(?:[123][sp]|Y|[NAQ].*:p)", ":[GWsi]");
    },
    s8233s_1: function (s, m) {
        return suggSing(m[1]);
    },
    c8237s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":(?:[123][sp]|Y|[NAQ].*:p)", ":[GWsi]");
    },
    s8237s_1: function (s, m) {
        return suggSing(m[1]);
    },
    c8241s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":(?:[123][sp]|Y|[NAQ].*:[pf])", ":(?:G|W|[me]:[si])|question ") && ! (m[1] == "ce" && morph(dDA, [m.start[2], m[2]], ":Y", false));
    },
    s8241s_1: function (s, m) {
        return suggMasSing(m[2]);
    },
    c8245s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":(?:[123][sp]|Y|[NAQ].*:[pm])", ":(?:G|W|[fe]:[si])");
    },
    s8245s_1: function (s, m) {
        return suggFemSing(m[1]);
    },
    c8249s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":(?:[123][sp]|Y|[NAQ].*:s)", ":[GWpi]");
    },
    s8249s_1: function (s, m) {
        return suggPlur(m[1]);
    },
    c8253s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^légion$/i) >= 0) && (morphex(dDA, [m.start[1], m[1]], ":(?:[123][sp]|Y|[NAQ].*:s)", ":[GWpi]") || morphex(dDA, [m.start[1], m[1]], ":(?:[123][sp]|[AQ].*:f)", ":[GWme]"));
    },
    s8253s_1: function (s, m) {
        return suggMasPlur(m[1]);
    },
    c8257s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^légion$/i) >= 0) && (morphex(dDA, [m.start[1], m[1]], ":(?:[123][sp]|Y|[NAQ].*:s)", ":[GWpi]") || morphex(dDA, [m.start[1], m[1]], ":(?:[123][sp]|[AQ].*:m)", ":[GWfe]"));
    },
    s8257s_1: function (s, m) {
        return suggFemPlur(m[1]);
    },
    c8288s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ]", ":[QWGBMpi]") && ! (m[1].search(/^(?:légion|nombre|cause)$/i) >= 0) && ! look(s.slice(0,m.index), /\bce que?\b/i);
    },
    s8288s_1: function (s, m) {
        return suggPlur(m[1]);
    },
    c8288s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && morphex(dDA, [m.start[1], m[1]], ":V", ":(?:N|A|Q|W|G|3p)") && ! look(s.slice(0,m.index), /\bce que?\b/i);
    },
    s8288s_2: function (s, m) {
        return suggVerbPpas(m[1], ":m:p");
    },
    c8299s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:montrer|penser|révéler|savoir|sentir|voir|vouloir) ", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GWYsi]");
    },
    s8299s_1: function (s, m) {
        return suggSing(m[2]);
    },
    c8307s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:montrer|penser|révéler|savoir|sentir|voir|vouloir) ", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:p", ":[GWYsi]");
    },
    s8307s_1: function (s, m) {
        return suggSing(m[2]);
    },
    c8315s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ">(?:montrer|penser|révéler|savoir|sentir|voir|vouloir) ", false) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:p", ":[GWsi]") || morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:f", ":[GWYme]")) && (! (m[1].search(/^(?:celui-(?:ci|là)|lequel)$/) >= 0) || ! morph(dDA, prevword1(s, m.index), ":R", false, false));
    },
    s8315s_1: function (s, m) {
        return suggMasSing(m[3]);
    },
    c8325s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ">(?:montrer|penser|révéler|savoir|sentir|voir|vouloir) ", false) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:p", ":[GWsi]") || morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:m", ":[GWYfe]")) && ! morph(dDA, prevword1(s, m.index), ":R", false, false);
    },
    s8325s_1: function (s, m) {
        return suggFemSing(m[3]);
    },
    c8336s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ">(?:montrer|penser|révéler|savoir|sentir|voir|vouloir) ", false) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:p", ":[GWsi]") || morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:m", ":[GWYfe]"));
    },
    s8336s_1: function (s, m) {
        return suggFemSing(m[3]);
    },
    c8345s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:montrer|penser|révéler|savoir|sentir|voir|vouloir) ", false) && morphex(dDA, [m.start[2], m[2]], ":[NAQ].*:s", ":[GWpi]");
    },
    s8345s_1: function (s, m) {
        return suggPlur(m[2]);
    },
    c8353s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ">(?:montrer|penser|révéler|savoir|sentir|voir|vouloir) ", false) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:s", ":[GWpi]") || morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:f", ":[GWYme]")) && (! (m[1].search(/^(?:ceux-(?:ci|là)|lesquels)$/) >= 0) || ! morph(dDA, prevword1(s, m.index), ":R", false, false));
    },
    s8353s_1: function (s, m) {
        return suggMasPlur(m[3]);
    },
    c8363s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ">(?:montrer|penser|révéler|savoir|sentir|voir|vouloir) ", false) && (morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:s", ":[GWpi]") || morphex(dDA, [m.start[3], m[3]], ":[NAQ].*:m", ":[GWYfe]")) && (! (m[1].search(/^(?:elles|celles-(?:ci|là)|lesquelles)$/) >= 0) || ! morph(dDA, prevword1(s, m.index), ":R", false, false));
    },
    s8363s_1: function (s, m) {
        return suggFemPlur(m[3]);
    },
    c8373s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:trouver|considérer|croire|rendre|voilà) ", false) && morphex(dDA, [m.start[2], m[2]], ":[AQ]:(?:[me]:p|f)", ":(?:G|Y|[AQ]:m:[is])");
    },
    s8373s_1: function (s, m) {
        return suggMasSing(m[2]);
    },
    c8377s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:trouver|considérer|croire|rendre|voilà) ", false) && morphex(dDA, [m.start[2], m[2]], ":[AQ]:(?:[fe]:p|m)", ":(?:G|Y|[AQ]:f:[is])");
    },
    s8377s_1: function (s, m) {
        return suggFemSing(m[2]);
    },
    c8381s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:trouver|considérer|croire|rendre|voilà) ", false) && morphex(dDA, [m.start[2], m[2]], ":[AQ].*:s", ":(?:G|Y|[AQ].*:[ip])");
    },
    s8381s_1: function (s, m) {
        return suggPlur(m[2]);
    },
    c8385s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ">(?:trouver|considérer|croire|rendre|voilà) ", false) && morphex(dDA, [m.start[3], m[3]], ":[AQ].*:p", ":(?:G|Y|[AQ].*:[is])");
    },
    s8385s_1: function (s, m) {
        return suggSing(m[3]);
    },
    c8389s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:trouver|considérer|croire|rendre) .*:3s", false) && morphex(dDA, [m.start[2], m[2]], ":[AQ].*:p", ":(?:G|Y|[AQ].*:[is])");
    },
    s8389s_1: function (s, m) {
        return suggSing(m[2]);
    },
    c8389s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:trouver|considérer|croire|rendre) .*:3p", false) && morphex(dDA, [m.start[2], m[2]], ":[AQ].*:s", ":(?:G|Y|[AQ].*:[ip])");
    },
    s8389s_2: function (s, m) {
        return suggSing(m[2]);
    },
    c8395s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ( morphex(dDA, [m.start[1], m[1]], ">(?:trouver|considérer|croire|rendre|voilà) ", ":1p") || (morph(dDA, [m.start[1], m[1]], ">(?:trouver|considérer|croire) .*:1p", false) && look(s.slice(0,m.index), /\bn(?:ous|e) +$/)) ) && morphex(dDA, [m.start[2], m[2]], ":[AQ].*:s", ":(?:G|Y|[AQ].*:[ip])");
    },
    s8395s_1: function (s, m) {
        return suggPlur(m[2]);
    },
    c8432s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">avoir ", false) && morph(dDA, [m.start[3], m[3]], ":Y", false);
    },
    c8434s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[3].search(/^(?:barre|confiance|cours|envie|peine|prise|crainte|cure|affaire|hâte|force|recours)$/i) >= 0) && morph(dDA, prevword1(s, m.index), ">puisque? ", false, true) && morph(dDA, [m.start[2], m[2]], ":V0a", false) && ! m[3]._isUpperCase() && morphex(dDA, [m.start[3], m[3]], ":(?:[123][sp]|Q.*:[fp])", ":(?:G|W|Q.*:m:[si])");
    },
    s8434s_1: function (s, m) {
        return suggMasSing(m[3]);
    },
    c8446s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[4].search(/^(?:barre|confiance|cours|envie|peine|prise|crainte|cure|affaire|hâte|force|recours)$/i) >= 0) && morph(dDA, prevword1(s, m.index), ">puisque? ", false, true) && morph(dDA, [m.start[3], m[3]], ":V0a", false) && ! m[4]._isUpperCase() && morphex(dDA, [m.start[4], m[4]], ":(?:[123][sp]|Q.*:[fp])", ":(?:G|W|Q.*:m:[si])");
    },
    s8446s_1: function (s, m) {
        return suggMasSing(m[4]);
    },
    c8457s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false) && morphex(dDA, [m.start[2], m[2]], ":V[0-3]..t.*:Q.*:s", ":[GWpi]");
    },
    s8457s_1: function (s, m) {
        return suggPlur(m[2]);
    },
    c8466s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return look(s.slice(m.end[0]), /^ *$/) && morph(dDA, [m.start[2], m[2]], ":V0a", false) && morphex(dDA, [m.start[1], m[1]], ":(?:M|Os|N)", ":R") && morphex(dDA, [m.start[3], m[3]], ":V[0-3]..t_.*:Q.*:s", ":[GWpi]") && ! look(s.slice(0,m.index), /\bque +$/);
    },
    s8466s_1: function (s, m) {
        return suggPlur(m[3]);
    },
    c8476s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false) && morphex(dDA, [m.start[2], m[2]], ":V[0-3]..t.*:Q.*:p", ":[GWsi]");
    },
    s8476s_1: function (s, m) {
        return m[2].slice(0,-1);
    },
    c8485s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":V0a", false) && morphex(dDA, [m.start[3], m[3]], ":V[0-3]..t_.*:Q.*:p", ":[GWsi]") && ! look(s.slice(0,m.index), /\bque? /);
    },
    s8485s_1: function (s, m) {
        return m[3].slice(0,-1);
    },
    c8494s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">avoir ", false) && morphex(dDA, [m.start[2], m[2]], ":Q.*:(?:f|m:p)", ":m:[si]");
    },
    s8494s_1: function (s, m) {
        return suggMasSing(m[2]);
    },
    c8503s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^(?:confiance|cours|envie|peine|prise|crainte|cure|affaire|hâte|force|recours)$/i) >= 0) && morphex(dDA, [m.start[1], m[1]], ":Q.*:(?:f|m:p)", ":m:[si]") && look(s.slice(0,m.index), /(?:après +$|sans +$|pour +$|que? +$|quand +$|, +$|^ *$)/i);
    },
    s8503s_1: function (s, m) {
        return suggMasSing(m[1]);
    },
    c8544s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">avoir ", false) && morphex(dDA, [m.start[2], m[2]], ":(?:Y|[123][sp])", ":[QGWMX]");
    },
    s8544s_1: function (s, m) {
        return suggVerbPpas(m[2], ":m:s");
    },
    c8557s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[3], m[3]], ":V0a", false) && ! (((m[4].search(/^(?:décidé|essayé|tenté)$/) >= 0) && look(s.slice(m.end[0]), / +d(?:e |’)/)) || ((m[4].search(/^réussi$/) >= 0) && look(s.slice(m.end[0]), / +à/))) && morph(dDA, [m.start[2], m[2]], ":[NAQ]", false) && morphex(dDA, [m.start[4], m[4]], ":V[0-3]..t.*:Q.*:s", ":[GWpi]") && ! morph(dDA, nextword1(s, m.end[0]), ":(?:Y|Oo|D)", false);
    },
    s8557s_1: function (s, m) {
        return suggPlur(m[4], m[2]);
    },
    c8572s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[3], m[3]], ":V0a", false) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:m", false) && (morphex(dDA, [m.start[4], m[4]], ":V[0-3]..t.*:Q.*:f", ":[GWme]") || morphex(dDA, [m.start[4], m[4]], ":V[0-3]..t.*:Q.*:p", ":[GWsi]"));
    },
    s8572s_1: function (s, m) {
        return suggMasSing(m[4]);
    },
    c8587s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[3], m[3]], ":V0a", false) && ! (((m[4].search(/^(?:décidé|essayé|tenté)$/) >= 0) && look(s.slice(m.end[0]), / +d(?:e |’)/)) || ((m[4].search(/^réussi$/) >= 0) && look(s.slice(m.end[0]), / +à/))) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:f", false) && (morphex(dDA, [m.start[4], m[4]], ":V[0-3]..t.*:Q.*:m", ":[GWfe]") || morphex(dDA, [m.start[4], m[4]], ":V[0-3]..t.*:Q.*:p", ":[GWsi]")) && ! morph(dDA, nextword1(s, m.end[0]), ":(?:Y|Oo)|>que?", false);
    },
    s8587s_1: function (s, m) {
        return suggFemSing(m[4]);
    },
    c8604s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false) && (morphex(dDA, [m.start[2], m[2]], ":V[0-3]..t.*:Q.*:f", ":[GWme]") || morphex(dDA, [m.start[2], m[2]], ":V[0-3]..t.*:Q.*:p", ":[GWsi]"));
    },
    s8604s_1: function (s, m) {
        return suggMasSing(m[2]);
    },
    c8614s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[1].search(/^(?:A|avions)$/) >= 0) && morph(dDA, [m.start[1], m[1]], ":V0a", false) && morph(dDA, [m.start[2], m[2]], ":V.+:(?:Y|2p)", false);
    },
    s8614s_1: function (s, m) {
        return suggVerbPpas(m[2], ":m:s");
    },
    c8614s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && m[1] == "a" && m[2].endsWith("") && ! look(s.slice(0,m.index), /\b(?:[mtn]’|il +|on +|elle +)$/i);
    },
    c8625s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false) && (morph(dDA, [m.start[3], m[3]], ":Y") || (m[3].search(/^(?:[mtsn]e|[nv]ous|leur|lui)$/) >= 0));
    },
    c8630s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false) && (morph(dDA, [m.start[3], m[3]], ":Y") || (m[3].search(/^(?:[mtsn]e|[nv]ous|leur|lui)$/) >= 0));
    },
    c8639s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, nextword1(s, m.end[0]), ":[NAQ].*:[me]", false);
    },
    c8642s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0e", false);
    },
    c8666s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false) && morphex(dDA, [m.start[2], m[2]], ":(?:Y|2p|Q.*:[fp])", ":m:[si]") && m[2] != "prise" && ! morph(dDA, prevword1(s, m.index), ">(?:les|[nv]ous|en)|:[NAQ].*:[fp]", false) && ! look(s.slice(0,m.index), /\b(?:quel(?:le|)s?|combien) /i);
    },
    s8666s_1: function (s, m) {
        return suggMasSing(m[2]);
    },
    c8673s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false) && morphex(dDA, [m.start[2], m[2]], ":(?:Y|2p|Q.*:[fp])", ":m:[si]") && m[2] != "prise" && ! morph(dDA, prevword1(s, m.index), ">(?:les|[nv]ous|en)|:[NAQ].*:[fp]", false) && ! look(s.slice(0,m.index), /\b(?:quel(?:le|)s?|combien) /i);
    },
    s8673s_1: function (s, m) {
        return suggMasSing(m[2]);
    },
    c8680s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":V0a", false) && morphex(dDA, [m.start[3], m[3]], ":(?:Y|2p|Q.*:p)", ":[si]");
    },
    s8680s_1: function (s, m) {
        return suggMasSing(m[3]);
    },
    c8686s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0a", false) && morphex(dDA, [m.start[2], m[2]], ":V[123]..t.*:Q.*:s", ":[GWpi]");
    },
    s8686s_1: function (s, m) {
        return suggPlur(m[2]);
    },
    c8704s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":(?:G|Y|P|1p|3[sp])") && ! look(s.slice(m.end[0]), /^ +(?:je|tu|ils?|elles?|on|[vn]ous) /);
    },
    s8704s_1: function (s, m) {
        return suggVerb(m[1], ":1p");
    },
    c8715s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":(?:G|Y|P|2p|3[sp])") && ! look(s.slice(m.end[0]), /^ +(?:je|ils?|elles?|on|[vn]ous) /);
    },
    s8715s_1: function (s, m) {
        return suggVerb(m[1], ":2p");
    },
    c8725s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":2s", ":3[sp]");
    },
    s8725s_1: function (s, m) {
        return suggVerb(m[1], ":3s");
    },
    c8725s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && morphex(dDA, [m.start[1], m[1]], ":1p", ":3[sp]");
    },
    s8725s_2: function (s, m) {
        return suggVerb(m[1], ":3p");
    },
    c8725s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! bCondMemo && morphex(dDA, [m.start[1], m[1]], ":2p", ":3[sp]");
    },
    s8725s_3: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c8760s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[NAQ]", ":G");
    },
    c8771s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V[13].*:Ip.*:2s", ":[GNAM]");
    },
    s8771s_1: function (s, m) {
        return m[1].slice(0,-1);
    },
    c8775s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V[13].*:Ip.*:2s", ":G");
    },
    s8775s_1: function (s, m) {
        return m[1].slice(0,-1);
    },
    c8788s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[MYOs]");
    },
    c8796s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V[23].*:Ip.*:3s", ":[GNA]|>(?:devoir|suffire)") && analyse(m[1].slice(0,-1)+"s", ":E:2s", false) && ! ((m[1].search(/^vient$/i) >= 0) && look(s.slice(m.end[0]), /^ +l[ea]/)) && ! ((m[1].search(/^dit$/i) >= 0) && look(s.slice(m.end[0]), /^ +[A-ZÉÈÂÎ]/));
    },
    s8796s_1: function (s, m) {
        return m[1].slice(0,-1)+"s";
    },
    c8802s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V[23].*:Ip.*:3s", ":G") && analyse(m[1].slice(0,-1)+"s", ":E:2s", false);
    },
    s8802s_1: function (s, m) {
        return m[1].slice(0,-1)+"s";
    },
    c8813s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V3.*:Ip.*:3s", ":[GNA]") && ! ((m[1].search(/^répond$/i) >= 0) && look(s.slice(m.end[0]), /^ +[A-ZÉÈÂÎ]/));
    },
    c8818s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V3.*:Ip.*:3s", ":G");
    },
    c8837s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":A", ":G") && ! look(s.slice(m.end[0]), /\bsoit\b/);
    },
    c8858s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":E|>chez", false) && _oDict.isValid(m[1]);
    },
    s8858s_1: function (s, m) {
        return suggVerbImpe(m[1]);
    },
    c8864s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":E|>chez", false) && _oDict.isValid(m[1]);
    },
    s8864s_1: function (s, m) {
        return suggVerbTense(m[1], ":E", ":2s");
    },
    c8892s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":E", ":[GM]");
    },
    c8901s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":E", ":[GM]") && morphex(dDA, nextword1(s, m.end[0]), ":", ":(?:Y|3[sp])", true) && morph(dDA, prevword1(s, m.index), ":Cc", false, true) && ! look(s.slice(0,m.index), /~ +$/);
    },
    c8910s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":E", ":[GM]") && morphex(dDA, nextword1(s, m.end[0]), ":", ":(?:N|A|Q|Y|B|3[sp])", true) && morph(dDA, prevword1(s, m.index), ":Cc", false, true) && ! look(s.slice(0,m.index), /~ +$/);
    },
    c8919s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":E", ":[GM]") && morphex(dDA, nextword1(s, m.end[0]), ":", ":(?:N|A|Q|Y|MP)", true) && morph(dDA, prevword1(s, m.index), ":Cc", false, true) && ! look(s.slice(0,m.index), /~ +$/);
    },
    c8934s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[0].endsWith("t-en") && look(s.slice(0,m.index), /\bva$/i) && morph(dDA, nextword1(s, m.end[0]), ">guerre ", false, false));
    },
    c8942s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":E", ":(?:G|M[12])") && morphex(dDA, nextword1(s, m.end[0]), ":", ":(?:Y|[123][sp])", true);
    },
    s8942s_1: function (s, m) {
        return m[0].replace(/ /g, "-");
    },
    c8951s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":E", false);
    },
    s8951s_1: function (s, m) {
        return m[0].replace(/ /g, "-");
    },
    c8960s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":E", false) && morphex(dDA, nextword1(s, m.end[0]), ":[RC]", ":[NAQ]", true);
    },
    s8960s_1: function (s, m) {
        return m[0].replace(/ /g, "-");
    },
    c8969s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":E", false) && morphex(dDA, nextword1(s, m.end[0]), ":[RC]", ":Y", true);
    },
    s8969s_1: function (s, m) {
        return m[0].replace(/ /g, "-");
    },
    c8978s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, nextword1(s, m.end[0]), ":Y", false, false);
    },
    s8978s_1: function (s, m) {
        return m[0].replace(/ /g, "-");
    },
    c8981s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! prevword1(s, m.index) && ! morph(dDA, nextword1(s, m.end[0]), ":Y", false, false);
    },
    s8984s_1: function (s, m) {
        return m[0].replace(/ /g, "-");
    },
    c9004s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":R", false, true);
    },
    c9005s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":R", false, false);
    },
    c9007s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] == "le" && ! morph(dDA, [m.start[2], m[2]], ":N.*:[me]:[si]");
    },
    c9007s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] == "la" && ! morph(dDA, [m.start[2], m[2]], ":N.*:[fe]:[si]");
    },
    c9007s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] == "les" && ! morph(dDA, [m.start[2], m[2]], ":N.*:.:[pi]");
    },
    c9011s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":R", false, false);
    },
    c9013s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[123][sp]");
    },
    c9014s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":[123]s", false, false);
    },
    c9015s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":(?:[123]s|R)", false, false);
    },
    c9016s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":(?:[123]p|R)", false, false);
    },
    c9017s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, prevword1(s, m.index), ":3p", false, false);
    },
    c9018s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[123][sp]", false);
    },
    c9019s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":(?:[123][sp]|Y)", ":(?:[NAQ].*:m:[si]|G|M)");
    },
    c9020s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":(?:[123][sp]|Y)", ":(?:[NAQ].*:f:[si]|G|M)");
    },
    c9021s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":(?:[123][sp]|Y)", ":(?:[NAQ].*:[si]|G|M)");
    },
    c9022s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":(?:[123][sp]|Y)", ":(?:[NAQ].*:[si]|G|M)");
    },
    c9024s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":(?:[123][sp]|Y)", ":(?:A|G|M|1p)");
    },
    c9025s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":(?:[123][sp]|Y)", ":(?:A|G|M|2p)");
    },
    c9027s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":V", false);
    },
    c9028s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! prevword1(s, m.index);
    },
    c9029s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":V", false);
    },
    c9030s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":2s", false) || look(s.slice(0,m.index), /\b(?:je|tu|on|ils?|elles?|nous) +$/i);
    },
    c9031s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":2s|>(ils?|elles?|on) ", false) || look(s.slice(0,m.index), /\b(?:je|tu|on|ils?|elles?|nous) +$/i);
    },
    c9045s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V", false) && m[2] != "A";
    },
    c9049s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V", false) && m[2] != "A";
    },
    c9053s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":Y") && m[2] != "A";
    },
    c9072s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:ce que?|tout) /i);
    },
    c9087s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":M") && ! (m[1].endsWith("ez") && look(s.slice(m.end[0]), / +vous/));
    },
    s9087s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c9095s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":(?:Q|2p)", ":M");
    },
    s9095s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c9103s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:aimer|aller|désirer|devoir|espérer|pouvoir|préférer|souhaiter|venir) ", false) && ! morph(dDA, [m.start[1], m[1]], ":[GN]", false) && morphex(dDA, [m.start[2], m[2]], ":V", ":M");
    },
    s9103s_1: function (s, m) {
        return suggVerbInfi(m[2]);
    },
    c9112s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">devoir ", false) && morphex(dDA, [m.start[2], m[2]], ":V", ":M") && ! morph(dDA, prevword1(s, m.index), ":D", false);
    },
    s9112s_1: function (s, m) {
        return suggVerbInfi(m[2]);
    },
    c9120s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":(?:Q|2p)", ":M");
    },
    s9120s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c9128s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">valoir ", false) && morphex(dDA, [m.start[2], m[2]], ":(?:Q|2p)", ":[GM]");
    },
    s9128s_1: function (s, m) {
        return suggVerbInfi(m[2]);
    },
    c9136s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V1", ":[NM]") && ! m[1]._isTitle() && ! look(s.slice(0,m.index), /> +$/);
    },
    s9136s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c9145s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">avoir ", false) && morphex(dDA, [m.start[2], m[2]], ":V1", ":N");
    },
    s9145s_1: function (s, m) {
        return suggVerbInfi(m[2]);
    },
    c9153s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[Q123][sp]?", ":Y");
    },
    s9153s_1: function (s, m) {
        return suggVerbInfi(m[1]);
    },
    c9169s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":V0e", false) && (morphex(dDA, [m.start[2], m[2]], ":Y", ":[NAQ]") || m[2] in aSHOULDBEVERB) && ! (m[1].search(/^(?:soit|été)$/i) >= 0) && ! morph(dDA, prevword1(s, m.index), ":Y|>ce", false, false) && ! look(s.slice(0,m.index), /ce (?:>|qu|que >) $/i) && ! look_chk1(dDA, s.slice(0,m.index), 0, /({w_2}) +> $/i, ":Y") && ! look_chk1(dDA, s.slice(0,m.index), 0, /^ *>? *([a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+)/i, ":Y");
    },
    s9169s_1: function (s, m) {
        return suggVerbPpas(m[2]);
    },
    c9182s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":1s|>(?:en|y)", false);
    },
    s9182s_1: function (s, m) {
        return suggVerb(m[1], ":1s");
    },
    c9186s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:1s|G)") && ! (morph(dDA, [m.start[2], m[2]], ":[PQ]", false) && morph(dDA, prevword1(s, m.index), ":V0.*:1s", false, false));
    },
    s9186s_1: function (s, m) {
        return suggVerb(m[2], ":1s");
    },
    c9190s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:1s|G|1p)");
    },
    s9190s_1: function (s, m) {
        return suggVerb(m[2], ":1s");
    },
    c9194s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:1s|G|1p)");
    },
    s9194s_1: function (s, m) {
        return suggVerb(m[2], ":1s");
    },
    c9198s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:1s|G|1p|3p!)");
    },
    s9198s_1: function (s, m) {
        return suggVerb(m[2], ":1s");
    },
    c9220s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:G|[ISK].*:2s)") && ! (morph(dDA, [m.start[2], m[2]], ":[PQ]", false) && morph(dDA, prevword1(s, m.index), ":V0.*:2s", false, false));
    },
    s9220s_1: function (s, m) {
        return suggVerb(m[2], ":2s");
    },
    c9224s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:G|[ISK].*:2s)");
    },
    s9224s_1: function (s, m) {
        return suggVerb(m[2], ":2s");
    },
    c9228s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:G|2p|3p!|[ISK].*:2s)");
    },
    s9228s_1: function (s, m) {
        return suggVerb(m[2], ":2s");
    },
    c9241s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3s|P|G)") && ! (morph(dDA, [m.start[2], m[2]], ":[PQ]", false) && morph(dDA, prevword1(s, m.index), ":V0.*:3s", false, false));
    },
    s9241s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9241s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && morph(dDA, [m.start[2], m[2]], ":3p", false);
    },
    c9246s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3s|P|G)");
    },
    s9246s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9246s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && morph(dDA, [m.start[2], m[2]], ":3p", false);
    },
    c9265s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3s|P|G)") && ! (morph(dDA, [m.start[2], m[2]], ":[PQ]", false) && morph(dDA, prevword1(s, m.index), ":V0.*:3s", false, false));
    },
    s9265s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9269s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3s|P|G)");
    },
    s9269s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9279s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":(?:3s|P|G|Q.*:m:[si])");
    },
    s9279s_1: function (s, m) {
        return suggVerb(m[1], ":3s");
    },
    c9283s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":(?:3s|P|G)");
    },
    s9283s_1: function (s, m) {
        return suggVerb(m[1], ":3s");
    },
    c9293s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:N|A|3s|P|Q|G|V0e.*:3p)");
    },
    s9293s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9298s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3s|P|Q|G)");
    },
    s9298s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9308s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3s|P|Q|G|3p!)") && ! morph(dDA, prevword1(s, m.index), ":[VR]|>de", false, false);
    },
    s9308s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9328s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":(?:3s|P|Q|G|3p!)") && ! morph(dDA, prevword1(s, m.index), ":[VRD]|>de", false, false) && !( morph(dDA, [m.start[1], m[1]], ":(?:Y|N.*:m:[si])", false) && ! (m[0].search(/ (?:qui|>) /) >= 0) );
    },
    s9328s_1: function (s, m) {
        return suggVerb(m[1], ":3s");
    },
    c9339s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3s|P|Q|G|3p!)") && ! morph(dDA, prevword1(s, m.index), ":[VR]|>de", false, false) && !( morph(dDA, [m.start[2], m[2]], ":Y", false) && ! (m[0].search(/ (?:qui|>) /) >= 0) );
    },
    s9339s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9350s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[2], m[2]], ":3s", false);
    },
    s9350s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9350s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[YP]", false);
    },
    c9363s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3s|P|G)") && ! morph(dDA, prevword1(s, m.index), ":R|>(?:et|ou)", false, false) && ! (morph(dDA, [m.start[2], m[2]], ":[PQ]", false) && morph(dDA, prevword1(s, m.index), ":V0.*:3s", false, false));
    },
    s9363s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9363s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && morph(dDA, [m.start[2], m[2]], ":3p", false);
    },
    c9369s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3s|P|G)") && ! morph(dDA, prevword1(s, m.index), ":R|>(?:et|ou)", false, false);
    },
    s9369s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9369s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && morph(dDA, [m.start[2], m[2]], ":3p", false);
    },
    s9388s_1: function (s, m) {
        return m[1].slice(0,-1)+"t";
    },
    c9396s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3s|P|G)") && morphex(dDA, prevword1(s, m.index), ":C", ":(?:Y|P|Q|[123][sp]|R)", true) && !( m[1].endsWith("ien") && look(s.slice(0,m.index), /> +$/) && morph(dDA, [m.start[2], m[2]], ":Y", false) );
    },
    s9396s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9415s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3s|P|G|Q)") && morphex(dDA, prevword1(s, m.index), ":C", ":(?:Y|P|Q|[123][sp]|R)", true);
    },
    s9415s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9420s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3s|P|G)") && morphex(dDA, prevword1(s, m.index), ":C", ":(?:Y|P|Q|[123][sp]|R)", true);
    },
    s9420s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9430s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":Y", false) && morph(dDA, [m.start[2], m[2]], ":V.[a-z_!?]+(?!.*:(?:3s|P|Q|Y|3p!))");
    },
    s9430s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9439s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! ((m[0].search(/^une? +(?:dizaine|douzaine|quinzaine|vingtaine|trentaine|quarantaine|cinquantaine|soixantaine|centaine|majorité|minorité|millier|poignée) /i) >= 0) && morph(dDA, [m.start[3], m[3]], ":3p", false)) && morphex(dDA, prevword1(s, m.index), ":C", ":(?:Y|P)", true) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:[si]", false) && morphex(dDA, [m.start[3], m[3]], ":V", ":(?:3s|P|Q|Y|3p!|G)") && ! (look(s.slice(0,m.index), /\b(?:et|ou) +$/i) && morph(dDA, [m.start[3], m[3]], ":[1-3]p", false)) && ! look(s.slice(0,m.index), /\bni .* ni\b/i) && ! checkAgreement(m[2], m[3]);
    },
    s9439s_1: function (s, m) {
        return suggVerb(m[3], ":3s");
    },
    c9445s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! ((m[0].search(/^une? +(?:dizaine|douzaine|quinzaine|vingtaine|trentaine|quarantaine|cinquantaine|soixantaine|centaine|majorité|minorité|millier|poignée) /i) >= 0) && morph(dDA, [m.start[3], m[3]], ":3p", false)) && morphex(dDA, prevword1(s, m.index), ":C", ":(?:Y|P)", true) && morph(dDA, [m.start[2], m[2]], ":[NAQ].*:[si]", false) && morphex(dDA, [m.start[3], m[3]], ":V", ":(?:3s|1p|P|Q|Y|3p!|G)") && ! (look(s.slice(0,m.index), /\b(?:et|ou) +$/i) && morph(dDA, [m.start[3], m[3]], ":[123]p", false)) && ! look(s.slice(0,m.index), /\bni .* ni\b/i);
    },
    s9445s_1: function (s, m) {
        return suggVerb(m[3], ":3s");
    },
    c9472s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, prevword1(s, m.index), ":C", ":(?:Y|P)", true) && isAmbiguousAndWrong(m[2], m[3], ":s", ":3s") && ! (look(s.slice(0,m.index), /\b(?:et|ou) +$/i) && morph(dDA, [m.start[3], m[3]], ":(?:[123]p|p)", false)) && ! look(s.slice(0,m.index), /\bni .* ni\b/i);
    },
    s9472s_1: function (s, m) {
        return suggVerb(m[3], ":3s", suggSing);
    },
    c9478s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, prevword1(s, m.index), ":C", ":(?:Y|P)", true) && isVeryAmbiguousAndWrong(m[2], m[3], ":s", ":3s", ! prevword1(s, m.index)) && ! (look(s.slice(0,m.index), /\b(?:et|ou) +$/i) && morph(dDA, [m.start[3], m[3]], ":(?:[123]p|p)", false)) && ! look(s.slice(0,m.index), /\bni .* ni\b/i);
    },
    s9478s_1: function (s, m) {
        return suggVerb(m[3], ":3s", suggSing);
    },
    c9495s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ( morph(dDA, [m.start[0], m[0]], ":1s") || ( look(s.slice(0,m.index), /> +$/) && morph(dDA, [m.start[0], m[0]], ":1s", false) ) ) && ! (m[0].slice(0,1)._isUpperCase() && look(sx.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/)) && ! look(sx.slice(0,m.index), /\b(?:j(?:e |[’'])|moi(?:,? qui| seul) )/i);
    },
    s9495s_1: function (s, m) {
        return suggVerb(m[0], ":3s");
    },
    c9500s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[0], m[0]], ":2s", ":(?:E|G|W|M|J|[13][sp]|2p)") && ! m[0].slice(0,1)._isUpperCase() && ! look(s.slice(0,m.index), /^ *$/) && ( ! morph(dDA, [m.start[0], m[0]], ":[NAQ]", false) || look(s.slice(0,m.index), /> +$/) ) && ! look(sx.slice(0,m.index), /\bt(?:u |[’']|oi,? qui |oi seul )/i);
    },
    s9500s_1: function (s, m) {
        return suggVerb(m[0], ":3s");
    },
    c9506s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[0], m[0]], ":2s", ":(?:G|W|M|J|[13][sp]|2p)") && ! (m[0].slice(0,1)._isUpperCase() && look(sx.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/)) && ( ! morph(dDA, [m.start[0], m[0]], ":[NAQ]", false) || look(s.slice(0,m.index), /> +$/) ) && ! look(sx.slice(0,m.index), /\bt(?:u |[’']|oi,? qui |oi seul )/i);
    },
    s9506s_1: function (s, m) {
        return suggVerb(m[0], ":3s");
    },
    c9512s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[0], m[0]], ":[12]s", ":(?:E|G|W|M|J|3[sp]|2p|1p)") && ! (m[0].slice(0,1)._isUpperCase() && look(sx.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/)) && ( ! morph(dDA, [m.start[0], m[0]], ":[NAQ]", false) || look(s.slice(0,m.index), /> +$/) || ( (m[0].search(/^étais$/i) >= 0) && ! morph(dDA, prevword1(s, m.index), ":[DA].*:p", false, true) ) ) && ! look(sx.slice(0,m.index), /\b(?:j(?:e |[’'])|moi(?:,? qui| seul) |t(?:u |[’']|oi,? qui |oi seul ))/i);
    },
    s9512s_1: function (s, m) {
        return suggVerb(m[0], ":3s");
    },
    c9518s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[0].slice(0,1)._isUpperCase() && look(sx.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/)) && ! look(sx.slice(0,m.index), /\b(?:j(?:e |[’'])|moi(?:,? qui| seul) |t(?:u |[’']|oi,? qui |oi seul ))/i);
    },
    s9518s_1: function (s, m) {
        return suggVerb(m[0], ":3s");
    },
    c9522s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! (m[0].slice(0,1)._isUpperCase() && look(sx.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/)) && ! look(sx.slice(0,m.index), /\b(?:j(?:e |[’'])|moi(?:,? qui| seul) |t(?:u |[’']|oi,? qui |oi seul ))/i);
    },
    s9522s_1: function (s, m) {
        return suggVerb(m[0], ":3s");
    },
    c9536s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":(?:1p|3[sp])") && ! look(s.slice(m.end[0]), /^ +(?:je|tu|ils?|elles?|on|[vn]ous)/);
    },
    s9536s_1: function (s, m) {
        return suggVerb(m[1], ":1p");
    },
    c9540s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":[13]p") && ! look(s.slice(m.end[0]), /^ +(?:je|tu|il|elle|on|[vn]ous)/);
    },
    s9540s_1: function (s, m) {
        return suggVerb(m[1], ":1p");
    },
    c9544s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":1p") && ! look(s.slice(m.end[0]), /^ +(?:ils|elles)/);
    },
    s9544s_1: function (s, m) {
        return suggVerb(m[1], ":1p");
    },
    c9556s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":(?:2p|3[sp])") && ! look(s.slice(m.end[0]), /^ +(?:je|ils?|elles?|on|[vn]ous)/);
    },
    s9556s_1: function (s, m) {
        return suggVerb(m[1], ":2p");
    },
    c9560s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":2p") && ! look(s.slice(m.end[0]), /^ +(?:je|ils?|elles?|on|[vn]ous)/);
    },
    s9560s_1: function (s, m) {
        return suggVerb(m[1], ":2p");
    },
    c9571s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[0], m[0]], ":V.*:1p", ":[EGMNAJ]") && ! (m[0].slice(0,1)._isUpperCase() && look(s.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/)) && ! look(sx.slice(0,m.index), /\b(?:[nN]ous(?:-mêmes?|)|[eE]t moi(?:-même|)|[nN]i (?:moi|nous)),? /);
    },
    s9571s_1: function (s, m) {
        return suggVerb(m[0], ":3p");
    },
    c9576s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[0], m[0]], ":V.*:2p", ":[EGMNAJ]") && ! (m[0].slice(0,1)._isUpperCase() && look(s.slice(0,m.index), /[a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ]/)) && ! look(sx.slice(0,m.index), /\b(?:[vV]ous(?:-mêmes?|)|[eE]t toi(?:-même|)|[tT]oi(?:-même|) et|[nN]i (?:vous|toi)),? /);
    },
    c9593s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3p|P|Q|G)") && ! (morph(dDA, [m.start[2], m[2]], ":[PQ]", false) && morph(dDA, prevword1(s, m.index), ":V0.*:3p", false, false));
    },
    s9593s_1: function (s, m) {
        return suggVerb(m[2], ":3p");
    },
    c9593s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && morph(dDA, [m.start[2], m[2]], ":3s", false);
    },
    c9598s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3p|P|G)");
    },
    s9598s_1: function (s, m) {
        return suggVerb(m[2], ":3p");
    },
    c9598s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && morph(dDA, [m.start[2], m[2]], ":3s", false);
    },
    c9608s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3p|P|Q|G)");
    },
    s9608s_1: function (s, m) {
        return suggVerb(m[2], ":3p");
    },
    c9617s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3p|P|Q|G)") && ! morph(dDA, prevword1(s, m.index), ":[VR]", false, false) && ! (morph(dDA, [m.start[2], m[2]], ":Y", false) && (m[1].search(/lesquel/i) >= 0) && ! (m[0].search(/ qui |>/) >= 0));
    },
    s9617s_1: function (s, m) {
        return suggVerb(m[2], ":3p");
    },
    c9627s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3p|P|Q|G)") && ! morph(dDA, prevword1(s, m.index), ":R", false, false) && ! (morph(dDA, [m.start[2], m[2]], ":[PQ]", false) && morph(dDA, prevword1(s, m.index), ":V0.*:3p", false, false));
    },
    s9627s_1: function (s, m) {
        return suggVerb(m[2], ":3p");
    },
    c9627s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && morph(dDA, [m.start[2], m[2]], ":3s", false);
    },
    c9632s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3p|P|G)") && ! morph(dDA, prevword1(s, m.index), ":R", false, false);
    },
    s9632s_1: function (s, m) {
        return suggVerb(m[2], ":3p");
    },
    c9632s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return bCondMemo && morph(dDA, [m.start[2], m[2]], ":3s", false);
    },
    c9652s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:à|avec|sur|chez|par|dans|parmi|contre|ni|de|pour|sous) +$/i);
    },
    c9664s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3p|P|Q|G)") && ! morph(dDA, prevword1(s, m.index), ":[VR]|>de ", false, false);
    },
    s9664s_1: function (s, m) {
        return suggVerb(m[2], ":3p");
    },
    c9669s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:3p|P|Q|G)") && ! morph(dDA, prevword1(s, m.index), ":[VR]", false, false);
    },
    s9669s_1: function (s, m) {
        return suggVerb(m[2], ":3p");
    },
    c9682s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V", ":(?:G|N|A|3p|P|Q)") && ! morph(dDA, prevword1(s, m.index), ":[VR]", false, false);
    },
    s9682s_1: function (s, m) {
        return suggVerb(m[2], ":3p");
    },
    c9691s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[NAQ].*:[pi]", false) && morphex(dDA, [m.start[3], m[3]], ":V", ":(?:[13]p|P|Q|Y|G|A.*:e:[pi])") && morphex(dDA, prevword1(s, m.index), ":C", ":[YP]", true) && ! checkAgreement(m[2], m[3]) && !( morph(dDA, [m.start[3], m[3]], ":3s", false) && look(s.slice(0,m.index), /\b(?:le|ce(?:tte|t|)|[mts](?:on|a)) .+ entre .+ et /i) );
    },
    s9691s_1: function (s, m) {
        return suggVerb(m[3], ":3p");
    },
    c9696s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[NAQ].*:[pi]", false) && morphex(dDA, [m.start[3], m[3]], ":V", ":(?:[13]p|P|Y|G)") && morphex(dDA, prevword1(s, m.index), ":C", ":[YP]", true) && !( morph(dDA, [m.start[3], m[3]], ":3s", false) && look(s.slice(0,m.index), /\b(?:le|ce(?:tte|t|)|[mts](?:on|a)) .+ entre .+ et /i) );
    },
    s9696s_1: function (s, m) {
        return suggVerb(m[3], ":3p");
    },
    c9720s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[pi]", false) && morphex(dDA, [m.start[2], m[2]], ":V", ":(?:[13]p|P|G|Q)") && morph(dDA, nextword1(s, m.end[0]), ":(?:R|D.*:p)|>au ", false, true);
    },
    s9720s_1: function (s, m) {
        return suggVerb(m[2], ":3p");
    },
    c9724s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":[NAQ].*:[pi]", false) && morphex(dDA, [m.start[2], m[2]], ":V", ":(?:[13]p|P|G)");
    },
    s9724s_1: function (s, m) {
        return suggVerb(m[2], ":3p");
    },
    c9734s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, prevword1(s, m.index), ":C", ":[YP]", true) && isAmbiguousAndWrong(m[2], m[3], ":p", ":3p");
    },
    s9734s_1: function (s, m) {
        return suggVerb(m[3], ":3p", suggPlur);
    },
    c9743s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, prevword1(s, m.index), ":C", ":[YP]", true) && isVeryAmbiguousAndWrong(m[1], m[2], ":p", ":3p", ! prevword1(s, m.index));
    },
    s9743s_1: function (s, m) {
        return suggVerb(m[2], ":3p", suggPlur);
    },
    c9761s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, prevword1(s, m.index), ":C", ":[YP]", true) && isVeryAmbiguousAndWrong(m[1], m[2], ":m:p", ":3p", ! prevword1(s, m.index));
    },
    s9761s_1: function (s, m) {
        return suggVerb(m[2], ":3p", suggMasPlur);
    },
    c9769s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, prevword1(s, m.index), ":C", ":[YP]", true) && isVeryAmbiguousAndWrong(m[1], m[2], ":f:p", ":3p", ! prevword1(s, m.index));
    },
    s9769s_1: function (s, m) {
        return suggVerb(m[2], ":3p", suggFemPlur);
    },
    c9781s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V0e", ":3s");
    },
    s9781s_1: function (s, m) {
        return suggVerb(m[1], ":3s");
    },
    c9790s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V0e.*:3s", ":3p");
    },
    s9790s_1: function (s, m) {
        return m[1].slice(0,-1);
    },
    c9800s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V0e", ":3p");
    },
    s9800s_1: function (s, m) {
        return suggVerb(m[1], ":3p");
    },
    c9809s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":V0e.*:3p", ":3s");
    },
    c9822s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(0,m.index), /\b(?:et |ou |[dD][eu] |ni |[dD]e l’) *$/) && morph(dDA, [m.start[1], m[1]], ":M", false) && morphex(dDA, [m.start[2], m[2]], ":[123][sp]", ":(?:G|3s|3p!|P|M|[AQ].*:[si])") && ! morph(dDA, prevword1(s, m.index), ":[VRD]", false, false) && ! look(s.slice(0,m.index), /([A-ZÉÈ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+), +([A-ZÉÈ][a-zA-Zà-öÀ-Ö0-9_ø-ÿØ-ßĀ-ʯﬁ-ﬆ-]+), +$/) && ! (morph(dDA, [m.start[2], m[2]], ":3p", false) && prevword1(s, m.index));
    },
    s9822s_1: function (s, m) {
        return suggVerb(m[2], ":3s");
    },
    c9840s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":M", false) && morph(dDA, [m.start[2], m[2]], ":M", false) && morphex(dDA, [m.start[3], m[3]], ":[123][sp]", ":(?:G|3p|P|Q.*:[pi])") && ! morph(dDA, prevword1(s, m.index), ":R", false, false);
    },
    s9840s_1: function (s, m) {
        return suggVerb(m[3], ":3p");
    },
    c9854s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":(?:[12]s|3p)", ":(?:3s|G|W|3p!)") && ! look(s.slice(m.end[0]), /^ +(?:et|ou) (?:l(?:es? |a |’|eurs? )|[mts](?:a|on|es) |ce(?:tte|ts|) |[nv]o(?:s|tre) |d(?:u|es) )/);
    },
    s9854s_1: function (s, m) {
        return suggVerb(m[1], ":3s");
    },
    c9870s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[123]s", ":(?:3p|G|W)");
    },
    s9870s_1: function (s, m) {
        return suggVerb(m[1], ":3p");
    },
    c9878s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[12][sp]", ":(?:G|W|3[sp]|Y|P|Q|N)");
    },
    s9878s_1: function (s, m) {
        return suggVerb(m[1], ":3s");
    },
    c9886s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[12][sp]", ":(?:G|W|3[sp])");
    },
    s9886s_1: function (s, m) {
        return suggVerb(m[1], ":3s");
    },
    c9896s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V.*:1[sŝś]", ":[GNW]") && ! look(s.slice(0,m.index), /\bje +>? *$/i) && ! morph(dDA, nextword1(s, m.end[0]), ":(?:Oo|X|1s)", false, false);
    },
    s9896s_1: function (s, m) {
        return m[1].slice(0,-1)+"é-je";
    },
    c9900s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V.*:1s", ":[GNW]") && ! look(s.slice(0,m.index), /\b(?:je|tu) +>? *$/i) && ! morph(dDA, nextword1(s, m.end[0]), ":(?:Oo|X|1s)", false, false);
    },
    c9904s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), /^ +(?:en|y|ne|>)/) && morphex(dDA, [m.start[1], m[1]], ":V.*:2s", ":[GNW]") && ! look(s.slice(0,m.index), /\b(?:je|tu) +>? *$/i);
    },
    c9908s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), /^ +(?:en|y|ne|>)/) && morphex(dDA, [m.start[1], m[1]], ":V.*:3s", ":[GNW]") && ! look(s.slice(0,m.index), /\b(?:ce|il|elle|on) +>? *$/i);
    },
    s9908s_1: function (s, m) {
        return m[0].replace(/ /g, "-");
    },
    c9912s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), /^ +(?:en|y|ne|aussi|>)/) && morphex(dDA, [m.start[1], m[1]], ":V.*:3s", ":[GNW]") && ! look(s.slice(0,m.index), /\b(?:ce|il|elle|on) +>? *$/i);
    },
    c9916s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), /^ +(?:en|y|ne|aussi|>)/) && morphex(dDA, [m.start[1], m[1]], ":V.*:1p", ":[GNW]") && ! morph(dDA, prevword1(s, m.index), ":Os", false, false) && ! morph(dDA, nextword1(s, m.end[0]), ":Y", false, false);
    },
    c9921s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), /^ +(?:en|y|ne|aussi|>)/) && ! m[1].endsWith("euillez") && morphex(dDA, [m.start[1], m[1]], ":V.*:2p", ":[GNW]") && ! morph(dDA, prevword1(s, m.index), ":Os", false, false) && ! morph(dDA, nextword1(s, m.end[0]), ":Y", false, false);
    },
    c9926s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! look(s.slice(m.end[0]), /^ +(?:en|y|ne|aussi|>)/) && morphex(dDA, [m.start[1], m[1]], ":V.*:3p", ":[GNW]") && ! look(s.slice(0,m.index), /\b(?:ce|ils|elles) +>? *$/i);
    },
    s9926s_1: function (s, m) {
        return m[0].replace(/ /g, "-");
    },
    c9943s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":1[sśŝ]");
    },
    s9943s_1: function (s, m) {
        return suggVerb(m[1], ":1ś");
    },
    c9943s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":V", false);
    },
    s9943s_2: function (s, m) {
        return suggSimil(m[1], ":1[sśŝ]");
    },
    c9953s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":[ISK].*:2s");
    },
    s9953s_1: function (s, m) {
        return suggVerb(m[1], ":2s");
    },
    c9953s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":V", false);
    },
    s9953s_2: function (s, m) {
        return suggSimil(m[1], ":2s");
    },
    c9962s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":3s");
    },
    s9962s_1: function (s, m) {
        return suggVerb(m[1], ":3s");
    },
    c9962s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "t" && (! m[1].endsWith("oilà") || m[2] != "il") && morphex(dDA, [m.start[1], m[1]], ":", ":V");
    },
    s9962s_2: function (s, m) {
        return suggSimil(m[1], ":3s");
    },
    c9962s_3: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! m[2].endsWith(("n", "N")) && morphex(dDA, [m.start[1], m[1]], ":3p", ":3s");
    },
    c9977s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":(?:1p|E:2[sp])");
    },
    s9977s_1: function (s, m) {
        return suggVerb(m[1], ":1p");
    },
    c9977s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":", ":V|>chez ");
    },
    s9977s_2: function (s, m) {
        return suggSimil(m[1], ":1p");
    },
    c9986s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":2p");
    },
    s9986s_1: function (s, m) {
        return suggVerb(m[1], ":2p");
    },
    c9986s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return ! morph(dDA, [m.start[1], m[1]], ":V|>chez ", false);
    },
    s9986s_2: function (s, m) {
        return suggSimil(m[1], ":2p");
    },
    c9996s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":V", ":3p") && _oDict.isValid(m[1]);
    },
    s9996s_1: function (s, m) {
        return suggVerb(m[1], ":3p");
    },
    c9996s_2: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return m[1] != "t" && ! morph(dDA, [m.start[1], m[1]], ":V", false) && _oDict.isValid(m[1]);
    },
    s9996s_2: function (s, m) {
        return suggSimil(m[1], ":3p");
    },
    c10010s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">avoir ", false) && morph(dDA, [m.start[2], m[2]], ":V.......e_.*:Q", false);
    },
    c10013s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">avoir ", false) && morph(dDA, [m.start[2], m[2]], ":V.......e_.*:Q", false);
    },
    c10027s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":[YX]|>y ", "R");
    },
    c10044s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[2], m[2]], ":[YX]", false);
    },
    c10058s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":(?:Os|M)", false) && morphex(dDA, [m.start[2], m[2]], ":[SK]", ":(?:G|V0|I)") && ! prevword1(s, m.index);
    },
    c10062s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":[SK]", ":(?:G|V0|I)") && ! prevword1(s, m.index);
    },
    c10072s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":(?:Os|M)", false) && morphex(dDA, [m.start[2], m[2]], ":S", ":[IG]");
    },
    s10072s_1: function (s, m) {
        return suggVerbMode(m[2], ":I", m[1]);
    },
    c10083s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ">(?:afin|pour|quoi|permettre|falloir|vouloir|ordonner|exiger|désirer|douter|préférer|suffire) ", false) && morph(dDA, [m.start[2], m[2]], ":(?:Os|M)", false) && ! morph(dDA, [m.start[3], m[3]], ":[GYS]", false) && ! (morph(dDA, [m.start[1], m[1]], ">douter ", false) && morph(dDA, [m.start[3], m[3]], ":(?:If|K)", false));
    },
    s10083s_1: function (s, m) {
        return suggVerbMode(m[3], ":S", m[2]);
    },
    c10100s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":(?:Os|M)", false) && ! morph(dDA, [m.start[2], m[2]], ":[GYS]", false);
    },
    s10100s_1: function (s, m) {
        return suggVerbMode(m[2], ":S", m[1]);
    },
    c10108s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[2], m[2]], ":S", ":[GIK]") && ! (m[2].search(/^e(?:usse|û[mt]es|ût)/) >= 0);
    },
    s10108s_1: function (s, m) {
        return suggVerbMode(m[2], ":I", m[1]);
    },
    c10112s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morphex(dDA, [m.start[1], m[1]], ":S", ":[GIK]") && m[1] != "eusse";
    },
    s10112s_1: function (s, m) {
        return suggVerbMode(m[1], ":I", "je");
    },
    c10123s_1: function (s, sx, m, dDA, sCountry, bCondMemo) {
        return morph(dDA, [m.start[1], m[1]], ":(?:Os|M)", false) && (morph(dDA, [m.start[2], m[2]], ":V.*:S") || morph(dDA, [m.start[2], m[2]], ":V0e.*:S", false));
    },
    s10123s_1: function (s, m) {
        return suggVerbMode(m[2], ":I", m[1]);
    },
}





exports.load = load;
exports.parse = parse;
exports.lang = lang;
exports.version = version;
exports.getDictionary = getDictionary;
exports.setOption = setOption;
exports.setOptions = setOptions;
exports.getOptions = getOptions;
exports.resetOptions = resetOptions;
exports.ignoreRule = ignoreRule;
exports.reactivateRule = reactivateRule;
exports.resetIgnoreRules = resetIgnoreRules;
exports.listRules = listRules;
