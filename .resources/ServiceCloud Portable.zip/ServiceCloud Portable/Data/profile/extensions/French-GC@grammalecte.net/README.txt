
= GRAMMALECTE =

French grammar checker
By Olivier R. (olivier /at/ grammalecte /dot/ net)

Website: http://www.dicollecte.org/grammalecte

License: GPL 3 -- http://www.gnu.org/copyleft/gpl.html

Grammalecte for Firefox is a derivative tool born from the version
for LibreOffice written in Python.

Written in JavaScript ES6/ES7.
